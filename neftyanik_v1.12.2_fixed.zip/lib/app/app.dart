import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../features/history/history_screen.dart';
import '../features/auth/login_screen.dart';
import '../features/corrections/correction_screen.dart';
import '../features/home/home_screen.dart';
import '../features/pads/pad_screen.dart';
import '../features/wells/well_screen.dart';
import '../features/wells/well_card_screen.dart';
import '../features/organization/organization_screen.dart';
import '../features/organization/personnel_screen.dart';
import '../features/areas/area_screen.dart';
import '../features/areas/wells_hierarchy_screen.dart';
import '../features/organization/profile_screen.dart';
import '../features/walk/walk_start_screen.dart';
import '../core/models/measurement.dart';
import '../core/models/pad.dart';
import '../features/walk/walk_summary_screen.dart';
import 'theme.dart';

class OilmanApp extends StatelessWidget {
  const OilmanApp({super.key, this.initializationError});
  final Object? initializationError;
  static final GoRouter _router = GoRouter(initialLocation: '/login', routes: [
    GoRoute(path: '/login', builder: (_, __) => const LoginScreen()),
    GoRoute(path: '/', builder: (_, __) => const HomeScreen()),
    GoRoute(path: '/pad/:padId', builder: (_, s) => PadScreen(padId: s.pathParameters['padId']!)),
    GoRoute(path: '/pad/:padId/card/:wellId', builder: (_, s) => WellCardScreen(padId:s.pathParameters['padId']!,wellId:s.pathParameters['wellId']!)),
    GoRoute(path: '/pad/:padId/well/:wellId', builder: (_, s) => WellScreen(padId:s.pathParameters['padId']!,wellId:s.pathParameters['wellId']!)),
    GoRoute(path: '/pad/:padId/walk/:index', builder: (_, state) {final padId=state.pathParameters['padId']!;final index=int.tryParse(state.pathParameters['index']!)??0;final pad=demoPads.firstWhere((p)=>p.id==padId);final safe=index.clamp(0,pad.wells.length-1).toInt();return WellScreen(key:ValueKey('walk-$padId-$safe'),padId:padId,wellId:pad.wells[safe].id,walkIndex:safe);}),
    GoRoute(path: '/pad/:padId/walk-summary', builder: (_, s) => WalkSummaryScreen(padId:s.pathParameters['padId']!)),
    GoRoute(path: '/walk', builder: (_, __) => const WalkStartScreen()),
    GoRoute(path: '/history', builder: (_, __) => const HistoryScreen()),
    GoRoute(path: '/area/:areaId', builder: (_, s) => AreaScreen(areaId:s.pathParameters['areaId']!)),
    GoRoute(path: '/personnel', builder: (_, __) => const PersonnelScreen()),
    GoRoute(path: '/wells', builder: (_, __) => const WellsHierarchyScreen()),
    GoRoute(path: '/profile', builder: (_, __) => const ProfileScreen()),
    GoRoute(path: '/correction', builder: (_, s) => CorrectionScreen(measurement:s.extra! as Measurement)),
    GoRoute(path: '/organization', builder: (_, __) => const OrganizationScreen()),
  ]);
  @override Widget build(BuildContext context)=>MaterialApp.router(title:'Нефтяник',debugShowCheckedModeBanner:false,theme:buildAppTheme(),routerConfig:_router,builder:(context,child){if(initializationError==null)return child??const SizedBox.shrink();return Material(child:SafeArea(child:Center(child:Padding(padding:const EdgeInsets.all(24),child:Text('Не удалось открыть локальные данные\n$initializationError',textAlign:TextAlign.center)))));});
}
