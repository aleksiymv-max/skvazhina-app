import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../core/models/pad.dart';
import '../../core/models/well.dart';
import '../../core/models/user.dart';
import '../../core/models/measurement.dart';
import '../../core/services/session_service.dart';
import '../../core/services/sync_service.dart';
import '../../core/repositories/measurement_repository.dart';
import '../../shared/widgets/status_chip.dart';

class HomeScreen extends StatefulWidget { const HomeScreen({super.key}); @override State<HomeScreen> createState()=>_HomeScreenState(); }
class _HomeScreenState extends State<HomeScreen>{
  final search=TextEditingController(); final repo=MeasurementRepository();
  List<Pad> pads=demoPads; Map<String,WellStatus> statuses={}; List<Measurement> problems=[]; bool loading=true;
  @override void initState(){super.initState();_load();}
  Future<void> _load() async { statuses=await repo.allWellStatuses(); problems=await repo.unresolvedProblems(); if(mounted)setState(()=>loading=false); }
  WellStatus _status(Well w)=>statuses[w.id]??w.status;
  List<Well> get wells=>pads.expand((p)=>p.wells).toList();
  int _count(WellStatus s)=>wells.where((w)=>_status(w)==s).length;
  int get oilPads=>pads.where((p)=>p.wells.any((w)=>w.type==WellType.oil)).length;
  int get gasPads=>pads.where((p)=>p.wells.any((w)=>w.type==WellType.gasCondensate)).length;
  int get oilWells=>wells.where((w)=>w.type==WellType.oil).length;
  int get gasWells=>wells.where((w)=>w.type==WellType.gasCondensate).length;
  int get oilProblems=>problems.where((m)=>demoPads.expand((p)=>p.wells).firstWhere((w)=>w.id==m.wellId).type==WellType.oil).length;
  int get gasProblems=>problems.length-oilProblems;

  @override Widget build(BuildContext context){
    if(loading)return const Scaffold(body:Center(child:CircularProgressIndicator()));
    final u=SessionService.instance.currentUser; final filtered=pads.where((p)=>p.name.toLowerCase().contains(search.text.toLowerCase())).toList();
    return Scaffold(appBar:AppBar(title:const Text('Нефтяник'),actions:[IconButton(onPressed:()=>context.push('/organization'),icon:const Icon(Icons.groups_outlined)),IconButton(onPressed:()async{await SessionService.instance.logout();if(context.mounted)context.go('/login');},icon:const Icon(Icons.logout))]),
      body:RefreshIndicator(onRefresh:_load,child:ListView(padding:const EdgeInsets.fromLTRB(16,8,16,24),children:[
        Text('Обзор месторождения',style:Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight:FontWeight.w800)),const SizedBox(height:12),
        _dashboardGrid(),const SizedBox(height:12),_statusVisual(),const SizedBox(height:12),
        if(u.role==UserRole.shopChief||u.role==UserRole.engineer)_personnelCard(),const SizedBox(height:8),
        Card(child:ListTile(leading:Icon(SyncService.instance.online?Icons.cloud_outlined:Icons.cloud_off_outlined),title:const Text('Локальные данные'),subtitle:Text(SyncService.instance.online?'Готово к синхронизации':'Работа офлайн'),trailing:StatusChip(label:SyncService.instance.online?'Онлайн':'Офлайн',kind:SyncService.instance.online?StatusKind.ok:StatusKind.warning))),
        const SizedBox(height:14),TextField(controller:search,onChanged:(_)=>setState((){}),decoration:const InputDecoration(labelText:'Поиск кустовой площадки',prefixIcon:Icon(Icons.search))),const SizedBox(height:12),
        const Text('Кустовые площадки',style:TextStyle(fontSize:20,fontWeight:FontWeight.w800)),const SizedBox(height:8),
        ...filtered.map((p)=>Card(child:ListTile(onTap:()=>context.push('/pad/${p.id}'),leading:CircleAvatar(backgroundColor:Theme.of(context).colorScheme.primaryContainer,child:const Icon(Icons.factory_outlined)),title:Text(p.name,style:const TextStyle(fontWeight:FontWeight.w800)),subtitle:Text('${p.wells.length} скважин · ${p.type}'),trailing:const Icon(Icons.chevron_right)))),
        const SizedBox(height:12),Row(children:[Expanded(child:FilledButton.icon(onPressed:()=>context.push('/trends'),icon:const Icon(Icons.show_chart),label:const Text('Тренды'))),const SizedBox(width:10),Expanded(child:OutlinedButton.icon(onPressed:()=>context.push('/history'),icon:const Icon(Icons.history),label:const Text('История')))])
      ])));
  }

  Widget _dashboardGrid()=>GridView.count(crossAxisCount:2,shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),crossAxisSpacing:10,mainAxisSpacing:10,childAspectRatio:1.48,children:[
    _dash('Кусты',pads.length,'Нефтяные $oilPads · Газовые $gasPads',Icons.location_on_outlined,()=>_showPads()),
    _dash('Скважины',wells.length,'Нефтяные $oilWells · Газовые $gasWells',Icons.oil_barrel_outlined,()=>_showWells()),
    _dash('В работе',_count(WellStatus.working),'Остановлено ${_count(WellStatus.stopped)} · ВНР ${_count(WellStatus.workover)}',Icons.play_circle_outline,()=>_showStatus()),
    _dash('Проблемы',problems.length,'Нефть $oilProblems · Газ $gasProblems',Icons.warning_amber_outlined,()=>_showProblems()),
  ]);
  Widget _dash(String title,int value,String sub,IconData icon,VoidCallback tap)=>Card(child:InkWell(borderRadius:BorderRadius.circular(14),onTap:tap,child:Padding(padding:const EdgeInsets.all(12),child:Column(crossAxisAlignment:CrossAxisAlignment.start,mainAxisAlignment:MainAxisAlignment.center,children:[Icon(icon,color:Theme.of(context).colorScheme.primary),const SizedBox(height:6),Text(title,style:const TextStyle(fontSize:12,color:Colors.black54)),Text('$value',style:const TextStyle(fontSize:25,fontWeight:FontWeight.w900)),Text(sub,style:const TextStyle(fontSize:10,color:Colors.black54))]))));

  Widget _statusVisual(){final total=wells.length;return Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('Состояние фонда',style:TextStyle(fontSize:17,fontWeight:FontWeight.w800)),const SizedBox(height:8),SizedBox(height:150,child:Row(children:[SizedBox(width:150,height:150,child:CustomPaint(painter:_StatusDonutPainter(working:_count(WellStatus.working),stopped:_count(WellStatus.stopped),workover:_count(WellStatus.workover),total:total))),const SizedBox(width:18),Expanded(child:Column(mainAxisAlignment:MainAxisAlignment.center,crossAxisAlignment:CrossAxisAlignment.start,children:[_legendRow('В работе',_count(WellStatus.working),Colors.green),_legendRow('Остановлена',_count(WellStatus.stopped),Colors.red),_legendRow('ВНР',_count(WellStatus.workover),Colors.orange)]))])),const SizedBox(height:8),Row(mainAxisAlignment:MainAxisAlignment.spaceAround,children:[_legend('Нефть',oilWells,Colors.black87),_legend('Газ',gasWells,Colors.blue)])])));}
  Widget _legendRow(String label,int value,Color color)=>Padding(padding:const EdgeInsets.symmetric(vertical:4),child:Row(children:[Container(width:10,height:10,decoration:BoxDecoration(color:color,shape:BoxShape.circle)),const SizedBox(width:7),Expanded(child:Text(label)),Text('$value',style:const TextStyle(fontWeight:FontWeight.w800))]));
  Widget _bar(String label, int value, int total, Color color) {
    final double fraction = total == 0 ? 0.0 : value / total;
    return Padding(
      padding: const EdgeInsets.only(bottom: 9),
      child: Row(
        children: [
          SizedBox(width: 90, child: Text(label)),
          Expanded(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(6),
              child: LinearProgressIndicator(
                value: fraction,
                minHeight: 10,
                color: color,
                backgroundColor: Colors.black12,
              ),
            ),
          ),
          const SizedBox(width: 8),
          SizedBox(width: 28, child: Text('$value')),
        ],
      ),
    );
  }
  Widget _legend(String label,int value,Color color)=>Column(children:[Text('$value',style:TextStyle(fontSize:20,fontWeight:FontWeight.w900,color:color)),Text(label,style:const TextStyle(fontSize:11))]);

  Widget _personnelCard() {
    final u = SessionService.instance.currentUser;
    final chiefId = u.isChief ? u.id : (u.chiefId ?? 'chief-001');
    final ws = SessionService.instance.workersForChief(chiefId);
    final pending = SessionService.instance.pendingForChief(chiefId).length;
    final engineers = ws.where((x) => x.role == UserRole.engineer).length;
    final operators = ws.where((x) => x.role == UserRole.operator).length;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Персонал', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(child: Text('Всего: ${ws.length}')),
                Expanded(child: Text('ИТР: $engineers')),
                Expanded(child: Text('Операторы: $operators')),
              ],
            ),
            if (u.isChief) Text('Ожидают подтверждения: $pending'),
            const SizedBox(height: 6),
            ...ws.take(5).map(
              (x) => ListTile(
                dense: true,
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.person_outline),
                title: Text(x.name),
                subtitle: Text(
                  x.role == UserRole.engineer
                      ? '${x.role.label} · ${x.itrSubrole?.label ?? ''}'
                      : x.role.label,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showPads()=>_showList('Кустовые площадки',pads.map((p)=>'${p.name} — ${p.wells.length} скважин · ${p.wells.where((w)=>w.type==WellType.oil).length} нефт. · ${p.wells.where((w)=>w.type==WellType.gasCondensate).length} газ.').toList());
  void _showWells()=>_showGrouped('Скважины по кустовым площадкам',pads.map((p)=>MapEntry(p.name,p.wells.map((w)=>'${w.number} · ${w.type==WellType.oil?'Нефтяная':'Газовая'} · ${_statusLabel(_status(w))}').toList())).toList());
  void _showStatus()=>_showGrouped('Состояние скважин',pads.map((p)=>MapEntry(p.name,p.wells.map((w)=>'${w.number} · ${_statusLabel(_status(w))}').toList())).toList());
  Future<void> _showProblems() async {
    problems = await repo.unresolvedProblems();
    if (!mounted) return;

    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (_) => StatefulBuilder(
        builder: (ctx, setModal) {
          return SafeArea(
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Text(
                  'Проблемы · ${problems.length}',
                  style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 10),
                if (problems.isEmpty)
                  const Card(
                    child: Padding(
                      padding: EdgeInsets.all(18),
                      child: Text('Открытых проблем нет.'),
                    ),
                  ),
                ...problems.map((m) {
                  Well? well;
                  for (final pad in demoPads) {
                    for (final item in pad.wells) {
                      if (item.id == m.wellId) well = item;
                    }
                  }
                  final isOil = well?.type == WellType.oil;
                  final canResolve = SessionService.instance.currentUser.canCorrect;

                  return Card(
                    child: ListTile(
                      title: Text(
                        'Скважина ${m.wellNumber} · ${isOil ? 'Нефтяная' : 'Газовая'}',
                      ),
                      subtitle: Text(m.problemNote ?? 'Проблема'),
                      trailing: canResolve
                          ? FilledButton(
                              onPressed: () async {
                                await repo.resolveProblem(
                                  m.id!,
                                  SessionService.instance.currentUser.id,
                                  SessionService.instance.currentUser.name,
                                );
                                problems = await repo.unresolvedProblems();
                                setModal(() {});
                                if (mounted) setState(() {});
                              },
                              child: const Text('Решена'),
                            )
                          : null,
                    ),
                  );
                }),
              ],
            ),
          );
        },
      ),
    );
  }

  String _statusLabel(WellStatus s)=>switch(s){WellStatus.working=>'В работе',WellStatus.workover=>'ВНР',WellStatus.stopped=>'Остановлена'};
  void _showList(String title,List<String> rows)=>showModalBottomSheet(context:context,isScrollControlled:true,builder:(_)=>SafeArea(child:ListView(padding:const EdgeInsets.all(16),children:[Text(title,style:const TextStyle(fontSize:20,fontWeight:FontWeight.w800)),const SizedBox(height:10),...rows.map((x)=>Card(child:ListTile(leading:const Icon(Icons.chevron_right),title:Text(x))))])));
  void _showGrouped(String title,List<MapEntry<String,List<String>>> groups)=>showModalBottomSheet(context:context,isScrollControlled:true,builder:(_)=>SafeArea(child:ListView(padding:const EdgeInsets.all(16),children:[Text(title,style:const TextStyle(fontSize:20,fontWeight:FontWeight.w800)),const SizedBox(height:10),...groups.map((g)=>Card(child:ExpansionTile(title:Text(g.key,style:const TextStyle(fontWeight:FontWeight.w800)),children:g.value.map((x)=>ListTile(dense:true,leading:const Icon(Icons.circle,size:8),title:Text(x))).toList())))])));
  @override void dispose(){search.dispose();super.dispose();}
}

class _StatusDonutPainter extends CustomPainter {
  _StatusDonutPainter({required this.working,required this.stopped,required this.workover,required this.total});
  final int working, stopped, workover, total;
  @override void paint(Canvas canvas, Size size) {
    final center=Offset(size.width/2,size.height/2); final radius=size.shortestSide/2-12; final bg=Paint()..style=PaintingStyle.stroke..strokeWidth=22..color=Colors.black12;
    canvas.drawCircle(center,radius,bg);
    if(total==0)return;
    var start=-1.5708;
    void arc(int value,Color color){final sweep=6.28318*value/total;if(value>0){final p=Paint()..style=PaintingStyle.stroke..strokeWidth=22..strokeCap=StrokeCap.butt..color=color;canvas.drawArc(Rect.fromCircle(center:center,radius:radius),start,sweep,false,p);start+=sweep;}}
    arc(working,Colors.green);arc(stopped,Colors.red);arc(workover,Colors.orange);
  }
  @override bool shouldRepaint(covariant _StatusDonutPainter old)=>old.working!=working||old.stopped!=stopped||old.workover!=workover||old.total!=total;
}
