import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import '../../core/models/measurement.dart';
import '../../core/models/pad.dart';
import '../../core/models/well.dart';
import '../../core/repositories/measurement_repository.dart';

class WellCardScreen extends StatefulWidget {
  const WellCardScreen({super.key, required this.padId, required this.wellId});
  final String padId;
  final String wellId;
  @override State<WellCardScreen> createState() => _WellCardScreenState();
}

class _WellCardScreenState extends State<WellCardScreen> {
  final repo = MeasurementRepository();
  Measurement? latest;
  List<Measurement> data = [];
  int days = 7;
  final Set<String> selected = {};
  bool loading = true;

  Pad get pad => demoPads.firstWhere((p) => p.id == widget.padId);
  Well get well => pad.wells.firstWhere((w) => w.id == widget.wellId);

  List<MapEntry<String, String>> get params => well.type == WellType.gasCondensate
      ? const {'r_buf':'Рбуф','rtr':'Ртр','r_line':'Рлин','t_before_choke':'Тдо штуцера','t_line':'Тлин','choke_value':'Дроссель 1','choke_value2':'Дроссель 2','r_downhole':'Рузд','t_downhole':'Тузд','r_ko':'Рко','inhibitor_feed':'Ингибитор'}.entries.toList()
      : const {'rtr':'Ртр','rz':'Рз','frequency':'F','current':'Iср','load':'Загрузка','rp':'Рпр','t_ped':'Тпэд','r_insul':'Rизол'}.entries.toList();

  @override void initState() { super.initState(); selected.addAll(params.take(3).map((e) => e.key)); _load(); }
  Future<void> _load() async {
    setState(() => loading = true);
    latest = await repo.latestForWell(well.id);
    data = await repo.trends(wellId: well.id, from: DateTime.now().subtract(Duration(days: days)), to: DateTime.now());
    if (mounted) setState(() => loading = false);
  }
  double? value(Measurement m, String key) => switch(key) {
    'rtr'=>m.rtr,'rz'=>m.rz,'frequency'=>m.frequency,'current'=>m.current,'load'=>m.load,'rp'=>m.rp,'t_ped'=>m.tPed,'r_insul'=>m.rInsul,
    'r_buf'=>m.rBuf,'r_line'=>m.rLine,'t_before_choke'=>m.tBeforeChoke,'t_line'=>m.tLine,'choke_value'=>m.chokeValue,'choke_value2'=>m.chokeValue2,
    'r_downhole'=>m.rDownhole,'t_downhole'=>m.tDownhole,'r_ko'=>m.rKo,'inhibitor_feed'=>m.inhibitorFeed,_=>null};

  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text('Скважина ${well.number}')),
    body: loading ? const Center(child: CircularProgressIndicator()) : ListView(padding: const EdgeInsets.all(16), children: [
      Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children:[Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('Скважина ${well.number}',style:const TextStyle(fontSize:22,fontWeight:FontWeight.w900)),Text('${well.type.label} · ${pad.areaName} · ${pad.name}',style:const TextStyle(color:Colors.black54))])),Chip(label:Text(well.status.label))]),
        if(latest!=null)...[const Divider(height:26),Text('Последний замер: ${DateFormat('dd.MM.yyyy HH:mm').format(latest!.measuredAt)}'),Text('Оператор: ${latest!.operatorName ?? '—'}')],
      ])),
      const SizedBox(height:12),
      _latestCard(),
      const SizedBox(height:12),
      Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        const Text('Тренды',style:TextStyle(fontSize:20,fontWeight:FontWeight.w900)),const SizedBox(height:12),
        SegmentedButton<int>(segments:const [ButtonSegment(value:1,label:Text('24 ч')),ButtonSegment(value:7,label:Text('7 д')),ButtonSegment(value:30,label:Text('30 д')),ButtonSegment(value:90,label:Text('90 д'))],selected:{days},onSelectionChanged:(v){days=v.first;_load();}),
        const SizedBox(height:12),Wrap(spacing:6,runSpacing:6,children:params.map((e)=>FilterChip(label:Text(e.value),selected:selected.contains(e.key),onSelected:(v)=>setState(()=>v?selected.add(e.key):selected.remove(e.key)))).toList()),
        const SizedBox(height:14),SizedBox(height:260,child:CustomPaint(painter:_MultiTrendPainter(data:data,keys:selected.toList(),getter:value))),
      ]))),
      const SizedBox(height:12),FilledButton.icon(onPressed:()=>context.push('/pad/${pad.id}/walk/${pad.wells.indexWhere((w)=>w.id==well.id)}'),icon:const Icon(Icons.assignment_turned_in_outlined),label:const Text('Перейти к обходу')),
    ]),
  );

  Widget _latestCard(){ if(latest==null)return const Card(child:Padding(padding:EdgeInsets.all(18),child:Text('По скважине пока нет замеров.'))); final m=latest!; return Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('Текущие параметры',style:TextStyle(fontSize:18,fontWeight:FontWeight.w900)),const SizedBox(height:10),Wrap(spacing:8,runSpacing:8,children:params.map((e){final v=value(m,e.key);return Container(width:150,padding:const EdgeInsets.all(12),decoration:BoxDecoration(color:const Color(0xFFF2F7FF),borderRadius:BorderRadius.circular(14)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(e.value,style:const TextStyle(fontSize:11,color:Colors.black54)),Text(v==null?'—':v.toStringAsFixed(2).replaceAll(RegExp(r'\.00$'),''),style:const TextStyle(fontSize:18,fontWeight:FontWeight.w900))]));}).toList())]))); }
}

class _MultiTrendPainter extends CustomPainter {
  _MultiTrendPainter({required this.data,required this.keys,required this.getter});
  final List<Measurement> data; final List<String> keys; final double? Function(Measurement,String) getter;
  @override void paint(Canvas c,Size s){final axis=Paint()..color=Colors.black12..strokeWidth=1;c.drawLine(Offset(28,8),Offset(28,s.height-24),axis);c.drawLine(Offset(28,s.height-24),Offset(s.width-8,s.height-24),axis);final palette=[Colors.blue,Colors.orange,Colors.green,Colors.purple,Colors.red,Colors.teal];for(var k=0;k<keys.length;k++){final vals=data.map((m)=>getter(m,keys[k])).toList();final numeric=vals.whereType<double>().toList();if(numeric.isEmpty)continue;final min=numeric.reduce((a,b)=>a<b?a:b),max=numeric.reduce((a,b)=>a>b?a:b),span=max-min==0?1:max-min;final pts=<Offset>[];for(var i=0;i<vals.length;i++){final v=vals[i];if(v==null)continue;final x=28+(s.width-38)*(vals.length <= 1 ? 0.5 : i / (vals.length - 1));final y=10+(s.height-40)*(1-(v-min)/span);pts.add(Offset(x,y));}if(pts.isEmpty)continue;final p=Paint()..color=palette[k%palette.length]..strokeWidth=2.5..style=PaintingStyle.stroke;final path=Path()..moveTo(pts.first.dx,pts.first.dy);for(final pt in pts.skip(1))path.lineTo(pt.dx,pt.dy);c.drawPath(path,p);}}
  @override bool shouldRepaint(covariant _MultiTrendPainter old)=>true;
}
