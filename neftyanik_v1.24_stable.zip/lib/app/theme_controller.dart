import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ThemeController extends ChangeNotifier {
  ThemeController._(); static final instance=ThemeController._();
  ThemeMode mode=ThemeMode.light;
  Future<void> load() async { final p=await SharedPreferences.getInstance(); mode=(p.getBool('darkTheme')??false)?ThemeMode.dark:ThemeMode.light; notifyListeners(); }
  Future<void> setDark(bool dark) async { mode=dark?ThemeMode.dark:ThemeMode.light; notifyListeners(); final p=await SharedPreferences.getInstance(); await p.setBool('darkTheme',dark); }
}
