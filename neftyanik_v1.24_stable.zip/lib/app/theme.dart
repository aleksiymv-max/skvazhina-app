import 'package:flutter/material.dart';

ThemeData buildLightTheme() {
  const blue=Color(0xFF0877F9), navy=Color(0xFF0755A5), bg=Color(0xFFF3F8FF);
  final scheme=ColorScheme.fromSeed(seedColor:blue,brightness:Brightness.light).copyWith(primary:blue,secondary:navy,surface:Colors.white);
  return ThemeData(useMaterial3:true,colorScheme:scheme,scaffoldBackgroundColor:bg,
    appBarTheme:const AppBarTheme(backgroundColor:navy,foregroundColor:Colors.white,surfaceTintColor:Colors.transparent,elevation:0),
    cardTheme:CardThemeData(color:Colors.white,elevation:.8,surfaceTintColor:Colors.white,shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(18),side:const BorderSide(color:Color(0xFFD9E9FB)))),
    navigationBarTheme:NavigationBarThemeData(backgroundColor:Colors.white,indicatorColor:const Color(0xFFDDEEFF),labelTextStyle:WidgetStateProperty.resolveWith((s)=>TextStyle(fontWeight:s.contains(WidgetState.selected)?FontWeight.w800:FontWeight.w500,fontSize:11))),
    filledButtonTheme:FilledButtonThemeData(style:FilledButton.styleFrom(backgroundColor:blue,foregroundColor:Colors.white,shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(12)))),
    inputDecorationTheme:_input(Colors.white,const Color(0xFFD5E5F7),blue));
}

ThemeData buildDarkTheme() {
  const blue=Color(0xFF2196F3), bg=Color(0xFF09131F), surface=Color(0xFF111F2E), border=Color(0xFF26384A);
  final scheme=ColorScheme.fromSeed(seedColor:blue,brightness:Brightness.dark).copyWith(primary:blue,surface:surface);
  return ThemeData(useMaterial3:true,brightness:Brightness.dark,colorScheme:scheme,scaffoldBackgroundColor:bg,
    appBarTheme:const AppBarTheme(backgroundColor:Color(0xFF0B1A29),foregroundColor:Colors.white,surfaceTintColor:Colors.transparent,elevation:0),
    cardTheme:CardThemeData(color:surface,elevation:0,surfaceTintColor:surface,shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(18),side:const BorderSide(color:border))),
    navigationBarTheme:NavigationBarThemeData(backgroundColor:const Color(0xFF0B1A29),indicatorColor:const Color(0xFF163D60),labelTextStyle:WidgetStateProperty.resolveWith((s)=>TextStyle(fontWeight:s.contains(WidgetState.selected)?FontWeight.w800:FontWeight.w500,fontSize:11))),
    filledButtonTheme:FilledButtonThemeData(style:FilledButton.styleFrom(backgroundColor:blue,foregroundColor:Colors.white,shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(12)))),
    inputDecorationTheme:_input(surface,border,blue));
}
InputDecorationTheme _input(Color fill,Color border,Color focus)=>InputDecorationTheme(filled:true,fillColor:fill,border:OutlineInputBorder(borderRadius:BorderRadius.circular(14),borderSide:BorderSide(color:border)),enabledBorder:OutlineInputBorder(borderRadius:BorderRadius.circular(14),borderSide:BorderSide(color:border)),focusedBorder:OutlineInputBorder(borderRadius:BorderRadius.circular(14),borderSide:BorderSide(color:focus,width:2)),contentPadding:const EdgeInsets.symmetric(horizontal:16,vertical:14));
