import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../core/models/user.dart';
import '../../core/services/session_service.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final username = TextEditingController(text: 'op-001');
  final password = TextEditingController(text: 'operator');
  final name = TextEditingController();
  final newField = TextEditingController();
  bool loading = false, register = false;
  String? error;
  UserRole role = UserRole.operator;
  ItrSubrole subrole = ItrSubrole.geologist;
  String fieldId = 'field-1';
  String department = 'Цех добычи нефти и газа';

  @override Widget build(BuildContext context) {
    final fields = SessionService.instance.approvedFields;
    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.surface,
      body: Column(children:[Container(width:double.infinity,padding:const EdgeInsets.fromLTRB(24,54,24,28),decoration:const BoxDecoration(color:Color(0xFF0757C9),borderRadius:BorderRadius.only(bottomLeft:Radius.circular(30),bottomRight:Radius.circular(30))),child:const Column(children:[Icon(Icons.oil_barrel_rounded,size:58,color:Colors.white),SizedBox(height:8),Text('Нефтяник',style:TextStyle(color:Colors.white,fontSize:30,fontWeight:FontWeight.w900)),Text('Производственный контроль',style:TextStyle(color:Colors.white70))])),Expanded(child: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 460),
            child: Card(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(register ? 'Регистрация' : 'Вход', style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 6),
                  Text(register ? 'Регистрация и согласование доступа' : 'Офлайн-вход · интернет не требуется', style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
                  const SizedBox(height: 22),
                  if (register) ...[
                    TextField(controller: name, decoration: const InputDecoration(labelText: 'ФИО')),
                    const SizedBox(height: 10),
                    DropdownButtonFormField<UserRole>(
                      value: role,
                      decoration: const InputDecoration(labelText: 'Роль'),
                      items: const [
                        DropdownMenuItem(value: UserRole.operator, child: Text('Оператор ДНГ')),
                        DropdownMenuItem(value: UserRole.engineer, child: Text('ИТР')),
                        DropdownMenuItem(value: UserRole.dispatcher, child: Text('Диспетчер')),
                        DropdownMenuItem(value: UserRole.shopChief, child: Text('Начальник цеха')),
                      ],
                      onChanged: (v) => setState(() { role = v ?? UserRole.operator; if (role != UserRole.shopChief && fieldId == 'new') fieldId = 'field-1'; }),
                    ),
                    if (role == UserRole.engineer) Padding(
                      padding: const EdgeInsets.only(top: 10),
                      child: DropdownButtonFormField<ItrSubrole>(
                        value: subrole,
                        decoration: const InputDecoration(labelText: 'Градация ИТР'),
                        items: ItrSubrole.values.map((r) => DropdownMenuItem(value: r, child: Text(r.label))).toList(),
                        onChanged: (v) => setState(() => subrole = v ?? ItrSubrole.geologist),
                      ),
                    ),
                    const SizedBox(height: 10),
                    DropdownButtonFormField<String>(
                      value: department,
                      decoration: const InputDecoration(labelText: 'Подразделение'),
                      items: const [DropdownMenuItem(value: 'Цех добычи нефти и газа', child: Text('Цех добычи нефти и газа'))],
                      onChanged: (v) => setState(() => department = v ?? 'Цех добычи нефти и газа'),
                    ),
                    const SizedBox(height: 10),
                    DropdownButtonFormField<String>(
                      value: fieldId,
                      decoration: const InputDecoration(labelText: 'Месторождение'),
                      items: [
                        ...fields.map((f) => DropdownMenuItem(value: f.id, child: Text(f.name))),
                        if (role == UserRole.shopChief) const DropdownMenuItem(value: 'new', child: Text('Новое месторождение')),
                      ],
                      onChanged: (v) => setState(() => fieldId = v ?? 'field-1'),
                    ),
                    if (role == UserRole.shopChief && fieldId == 'new') Padding(
                      padding: const EdgeInsets.only(top: 10),
                      child: TextField(controller: newField, decoration: const InputDecoration(labelText: 'Название нового месторождения')),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      role == UserRole.shopChief
                        ? 'Регистрация начальника цеха${fieldId == 'new' ? ' и нового месторождения' : ''} направляется администратору.'
                        : 'Заявка будет направлена начальникам выбранного месторождения.',
                      style: TextStyle(fontSize: 12, color: Theme.of(context).colorScheme.onSurfaceVariant),
                    ),
                  ] else ...[
                    TextField(controller: username, decoration: const InputDecoration(labelText: 'Логин')),
                    const SizedBox(height: 10),
                    TextField(controller: password, obscureText: true, decoration: const InputDecoration(labelText: 'Пароль')),
                  ],
                  if (error != null) Padding(padding: const EdgeInsets.only(top: 12), child: Text(error!, style: const TextStyle(color: Colors.red))),
                  const SizedBox(height: 18),
                  SizedBox(width: double.infinity, child: FilledButton(onPressed: loading ? null : (register ? _register : _login), child: Text(loading ? 'Подождите…' : (register ? 'Отправить заявку' : 'Войти')))),
                  const SizedBox(height: 8),
                  SizedBox(width: double.infinity, child: TextButton(onPressed: () => setState(() { register = !register; error = null; }), child: Text(register ? 'Вернуться ко входу' : 'Регистрация сотрудника'))),
                  const SizedBox(height: 8),
                  Text('Тест: chief-001/chief · op-001/operator · eng-001/engineer · disp-001/dispatcher · adm-001/admin', style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant, fontSize: 12)),
                ]),
              ),
            ),
          ),
        ),
      ))]),
    );
  }

  Future<void> _login() async {
    setState(() => loading = true);
    try { await SessionService.instance.login(username.text.trim(), password.text); if (mounted) context.go('/'); }
    catch (e) { if (mounted) setState(() => error = e.toString()); }
    finally { if (mounted) setState(() => loading = false); }
  }

  Future<void> _register() async {
    if (name.text.trim().isEmpty) { setState(() => error = 'Введите ФИО'); return; }
    setState(() => loading = true);
    try {
      final id = await SessionService.instance.register(name: name.text.trim(), role: role, subrole: role == UserRole.engineer ? subrole : null, fieldId: fieldId, newFieldName: newField.text);
      if (mounted) showDialog(context: context, builder: (_) => AlertDialog(
        title: const Text('Заявка отправлена'),
        content: Text('Ваш логин: $id\n${role == UserRole.shopChief ? 'Ожидается согласование администратора.' : 'Ожидается согласование начальника цеха выбранного месторождения.'}'),
        actions: [TextButton(onPressed: () { Navigator.pop(context); setState(() => register = false); }, child: const Text('Понятно'))],
      ));
    } catch (e) { if (mounted) setState(() => error = e.toString()); }
    finally { if (mounted) setState(() => loading = false); }
  }

  @override void dispose() { username.dispose(); password.dispose(); name.dispose(); newField.dispose(); super.dispose(); }
}
