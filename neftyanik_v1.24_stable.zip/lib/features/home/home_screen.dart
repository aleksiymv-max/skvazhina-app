import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../core/models/measurement.dart';
import '../../core/models/pad.dart';
import '../../core/models/production_area.dart';
import '../../core/models/user.dart';
import '../../core/models/well.dart';
import '../../core/repositories/measurement_repository.dart';
import '../../core/services/session_service.dart';

class HomeScreen extends StatefulWidget { const HomeScreen({super.key}); @override State<HomeScreen> createState()=>_HomeScreenState(); }
class _HomeScreenState extends State<HomeScreen> {
 final repo=MeasurementRepository(); Map<String,WellStatus> statuses={}; List<Measurement> problems=[]; bool loading=true;
 @override void initState(){super.initState();SessionService.instance.addListener(_sessionChanged);_load();}
 void _sessionChanged(){if(mounted)setState((){});}
 @override void dispose(){SessionService.instance.removeListener(_sessionChanged);super.dispose();}
 Future<void> _load()async{statuses=await repo.allWellStatuses();problems=await repo.unresolvedProblems();if(mounted)setState(()=>loading=false);}
 List<Well> get wells=>demoPads.expand((p)=>p.wells).toList(); WellStatus _status(Well w)=>statuses[w.id]??w.status; int _count(WellStatus s)=>wells.where((w)=>_status(w)==s).length;
 String _statusText(WellStatus s)=>switch(s){WellStatus.working=>'В работе',WellStatus.stopped=>'Остановлена',WellStatus.workover=>'ВНР'};
 @override Widget build(BuildContext context){if(loading)return const Scaffold(body:Center(child:CircularProgressIndicator()));final user=SessionService.instance.currentUser;return Scaffold(
  appBar:AppBar(title:const Text('Нефтяник',style:TextStyle(fontWeight:FontWeight.w900)),actions:[IconButton(onPressed:()=>context.push('/profile'),icon:const Icon(Icons.account_circle_outlined))]),
  body:RefreshIndicator(onRefresh:_load,child:ListView(padding:const EdgeInsets.fromLTRB(16,16,16,28),children:[
   const Text('Главная',style:TextStyle(fontSize:26,fontWeight:FontWeight.w900)),const SizedBox(height:4),Text('Оперативная сводка по месторождению',style:TextStyle(color:Theme.of(context).colorScheme.onSurfaceVariant)),const SizedBox(height:16),
   _fieldDashboard(),const SizedBox(height:12),_statusDashboard(),const SizedBox(height:12),_problemsDashboard(),const SizedBox(height:12),if(user.role==UserRole.shopChief||user.role==UserRole.engineer||user.role==UserRole.dispatcher)_personnelDashboard(),
  ]))
 );}
 Widget _header(IconData icon,String title,String subtitle)=>Row(children:[Container(width:46,height:46,decoration:BoxDecoration(color:Theme.of(context).colorScheme.primaryContainer,borderRadius:BorderRadius.circular(14)),child:Icon(icon,color:Theme.of(context).colorScheme.primary)),const SizedBox(width:12),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(title,style:const TextStyle(fontSize:18,fontWeight:FontWeight.w900)),Text(subtitle,style:TextStyle(fontSize:12,color:Theme.of(context).colorScheme.onSurfaceVariant))])),const Icon(Icons.chevron_right)]);
 Widget _fieldDashboard()=>Card(child:InkWell(borderRadius:BorderRadius.circular(18),onTap:()=>context.push('/wells'),child:Padding(padding:const EdgeInsets.all(16),child:Column(children:[_header(Icons.location_on_outlined,'Демо-месторождение','Месторождение'),const Divider(height:24),...demoAreas.map((a){final n=a.pads.expand((p)=>p.wells).length;return Padding(padding:const EdgeInsets.symmetric(vertical:5),child:Row(children:[Expanded(child:Text(a.name,style:const TextStyle(fontWeight:FontWeight.w700))),Text('${a.pads.length} куст.  •  $n скв.',style:TextStyle(color:Theme.of(context).colorScheme.onSurfaceVariant))]));})]))));
 Widget _statusDashboard()=>Card(child:InkWell(borderRadius:BorderRadius.circular(18),onTap:_showStatus,child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[_header(Icons.donut_large_outlined,'Состояние фонда','Нажмите для списка скважин'),const SizedBox(height:16),Row(children:[_metric('В работе',_count(WellStatus.working),Colors.green),_metric('Остановлено',_count(WellStatus.stopped),Colors.red),_metric('ВНР',_count(WellStatus.workover),Colors.orange)]),const SizedBox(height:12),ClipRRect(borderRadius:BorderRadius.circular(8),child:Row(children:[_segment(_count(WellStatus.working),Colors.green),_segment(_count(WellStatus.stopped),Colors.red),_segment(_count(WellStatus.workover),Colors.orange)]))]))));
 Widget _metric(String t,int v,Color c)=>Expanded(child:Column(children:[Text('$v',style:TextStyle(fontSize:25,fontWeight:FontWeight.w900,color:c)),Text(t,textAlign:TextAlign.center,style:TextStyle(fontSize:11,color:Theme.of(context).colorScheme.onSurfaceVariant))]));
 Widget _segment(int v, Color c) {
  final alpha = v == 0 ? 0.15 : 1.0;
  return Expanded(
    flex: v == 0 ? 1 : v,
    child: Container(height: 9, color: c.withValues(alpha: alpha)),
  );
 }
 Widget _problemsDashboard()=>Card(child:InkWell(borderRadius:BorderRadius.circular(18),onTap:_showProblems,child:Padding(padding:const EdgeInsets.all(16),child:Column(children:[_header(Icons.warning_amber_rounded,'Проблемы','Открытых вопросов: ${problems.length}'),const SizedBox(height:12),...demoAreas.map((a){final ids=a.pads.expand((p)=>p.wells.map((w)=>w.id)).toSet();final n=problems.where((m)=>ids.contains(m.wellId)).length;return Row(children:[Expanded(child:Text(a.name)),Text('$n',style:TextStyle(fontWeight:FontWeight.w900,color:n>0?Colors.red:Colors.green))]);})]))));
 Widget _personnelDashboard(){final u=SessionService.instance.currentUser;final chiefId=u.isChief?u.id:(u.chiefId??'chief-001');final workers=SessionService.instance.workersForChief(chiefId);final chiefs=SessionService.instance.approvedWorkers.where((x)=>x.role==UserRole.shopChief&&SessionService.instance.isAtWork(x.id)).length;final eng=workers.where((x)=>x.role==UserRole.engineer&&SessionService.instance.isAtWork(x.id)).length;final dispatchers=workers.where((x)=>x.role==UserRole.dispatcher&&SessionService.instance.isAtWork(x.id)).length;final ops=workers.where((x)=>x.role==UserRole.operator&&SessionService.instance.isAtWork(x.id)).length;final total=chiefs+eng+dispatchers+ops;return Card(child:InkWell(borderRadius:BorderRadius.circular(18),onTap:()=>context.push('/personnel'),child:Padding(padding:const EdgeInsets.all(16),child:Column(children:[_header(Icons.groups_outlined,'Персонал','На работе: $total сотрудников'),const SizedBox(height:12),Wrap(spacing:8,runSpacing:8,children:[SizedBox(width:120,child:_small('Начальники',chiefs)),SizedBox(width:90,child:_small('ИТР',eng)),SizedBox(width:120,child:_small('Диспетчеры',dispatchers)),SizedBox(width:110,child:_small('Операторы',ops))])]))));}
 Widget _small(String t,int v)=>Column(mainAxisSize:MainAxisSize.min,children:[Text('$v',style:const TextStyle(fontSize:20,fontWeight:FontWeight.w900)),Text(t,style:TextStyle(fontSize:11,color:Theme.of(context).colorScheme.onSurfaceVariant))]);
 void _showStatus()=>showModalBottomSheet(context:context,isScrollControlled:true,showDragHandle:true,builder:(_)=>SafeArea(child:FractionallySizedBox(heightFactor:.68,child:ListView(padding:const EdgeInsets.fromLTRB(16,0,16,20),children:[const Text('Состояние скважин',style:TextStyle(fontSize:21,fontWeight:FontWeight.w900)),const SizedBox(height:10),for(final s in [WellStatus.stopped,WellStatus.workover])Card(child:ExpansionTile(initiallyExpanded:true,title:Text('${_statusText(s)} · ${_count(s)}',style:const TextStyle(fontWeight:FontWeight.w800)),children:wells.where((w)=>_status(w)==s).map((w)=>ListTile(title:Text('Скважина ${w.number}'),subtitle:Text(demoAreas.firstWhere((a)=>a.pads.any((p)=>p.wells.any((x)=>x.id==w.id))).name))).toList()))]))));
 Future<void> _showProblems() async {
  problems = await repo.unresolvedProblems();
  if (!mounted) return;

  final canResolve = SessionService.instance.currentUser.canResolveProblems;

  await showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (_) {
      return StatefulBuilder(
        builder: (ctx, setModal) {
          return SafeArea(
            child: FractionallySizedBox(heightFactor: .72, child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Text(
                  'Проблемные вопросы · ${problems.length}',
                  style: const TextStyle(
                    fontSize: 21,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 10),
                if (problems.isEmpty)
                  const Card(
                    child: Padding(
                      padding: EdgeInsets.all(18),
                      child: Text('Открытых проблем нет.'),
                    ),
                  ),
                ...problems.map((m) {
                  return Card(
                    child: ListTile(
                      title: Text('Скважина ${m.wellNumber}'),
                      subtitle: Text(m.problemNote ?? 'Проблема'),
                      trailing: canResolve
                          ? FilledButton(
                              onPressed: () async {
                                await repo.resolveProblem(
                                  m.id!,
                                  SessionService.instance.currentUser.id,
                                  SessionService.instance.currentUser.name,
                                );
                                problems = await repo.unresolvedProblems();
                                setModal(() {});
                                if (mounted) setState(() {});
                              },
                              child: const Text('Решена'),
                            )
                          : null,
                    ),
                  );
                }),
              ],
            )),
          );
        },
      );
    },
  );
 }

}
