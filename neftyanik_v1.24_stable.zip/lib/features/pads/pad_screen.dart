import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../core/models/pad.dart';
import '../../core/models/well.dart';
import '../../core/repositories/measurement_repository.dart';
import '../../core/services/session_service.dart';
import '../../shared/widgets/status_chip.dart';

class PadScreen extends StatefulWidget {
  const PadScreen({super.key, required this.padId});
  final String padId;
  @override State<PadScreen> createState() => _PadScreenState();
}

class _PadScreenState extends State<PadScreen> {
  final repo = MeasurementRepository();
  int checked = 0;
  Map<String, Object?>? active;
  List<Well> wells = const [];
  String padName = '';
  String padType = '';
  bool loading = true;
  String? error;

  @override void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    try {
      final local = demoPads.where((p) => p.id == widget.padId).firstOrNull;
      padName = local?.name ?? 'КП ${widget.padId}';
      padType = local?.type ?? '';
      wells = local?.wells ?? const [];
      if (SessionService.instance.token != null) {
        final rows = await SessionService.instance.api.fetchWells(widget.padId);
        wells = rows.map(_wellFromJson).toList();
      }
      final statusMap = await repo.allWellStatuses();
      wells = wells.map((w) => statusMap[w.id] == null ? w : Well(id:w.id, number:w.number, type:w.type, status:statusMap[w.id]!, pkvWork:w.pkvWork, pkvIdle:w.pkvIdle, rtr:w.rtr, rz:w.rz, frequency:w.frequency, current:w.current, load:w.load, rp:w.rp, tPed:w.tPed, rInsul:w.rInsul, pkvInstalled:w.pkvInstalled, pidInstalled:w.pidInstalled)).toList();
      checked = await repo.checkedCount(widget.padId);
      active = await repo.activeWalk(widget.padId);
    } catch (e) {
      error = 'Сервер недоступен. Используются данные, сохранённые в приложении.';
      final local = demoPads.where((p) => p.id == widget.padId).firstOrNull;
      if (local != null) { padName = local.name; padType = local.type; wells = local.wells; }
      final statusMap = await repo.allWellStatuses();
      wells = wells.map((w) => statusMap[w.id] == null ? w : Well(id:w.id, number:w.number, type:w.type, status:statusMap[w.id]!, pkvWork:w.pkvWork, pkvIdle:w.pkvIdle, rtr:w.rtr, rz:w.rz, frequency:w.frequency, current:w.current, load:w.load, rp:w.rp, tPed:w.tPed, rInsul:w.rInsul, pkvInstalled:w.pkvInstalled, pidInstalled:w.pidInstalled)).toList();
      checked = await repo.checkedCount(widget.padId);
      active = await repo.activeWalk(widget.padId);
    } finally { if (mounted) setState(() => loading = false); }
  }

  Well _wellFromJson(Map<String, dynamic> row) {
    final type = row['type'] == 'gas_condensate' ? WellType.gasCondensate : WellType.oil;
    final status = switch (row['status']) {
      'Остановлена' => WellStatus.stopped,
      'ВНР' => WellStatus.workover,
      _ => WellStatus.working,
    };
    return Well(id: row['id'].toString(), number: row['number'].toString(), type: type, status: status);
  }

  Future<void> _startOrResume() async {
    if (wells.isEmpty) return;
    final index = (active?['current_index'] as int?) ?? 0;
    await repo.saveWalk(widget.padId, index);
    if (mounted) context.push('/walk/pad/${widget.padId}/step/$index');
  }

  @override Widget build(BuildContext context) {
    if (loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    final problems = wells.where((w) => w.status == WellStatus.stopped).length;
    final hasResume = active != null;
    final safeIndex = wells.isEmpty ? 0 : (active?['current_index'] as int? ?? 0).clamp(0, wells.length - 1).toInt();
    return Scaffold(
      appBar: AppBar(title: Text(padName)),
      body: ListView(padding: const EdgeInsets.fromLTRB(16,4,16,24), children: [
        Text(padType, style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
        if (error != null) Padding(padding: const EdgeInsets.symmetric(vertical: 10), child: Text(error!, style: const TextStyle(color: Colors.orange))),
        const SizedBox(height: 8),
        Row(children: [Expanded(child: _stat('Скважин','${wells.length}')), const SizedBox(width:8), Expanded(child: _stat('Проверено','$checked')), const SizedBox(width:8), Expanded(child: _stat('Внимание','$problems'))]),
        const SizedBox(height:16),
        const SizedBox(height:20), const Text('Скважины', style: TextStyle(fontSize:20,fontWeight:FontWeight.w800)), const SizedBox(height:10),
        ...wells.map((w) => _wellTile(context, w)),
      ]),
    );
  }
  Widget _stat(String l,String v)=>Card(margin:EdgeInsets.zero,child:Padding(padding:const EdgeInsets.all(12),child:Column(children:[Text(l,style:TextStyle(fontSize:11,color:Theme.of(context).colorScheme.onSurfaceVariant)),const SizedBox(height:4),Text(v,style:const TextStyle(fontSize:20,fontWeight:FontWeight.w800))])));
  Widget _wellTile(BuildContext context, Well well){
    final (label,kind)=switch(well.status){
      WellStatus.stopped=>('Остановлена',StatusKind.problem),
      WellStatus.workover=>('ВНР',StatusKind.warning),
      WellStatus.working=>('В работе',StatusKind.ok),
    };
    return Card(margin:const EdgeInsets.only(bottom:8),child:ListTile(onTap:()=>context.push('/wells/pad/${widget.padId}/card/${well.id}'),title:Text('Скважина ${well.number}',style:const TextStyle(fontWeight:FontWeight.w700)),subtitle:well.pkvWork!=null?Text('ПКВ ${well.pkvWork}/${well.pkvIdle} · цикл ${well.pkvCycle} мин'):null,trailing:StatusChip(label:label,kind:kind)));
  }
}
