import 'dart:io';
import 'package:excel/excel.dart';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import '../models/measurement.dart';
import '../models/production_area.dart';
import '../models/well.dart';
import '../models/work_task.dart';

class ExportService {
 static Future<File> createChessXlsx({required List<Measurement> measurements})async{
  final book=Excel.createExcel();book.delete('Sheet1');
  for(final area in demoAreas){
   final ms=measurements.where((m)=>area.padIds.contains(m.padId)).toList()..sort((a,b)=>a.measuredAt.compareTo(b.measuredAt));
   final sheet=book[_safeSheet(area.name)];
   final dates=<DateTime>[];for(final m in ms){if(!dates.any((d)=>_sameMinute(d,m.measuredAt)))dates.add(m.measuredAt);}
   sheet.appendRow([TextCellValue('Кустовая площадка'),TextCellValue('Скважина'),TextCellValue('Параметр'),...dates.map((d)=>TextCellValue(DateFormat('dd.MM.yy\nHH:mm').format(d)))]);
   var row=1;var wellIndex=0;
   for(final pad in area.pads){
    final padMs=ms.where((m)=>m.padId==pad.id).toList();
    for(final well in pad.wells){
     final wm=padMs.where((m)=>m.wellId==well.id).toList();
     for(final spec in _specs(well.type)){
      sheet.appendRow([TextCellValue(pad.name),TextCellValue(well.number),TextCellValue(spec.$2),...dates.map((d){final matches=wm.where((x)=>_sameMinute(x.measuredAt,d));final m=matches.isEmpty?null:matches.first;return _cell(m==null?null:spec.$3(m));})]);
      _paintRow(sheet,row,wellIndex);row++;
     }
     wellIndex++;
    }
   }
   _paintHeader(sheet,dates.length+3);
   sheet.setColumnWidth(0,20);sheet.setColumnWidth(1,14);sheet.setColumnWidth(2,22);
   for(var c=3;c<dates.length+3;c++)sheet.setColumnWidth(c,15);
  }
  return _save(book,'Нефтяник_шахматка');
 }

 static Future<File> createComparisonXlsx({required List<Measurement> measurements,required ProductionArea area,required DateTime firstDate,required DateTime secondDate})async{
  final book=Excel.createExcel();book.delete('Sheet1');final sheet=book[_safeSheet(area.name)];
  final specs=<String,String>{};for(final p in area.pads){for(final w in p.wells){for(final s in _specs(w.type)){specs[s.$1]=s.$2;}}}
  final ordered=specs.entries.toList();
  final head1=['Куст','Скважина',...ordered.map((e)=>e.value)];
  sheet.appendRow([TextCellValue(''),TextCellValue(''),...List.generate(ordered.length,(i)=>TextCellValue(DateFormat('dd.MM.yyyy').format(firstDate))),...List.generate(ordered.length,(i)=>TextCellValue(DateFormat('dd.MM.yyyy').format(secondDate))),...List.generate(ordered.length,(i)=>TextCellValue('ДЕЛЬТА'))]);
  sheet.appendRow([TextCellValue('Куст'),TextCellValue('Скважина'),...ordered.map((e)=>TextCellValue(e.value)),...ordered.map((e)=>TextCellValue(e.value)),...ordered.map((e)=>TextCellValue(e.value))]);
  var row=2;var wi=0;
  for(final pad in area.pads){for(final well in pad.wells){
   final wm=measurements.where((m)=>m.padId==pad.id&&m.wellId==well.id).toList();
   final m1=_forDay(wm,firstDate),m2=_forDay(wm,secondDate);
   final map1=_values(well.type,m1),map2=_values(well.type,m2);
   final cells=<CellValue>[TextCellValue(pad.name),TextCellValue(well.number)];
   cells.addAll(ordered.map((e)=>_cell(map1[e.key])));cells.addAll(ordered.map((e)=>_cell(map2[e.key])));
   cells.addAll(ordered.map((e){final a=map1[e.key],b=map2[e.key];return _cell(a is num&&b is num?b-a:null);}));
   sheet.appendRow(cells);_paintRow(sheet,row,wi);row++;wi++;
  }}
  _paintHeader(sheet,2+ordered.length*3);sheet.setColumnWidth(0,18);sheet.setColumnWidth(1,13);for(var c=2;c<2+ordered.length*3;c++)sheet.setColumnWidth(c,13);
  return _save(book,'Замерная_${_file(area.name)}_${DateFormat('ddMMyy').format(firstDate)}_${DateFormat('ddMMyy').format(secondDate)}');
 }

 static Measurement? _forDay(List<Measurement> ms,DateTime d){final x=ms.where((m)=>m.measuredAt.year==d.year&&m.measuredAt.month==d.month&&m.measuredAt.day==d.day).toList()..sort((a,b)=>b.measuredAt.compareTo(a.measuredAt));return x.isEmpty?null:x.first;}
 static Map<String,dynamic> _values(WellType t,Measurement? m){if(m==null)return {};return {for(final s in _specs(t))s.$1:s.$3(m)};}
 static List<(String,String,dynamic Function(Measurement))> _specs(WellType t)=>t==WellType.gasCondensate?[
  ('rbuf','Рбуф, МПа',(m)=>m.rBuf),('rtr','Ртр, МПа',(m)=>m.rtr),('rline','Рлин, МПа',(m)=>m.rLine),('tb','Тдо штуцера, °C',(m)=>m.tBeforeChoke),('tl','Тлин, °C',(m)=>m.tLine),('rd','Рузд, МПа',(m)=>m.rDownhole),('td','Тузд, °C',(m)=>m.tDownhole),('rko','Рко, МПа',(m)=>m.rKo),('inh','Ингибитор, л/ч',(m)=>m.inhibitorFeed)
 ]:[('rtr','Ртр, кгс/см²',(m)=>m.rtr),('rz','Рз, кгс/см²',(m)=>m.rz),('f','F, Гц',(m)=>m.frequency),('i','Iср, А',(m)=>m.current),('load','Загрузка, %',(m)=>m.load),('rp','Рпр, атм',(m)=>m.rp),('tped','Тпэд, °C',(m)=>m.tPed),('riz','Rизол, кОм',(m)=>m.rInsul)];
 static void _paintHeader(Sheet s,int cols){for(var c=0;c<cols;c++){s.cell(CellIndex.indexByColumnRow(columnIndex:c,rowIndex:0)).cellStyle=CellStyle(bold:true,backgroundColorHex:ExcelColor.fromHexString('#D9EAF7'),horizontalAlign:HorizontalAlign.Center,verticalAlign:VerticalAlign.Center);}}
 static void _paintRow(Sheet s,int row,int wellIndex){final color=wellIndex.isEven?'#F3F8FC':'#E7F1F8';for(var c=0;c<80;c++){final cell=s.cell(CellIndex.indexByColumnRow(columnIndex:c,rowIndex:row));cell.cellStyle=CellStyle(backgroundColorHex:ExcelColor.fromHexString(color),verticalAlign:VerticalAlign.Center);}}
 static Future<File> _save(Excel book,String name)async{final dir=await getTemporaryDirectory();final f=File('${dir.path}/$name.xlsx');final bytes=book.encode();if(bytes==null)throw StateError('Не удалось сформировать Excel');await f.writeAsBytes(bytes,flush:true);return f;}
 static bool _sameMinute(DateTime a,DateTime b)=>a.year==b.year&&a.month==b.month&&a.day==b.day&&a.hour==b.hour&&a.minute==b.minute;
 static String _safeSheet(String s){final x=s.replaceAll(RegExp(r'[\\/*?:\[\]]'),' ').trim();return x.length>31?x.substring(0,31):x;}
 static String _file(String s)=>s.replaceAll(RegExp(r'[^A-Za-zА-Яа-я0-9_-]'),'_');
 static CellValue _cell(dynamic v){if(v==null)return TextCellValue('');if(v is int)return IntCellValue(v);if(v is double)return DoubleCellValue(v);if(v is num)return DoubleCellValue(v.toDouble());return TextCellValue(v.toString());}
 static Future<File> createTaskJournalXlsx({required List<WorkTask> tasks})async{
  final book=Excel.createExcel();book.delete('Sheet1');final sheet=book['Журнал заданий'];
  sheet.appendRow(['Участок','Кустовая площадка','Сотрудник / получатель','Задание','Кто выдал','Дата и время выдачи','Кто выполнил','Дата и время выполнения','Подтверждение','Кто подтвердил','Дата и время подтверждения'].map(TextCellValue.new).toList());
  final rows=tasks.where((t)=>t.status==WorkTaskStatus.confirmed).toList()..sort((a,b){final x=(a.areaName??'').compareTo(b.areaName??'');if(x!=0)return x;final y=(a.padName??'').compareTo(b.padName??'');if(y!=0)return y;return a.targetName.compareTo(b.targetName);});
  var r=1;String? lastArea,lastPad,lastPerson;
  for(final t in rows){final area=t.areaName??(t.targetType==WorkTaskTarget.area?t.targetName:'—');final pad=t.padName??(t.targetType==WorkTaskTarget.pad?t.targetName:'—');final person=t.targetType==WorkTaskTarget.personal?t.targetName:(t.completedBy??'Общее задание');
    sheet.appendRow([area,pad,person,t.title,t.createdBy,_dateTime(t.createdAt),t.completedBy??'',t.completedAt==null?'':_dateTime(t.completedAt!),t.confirmedAt==null?'Не подтверждено':'Подтверждено',t.confirmedBy??'',t.confirmedAt==null?'':_dateTime(t.confirmedAt!)].map(TextCellValue.new).toList());
    final boundary=area!=lastArea||pad!=lastPad||person!=lastPerson;final color=boundary?'#D9EAF7':(r.isEven?'#F3F8FC':'#FFFFFF');for(var c=0;c<11;c++)sheet.cell(CellIndex.indexByColumnRow(columnIndex:c,rowIndex:r)).cellStyle=CellStyle(backgroundColorHex:ExcelColor.fromHexString(color),verticalAlign:VerticalAlign.Center);lastArea=area;lastPad=pad;lastPerson=person;r++;
  }
  _paintHeader(sheet,11);for(var c=0;c<11;c++)sheet.setColumnWidth(c,c==3?32:22);return _save(book,'Журнал_заданий_${DateFormat('ddMMyyyy').format(DateTime.now())}');
 }
 static String _dateTime(DateTime d)=>DateFormat('dd.MM.yyyy HH:mm').format(d);
 static Future<void> shareXlsx(File file)async=>Share.shareXFiles([XFile(file.path)],text:'Excel — Нефтяник');
}
