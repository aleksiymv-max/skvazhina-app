enum UserRole { operator, engineer, shopChief, manager, admin }

enum ItrSubrole { leadingGeologist, leadingTechnologist, geologist, technologist, master }

extension ItrSubroleX on ItrSubrole {
  String get label => switch (this) {
    ItrSubrole.leadingGeologist => 'Ведущий геолог',
    ItrSubrole.leadingTechnologist => 'Ведущий технолог',
    ItrSubrole.geologist => 'Геолог',
    ItrSubrole.technologist => 'Технолог',
    ItrSubrole.master => 'Мастер',
  };
}

extension UserRoleX on UserRole {
  String get label => switch (this) {
    UserRole.operator => 'Оператор ДНГ',
    UserRole.engineer => 'ИТР',
    UserRole.shopChief => 'Начальник цеха',
    UserRole.manager => 'Руководитель',
    UserRole.admin => 'Администратор',
  };
}

class AppUser {
  const AppUser({required this.id, required this.name, required this.role, this.itrSubrole, this.chiefId, this.approved = true});
  final String id;
  final String name;
  final UserRole role;
  final ItrSubrole? itrSubrole;
  final String? chiefId;
  final bool approved;

  bool get canCorrect => role == UserRole.engineer || role == UserRole.shopChief || role == UserRole.admin;
  bool get canExport => role != UserRole.operator;
  bool get canCreatePads => role == UserRole.engineer || role == UserRole.shopChief || role == UserRole.admin;
  bool get canDeletePads => role == UserRole.engineer || role == UserRole.shopChief || role == UserRole.admin;
  bool get isChief => role == UserRole.shopChief;
}
