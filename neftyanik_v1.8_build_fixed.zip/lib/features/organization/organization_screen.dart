import 'package:flutter/material.dart';
import '../../core/models/pad.dart';
import '../../core/models/user.dart';
import '../../core/services/session_service.dart';

class OrganizationScreen extends StatefulWidget { const OrganizationScreen({super.key}); @override State<OrganizationScreen> createState()=>_OrganizationScreenState(); }
class _OrganizationScreenState extends State<OrganizationScreen>{
  final field=TextEditingController(text:'Чаяндинское НГКМ');
  @override
  Widget build(BuildContext context) {
    final s = SessionService.instance;
    final chief = s.currentUser.isChief;
    final chiefId = chief ? s.currentUser.id : (s.currentUser.chiefId ?? 'chief-001');
    final workers = s.workersForChief(chiefId);
    final pending = s.pendingForChief(chiefId);
    return Scaffold(
      appBar: AppBar(title: const Text('Управление месторождением')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Месторождение', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 10),
                  TextField(controller: field, enabled: chief, decoration: const InputDecoration(labelText: 'Название')),
                  if (chief)
                    Padding(
                      padding: const EdgeInsets.only(top: 10),
                      child: FilledButton.icon(
                        onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Месторождение сохранено локально'))),
                        icon: const Icon(Icons.save),
                        label: const Text('Сохранить месторождение'),
                      ),
                    ),
                ],
              ),
            ),
          ),
          if (chief)
            _section(
              'Подчинённые · ${workers.length}',
              workers.map((u) => ListTile(
                contentPadding: EdgeInsets.zero,
                leading: CircleAvatar(child: Icon(u.role == UserRole.engineer ? Icons.engineering : Icons.person)),
                title: Text(u.name),
                subtitle: Text(u.role == UserRole.engineer ? '${u.role.label} · ${u.itrSubrole?.label ?? ''}' : u.role.label),
                trailing: const Icon(Icons.verified_outlined),
              )).toList(),
            ),
          if (chief && pending.isNotEmpty)
            _section(
              'Ожидают подтверждения',
              pending.map((u) => Card(
                child: ListTile(
                  title: Text(u.name),
                  subtitle: Text('${u.role.label}${u.itrSubrole == null ? '' : ' · ${u.itrSubrole!.label}'}'),
                  trailing: FilledButton(
                    onPressed: () => setState(() => s.approve(u.id)),
                    child: const Text('Подтвердить'),
                  ),
                ),
              )).toList(),
            ),
          _section(
            'Кустовые площадки',
            demoPads.map((p) => ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.location_on_outlined),
              title: Text(p.name),
              subtitle: Text('${p.wells.length} скважин'),
              trailing: chief
                  ? IconButton(
                      onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Удаление доступно только начальнику цеха'))),
                      icon: const Icon(Icons.delete_outline),
                    )
                  : null,
            )).toList(),
          ),
          if (s.currentUser.canCreatePads)
            FilledButton.icon(onPressed: () => _addPad(context), icon: const Icon(Icons.add), label: const Text('Создать кустовую площадку')),
          if (s.currentUser.canCreatePads)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: OutlinedButton.icon(onPressed: () => _addWell(context), icon: const Icon(Icons.add_circle_outline), label: const Text('Создать скважину')),
            ),
        ],
      ),
    );
  }
  Widget _section(String t,List<Widget> c)=>Card(margin:const EdgeInsets.only(bottom:12),child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(t,style:const TextStyle(fontWeight:FontWeight.w800,fontSize:17)),const SizedBox(height:8),...c])));
  Future<void> _addPad(BuildContext context)async{final c=TextEditingController();final ok=await showDialog<bool>(context:context,builder:(_)=>AlertDialog(title:const Text('Новая кустовая площадка'),content:TextField(controller:c,decoration:const InputDecoration(labelText:'Название')),actions:[TextButton(onPressed:()=>Navigator.pop(context,false),child:const Text('Отмена')),FilledButton(onPressed:()=>Navigator.pop(context,true),child:const Text('Создать'))]));if(ok==true&&c.text.trim().isNotEmpty&&mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Кустовая площадка «${c.text.trim()}» создана локально')));c.dispose();}
  Future<void> _addWell(BuildContext context)async{final c=TextEditingController();final ok=await showDialog<bool>(context:context,builder:(_)=>AlertDialog(title:const Text('Новая скважина'),content:TextField(controller:c,decoration:const InputDecoration(labelText:'Номер скважины')),actions:[TextButton(onPressed:()=>Navigator.pop(context,false),child:const Text('Отмена')),FilledButton(onPressed:()=>Navigator.pop(context,true),child:const Text('Создать'))]));if(ok==true&&c.text.trim().isNotEmpty&&mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Скважина ${c.text.trim()} создана локально')));c.dispose();}
}
