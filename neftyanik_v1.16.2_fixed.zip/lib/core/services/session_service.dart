import '../models/user.dart';
import '../network/api_client.dart';

class OilFieldRegistration {
  OilFieldRegistration({required this.id,required this.name,required this.approved});
  final String id,name; bool approved;
}
class PendingUser {
  PendingUser({required this.id,required this.name,required this.role,this.subrole,required this.fieldId,this.requiresAdmin=false});
  final String id,name,fieldId; final UserRole role; final ItrSubrole? subrole; final bool requiresAdmin; bool approved=false;
}
class SessionService {
  SessionService._(); static final instance=SessionService._();
  AppUser currentUser=const AppUser(id:'op-001',name:'Оператор ДНГ',role:UserRole.operator,chiefId:'chief-001');
  final ApiClient api=ApiClient.instance; String? get token=>api.token;
  final List<OilFieldRegistration> fields=[OilFieldRegistration(id:'field-1',name:'Чаяндинское НГКМ',approved:true)];
  final Map<String,String> userFields={'chief-001':'field-1','eng-001':'field-1','op-001':'field-1','op-002':'field-1'};
  final List<AppUser> _workers=[const AppUser(id:'chief-001',name:'Иванов Алексей Николаевич',role:UserRole.shopChief),const AppUser(id:'eng-001',name:'Петров Сергей Андреевич',role:UserRole.engineer,itrSubrole:ItrSubrole.leadingGeologist,chiefId:'chief-001'),const AppUser(id:'op-001',name:'Смирнов Дмитрий Олегович',role:UserRole.operator,chiefId:'chief-001'),const AppUser(id:'op-002',name:'Кузнецов Максим Игоревич',role:UserRole.operator,chiefId:'chief-001')];
  final List<PendingUser> pendingUsers=[];
  List<OilFieldRegistration> get approvedFields=>fields.where((f)=>f.approved).toList();
  List<AppUser> get approvedWorkers=>List.unmodifiable(_workers.where((u)=>u.approved));
  List<AppUser> chiefsForField(String fieldId)=>_workers.where((u)=>u.role==UserRole.shopChief&&userFields[u.id]==fieldId).toList();
  List<AppUser> workersForChief(String chiefId)=>_workers.where((u)=>u.chiefId==chiefId&&u.approved).toList();
  List<PendingUser> pendingForChief(String chiefId){final field=userFields[chiefId];return pendingUsers.where((u)=>u.fieldId==field&&!u.approved&&!u.requiresAdmin).toList();}
  List<PendingUser> get pendingForAdmin=>pendingUsers.where((u)=>!u.approved&&u.requiresAdmin).toList();
  Future<void> logout()async{api.token=null;currentUser=const AppUser(id:'',name:'',role:UserRole.operator,approved:false);}
  Future<void> login(String username,String password)async{const demo=<String,Map<String,String>>{'chief-001':{'password':'chief','name':'Иванов Алексей Николаевич','role':'shopChief'},'op-001':{'password':'operator','name':'Смирнов Дмитрий Олегович','role':'operator'},'eng-001':{'password':'engineer','name':'Петров Сергей Андреевич','role':'engineer'},'op-002':{'password':'operator','name':'Кузнецов Максим Игоревич','role':'operator'},'adm-001':{'password':'admin','name':'Администратор','role':'admin'}};final record=demo[username];if(record==null||record['password']!=password)throw const ApiException('Неверный логин или пароль');final role=UserRole.values.firstWhere((r)=>r.name==record['role']);final saved=_workers.where((u)=>u.id==username).firstOrNull;if(saved!=null&&!saved.approved)throw const ApiException('Регистрация ожидает согласования');currentUser=AppUser(id:username,name:record['name']!,role:role,chiefId:saved?.chiefId,itrSubrole:saved?.itrSubrole,approved:true);api.token='offline-$username';}
  Future<String> register({required String name,required UserRole role,ItrSubrole? subrole,required String fieldId,String? newFieldName})async{
    var actualField=fieldId;var adminApproval=role==UserRole.shopChief;
    if(fieldId=='new'){final title=(newFieldName??'').trim();if(title.isEmpty)throw const ApiException('Введите название месторождения');actualField='field-${DateTime.now().millisecondsSinceEpoch}';fields.add(OilFieldRegistration(id:actualField,name:title,approved:false));adminApproval=true;}
    final id='${role.name}-${DateTime.now().millisecondsSinceEpoch}';pendingUsers.add(PendingUser(id:id,name:name,role:role,subrole:subrole,fieldId:actualField,requiresAdmin:adminApproval));return id;
  }
  void approve(String id){final p=pendingUsers.where((u)=>u.id==id).firstOrNull;if(p==null)return;p.approved=true;final chief=chiefsForField(p.fieldId).firstOrNull;_workers.add(AppUser(id:p.id,name:p.name,role:p.role,itrSubrole:p.subrole,chiefId:p.role==UserRole.shopChief?null:chief?.id,approved:true));userFields[p.id]=p.fieldId;if(p.role==UserRole.shopChief){final f=fields.where((x)=>x.id==p.fieldId).firstOrNull;if(f!=null)f.approved=true;}}
}
