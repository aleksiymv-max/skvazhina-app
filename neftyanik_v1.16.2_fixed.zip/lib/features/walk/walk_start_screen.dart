import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../core/models/production_area.dart';

class WalkStartScreen extends StatelessWidget {
  const WalkStartScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Новый обход')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Выберите кустовую площадку', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
          const SizedBox(height: 6),
          const Text('Сначала выберите участок добычи, затем куст. Откройте карточку кустовой площадки, проверьте состав фонда и затем начните обход.', style: TextStyle(color: Colors.black54)),
          const SizedBox(height: 14),
          ...demoAreas.map((area) => Card(
            child: ExpansionTile(
              leading: const CircleAvatar(child: Icon(Icons.location_on_outlined)),
              title: Text(area.name, style: const TextStyle(fontWeight: FontWeight.w800)),
              subtitle: Text('${area.pads.length} кустовых площадок'),
              children: area.pads.map((pad) => ListTile(
                contentPadding: const EdgeInsets.only(left: 28, right: 16),
                leading: const Icon(Icons.factory_outlined),
                title: Text(pad.name, style: const TextStyle(fontWeight: FontWeight.w700)),
                subtitle: Text('${pad.wells.length} скважин'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => context.push('/walk/pad/${pad.id}'),
              )).toList(),
            ),
          )),
        ],
      ),
    );
  }
}
