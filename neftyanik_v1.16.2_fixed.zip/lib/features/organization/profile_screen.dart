import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../core/models/user.dart';
import '../../core/services/session_service.dart';

class ProfileScreen extends StatefulWidget { const ProfileScreen({super.key}); @override State<ProfileScreen> createState()=>_ProfileScreenState(); }
class _ProfileScreenState extends State<ProfileScreen> {
  String photoMode='none';
  @override Widget build(BuildContext context){final u=SessionService.instance.currentUser;final position=u.role==UserRole.engineer?(u.itrSubrole?.label??'ИТР'):u.role.label;return Scaffold(appBar:AppBar(title:const Text('Профиль')),body:ListView(padding:const EdgeInsets.all(16),children:[
    Center(child:Stack(children:[CircleAvatar(radius:58,backgroundColor:const Color(0xFFE1EFFF),child:Icon(photoMode=='none'?Icons.person_outline:Icons.person,size:64,color:Theme.of(context).colorScheme.primary)),Positioned(right:0,bottom:0,child:IconButton.filled(onPressed:_changePhoto,icon:const Icon(Icons.photo_camera_outlined)))])),
    const SizedBox(height:14),Center(child:Text(u.name,style:const TextStyle(fontSize:21,fontWeight:FontWeight.w900))),Center(child:Text(position,style:const TextStyle(color:Colors.black54))),const SizedBox(height:20),
    Card(child:Column(children:[ListTile(leading:const Icon(Icons.badge_outlined),title:const Text('ФИО'),subtitle:Text(u.name)),const Divider(height:1),ListTile(leading:const Icon(Icons.work_outline),title:const Text('Должность'),subtitle:Text(position)),const Divider(height:1),ListTile(leading:const Icon(Icons.business_outlined),title:const Text('Подразделение'),subtitle:const Text('Добыча нефти и газа'))])),
    const SizedBox(height:12),OutlinedButton.icon(onPressed:_changePhoto,icon:const Icon(Icons.add_a_photo_outlined),label:const Text('Изменить фотографию')),
    const SizedBox(height:8),OutlinedButton.icon(style:OutlinedButton.styleFrom(foregroundColor:Colors.red),onPressed:()async{await SessionService.instance.logout();if(context.mounted)context.go('/login');},icon:const Icon(Icons.logout),label:const Text('Выйти из приложения')),
  ]));}
  Future<void> _changePhoto()async{final action=await showModalBottomSheet<String>(context:context,builder:(_)=>SafeArea(child:Wrap(children:[const ListTile(title:Text('Фотография профиля',style:TextStyle(fontWeight:FontWeight.w800))),ListTile(leading:const Icon(Icons.photo_library_outlined),title:const Text('Выбрать фотографию'),onTap:()=>Navigator.pop(context,'gallery')),ListTile(leading:const Icon(Icons.camera_alt_outlined),title:const Text('Сделать фотографию'),onTap:()=>Navigator.pop(context,'camera'))])));if(action!=null&&mounted){setState(()=>photoMode=action);ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Выбор файла будет подключён к галерее телефона в следующем этапе.')));}}
}
