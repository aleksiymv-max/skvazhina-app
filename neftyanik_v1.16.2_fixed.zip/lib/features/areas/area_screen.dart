import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../core/models/production_area.dart';
import '../../core/models/well.dart';

class AreaScreen extends StatelessWidget {
  const AreaScreen({super.key, required this.areaId});
  final String areaId;

  @override
  Widget build(BuildContext context) {
    final area = demoAreas.firstWhere((a) => a.id == areaId, orElse: () => demoAreas.first);
    final pads = area.pads;
    final wells = pads.expand((p) => p.wells).toList();
    final oil = wells.where((w) => w.type == WellType.oil).length;
    final gas = wells.length - oil;
    return Scaffold(
      appBar: AppBar(title: Text(area.name)),
      body: ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 24), children: [
        Row(children: [
          Expanded(child: _stat('Кустов', pads.length.toString())),
          const SizedBox(width: 10),
          Expanded(child: _stat('Скважин', wells.length.toString())),
          const SizedBox(width: 10),
          Expanded(child: _stat('Нефть / газ', '$oil / $gas')),
        ]),
        const SizedBox(height: 18),
        const Text('Кустовые площадки', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
        const SizedBox(height: 8),
        ...pads.map((pad) => Card(child: ListTile(
          leading: CircleAvatar(backgroundColor: Theme.of(context).colorScheme.primaryContainer, child: const Icon(Icons.factory_outlined)),
          title: Text(pad.name, style: const TextStyle(fontWeight: FontWeight.w800)),
          subtitle: Text('${pad.wells.length} скважин · ${pad.wells.where((w) => w.type == WellType.oil).length} нефтяных · ${pad.wells.where((w) => w.type == WellType.gasCondensate).length} газовых'),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => context.push('/wells/pad/${pad.id}'),
        ))),
      ]),
    );
  }

  Widget _stat(String label, String value) => Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(children: [Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)), const SizedBox(height: 3), Text(label, style: const TextStyle(fontSize: 11, color: Colors.black54))])));
}
