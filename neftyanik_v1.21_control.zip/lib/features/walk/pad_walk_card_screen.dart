import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../core/models/pad.dart';
import '../../core/models/well.dart';
import '../../core/models/work_task.dart';

class PadWalkCardScreen extends StatelessWidget {
  const PadWalkCardScreen({super.key, required this.padId});
  final String padId;
  @override Widget build(BuildContext context){
    final pad=demoPads.firstWhere((p)=>p.id==padId);
    final working=pad.wells.where((w)=>w.status==WellStatus.working).length;
    final tasks=WorkTaskStore.instance.tasks.where((t)=>t.status!=WorkTaskStatus.confirmed&&((t.targetType==WorkTaskTarget.pad&&t.targetId==pad.id)||(t.targetType==WorkTaskTarget.area&&t.targetId==pad.areaId))).toList();
    return Scaffold(appBar:AppBar(title:Text(pad.name)),body:ListView(padding:const EdgeInsets.all(16),children:[
      Card(child:Padding(padding:const EdgeInsets.all(18),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text(pad.name,style:const TextStyle(fontSize:24,fontWeight:FontWeight.w900)),const SizedBox(height:4),Text(pad.areaName),const SizedBox(height:14),
        Wrap(spacing:8,runSpacing:8,children:[_stat('Фонд','${pad.wells.length}'),_stat('В работе','$working'),_stat('Тип',pad.type)]),
      ]))),
      const SizedBox(height:14),const Text('Задания',style:TextStyle(fontSize:19,fontWeight:FontWeight.w900)),const SizedBox(height:8),if(tasks.isEmpty)const Card(child:Padding(padding:EdgeInsets.all(14),child:Text('Активных заданий нет.'))),...tasks.map((t)=>Card(child:ListTile(leading:const Icon(Icons.task_alt),title:Text(t.title),subtitle:Text(t.description)))),const SizedBox(height:14),const Text('Скважины кустовой площадки',style:TextStyle(fontSize:19,fontWeight:FontWeight.w900)),const SizedBox(height:8),
      ...pad.wells.map((w)=>Card(child:ListTile(leading:CircleAvatar(child:Text(w.number.length>3?w.number.substring(w.number.length-3):w.number)),title:Text('Скважина ${w.number}',style:const TextStyle(fontWeight:FontWeight.w800)),subtitle:Text(_status(w.status)),trailing:const Icon(Icons.chevron_right),onTap:()=>context.push('/walk/pad/${pad.id}/well/${w.id}')))),
      const SizedBox(height:18),FilledButton.icon(onPressed:pad.wells.isEmpty?null:()=>context.push('/walk/pad/${pad.id}/step/0'),icon:const Icon(Icons.play_arrow_rounded),label:const Padding(padding:EdgeInsets.symmetric(vertical:13),child:Text('Начать обход'))),
    ]));
  }
  Widget _stat(String a,String b)=>Container(padding:const EdgeInsets.symmetric(horizontal:12,vertical:10),decoration:BoxDecoration(color:const Color(0xFFF2F7FF),borderRadius:BorderRadius.circular(12)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(a,style:const TextStyle(fontSize:11,color:Colors.black54)),Text(b,style:const TextStyle(fontWeight:FontWeight.w800))]));
  String _status(WellStatus s)=>switch(s){WellStatus.working=>'В работе',WellStatus.workover=>'ВНР',WellStatus.stopped=>'Остановлена'};
}
