import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../core/models/measurement.dart';
import '../../core/models/pad.dart';
import '../../core/models/production_area.dart';
import '../../core/models/well.dart';
import '../../core/repositories/measurement_repository.dart';
import '../../core/services/session_service.dart';
import '../../core/services/export_service.dart';
import '../../core/models/work_task.dart';
import '../corrections/correction_screen.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});
  @override State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  final repo = MeasurementRepository();
  String? padId, wellId, selectedDate;
  List<Measurement> items = [];
  bool loading = false;
  Pad? get pad => padId == null ? null : demoPads.where((p) => p.id == padId).firstOrNull;
  Well? get well => pad?.wells.where((w) => w.id == wellId).firstOrNull;

  @override void initState() { super.initState(); padId = demoPads.first.id; _setWell(); _load(); }
  void _setWell() { final ws = pad?.wells ?? const <Well>[]; wellId = ws.isEmpty ? null : ws.first.id; selectedDate = null; }
  Future<void> _load() async { setState(() => loading = true); items = wellId == null ? [] : await repo.history(wellId: wellId, limit: 500); if (mounted) setState(() => loading = false); }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('История'), actions: [if (SessionService.instance.currentUser.canExport) PopupMenuButton<String>(onSelected: _exportAction, itemBuilder: (_) => const [PopupMenuItem(value:'save',child:ListTile(leading:Icon(Icons.table_view_outlined),title:Text('Выгрузить Excel'))),PopupMenuItem(value:'compare',child:ListTile(leading:Icon(Icons.compare_arrows),title:Text('Составить замерную'))),PopupMenuItem(value:'tasks',child:ListTile(leading:Icon(Icons.assignment_outlined),title:Text('Выгрузить журнал заданий')))])]),
    body: DefaultTabController(
      length: 3,
      child: Column(children: [
        const TabBar(isScrollable:true,tabs: [Tab(text: 'Параметры'), Tab(text: 'Задания'), Tab(text:'Проблемы')]),
        Expanded(child: TabBarView(children: [
          ListView(padding: const EdgeInsets.all(16), children: [
            const Text('Выбор скважины', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)), const SizedBox(height: 10),
            DropdownButtonFormField<String>(value: padId, decoration: const InputDecoration(labelText: 'Кустовая площадка'), items: demoPads.map((p) => DropdownMenuItem(value: p.id, child: Text(p.name))).toList(), onChanged: (v) { setState(() { padId = v; _setWell(); }); _load(); }),
            const SizedBox(height: 10),
            DropdownButtonFormField<String>(value: wellId, decoration: const InputDecoration(labelText: 'Скважина'), items: (pad?.wells ?? const <Well>[]).map((w) => DropdownMenuItem(value: w.id, child: Text('Скважина ${w.number} · ${w.type == WellType.oil ? 'нефтяная' : 'газовая'}'))).toList(), onChanged: (v) { setState(() { wellId = v; selectedDate = null; }); _load(); }),
            const SizedBox(height: 18),
            if (well != null) Text('Замеры скважины ${well!.number}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            if (loading) const Center(child: Padding(padding: EdgeInsets.all(24), child: CircularProgressIndicator()))
            else if (items.isEmpty) const Card(child: Padding(padding: EdgeInsets.all(18), child: Text('Для выбранной скважины замеров пока нет.')))
            else ...items.map(_dateCard),
          ]),
          _taskHistory(),
          _problemHistory(),
        ])),
      ]),
    ),
  );


  Future<void> _exportAction(String action) async {
    final all = await repo.history(limit: 10000);
    if (action == 'compare') { await _comparison(all); return; }
    if (action == 'tasks') { final file=await ExportService.createTaskJournalXlsx(tasks:WorkTaskStore.instance.tasks); await ExportService.shareXlsx(file); return; }
    final file = await ExportService.createChessXlsx(measurements: all);
    await ExportService.shareXlsx(file);
  }

  Future<void> _comparison(List<Measurement> all) async {
    var area=demoAreas.first; DateTime first=DateTime.now().subtract(const Duration(days:1)), second=DateTime.now();
    final ok=await showDialog<bool>(context:context,builder:(c)=>StatefulBuilder(builder:(c,setD)=>AlertDialog(title:const Text('Составить замерную'),content:SizedBox(width:360,child:Column(mainAxisSize:MainAxisSize.min,children:[DropdownButtonFormField<String>(value:area.id,decoration:const InputDecoration(labelText:'Участок добычи'),items:demoAreas.map((a)=>DropdownMenuItem(value:a.id,child:Text(a.name))).toList(),onChanged:(v)=>setD(()=>area=demoAreas.firstWhere((a)=>a.id==v))),const SizedBox(height:12),ListTile(contentPadding:EdgeInsets.zero,title:const Text('Дата №1'),subtitle:Text(DateFormat('dd.MM.yyyy').format(first)),trailing:const Icon(Icons.calendar_month),onTap:()async{final d=await showDatePicker(context:c,firstDate:DateTime(2020),lastDate:DateTime.now(),initialDate:first);if(d!=null)setD(()=>first=d);}),ListTile(contentPadding:EdgeInsets.zero,title:const Text('Дата №2'),subtitle:Text(DateFormat('dd.MM.yyyy').format(second)),trailing:const Icon(Icons.calendar_month),onTap:()async{final d=await showDatePicker(context:c,firstDate:DateTime(2020),lastDate:DateTime.now(),initialDate:second);if(d!=null)setD(()=>second=d);})])),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Отмена')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('Сформировать'))])));
    if(ok!=true)return; final file=await ExportService.createComparisonXlsx(measurements:all,area:area,firstDate:first,secondDate:second); await ExportService.shareXlsx(file);
  }

  Widget _taskHistory(){final done=WorkTaskStore.instance.tasks.where((t)=>t.status==WorkTaskStatus.confirmed).toList();return ListView(padding:const EdgeInsets.all(16),children:[const Text('История выполнения заданий',style:TextStyle(fontSize:20,fontWeight:FontWeight.w900)),const SizedBox(height:12),if(done.isEmpty)const Card(child:Padding(padding:EdgeInsets.all(18),child:Text('Выполненных заданий пока нет.'))),...done.map((t)=>Card(child:ListTile(leading:const CircleAvatar(child:Icon(Icons.check)),title:Text(t.title,style:const TextStyle(fontWeight:FontWeight.w800)),subtitle:Text('${t.targetName}\nВыдал: ${t.createdBy} · ${DateFormat('dd.MM.yyyy HH:mm').format(t.createdAt)}\nВыполнил: ${t.completedBy??'—'} · ${t.completedAt==null?'—':DateFormat('dd.MM.yyyy HH:mm').format(t.completedAt!)}\nПодтвердил: ${t.confirmedBy??'—'} · ${t.confirmedAt==null?'—':DateFormat('dd.MM.yyyy HH:mm').format(t.confirmedAt!)}'),isThreeLine:true))) ]);}


  Widget _problemHistory()=>FutureBuilder<List<Measurement>>(future:repo.resolvedProblems(),builder:(context,snap){final rows=snap.data??const <Measurement>[];return ListView(padding:const EdgeInsets.all(16),children:[const Text('История решённых проблем',style:TextStyle(fontSize:20,fontWeight:FontWeight.w900)),const SizedBox(height:12),if(snap.connectionState==ConnectionState.waiting)const Center(child:CircularProgressIndicator()),if(snap.connectionState!=ConnectionState.waiting&&rows.isEmpty)const Card(child:Padding(padding:EdgeInsets.all(18),child:Text('Решённых проблем пока нет.'))),...rows.map((m){final p=demoPads.where((x)=>x.id==m.padId).firstOrNull;final a=p==null?null:areaForPad(p.id);final info=[a?.name??'Участок не указан',p?.name??m.padId,m.problemNote??'Проблема','Зафиксировал: ${m.operatorName??'—'} · ${DateFormat('dd.MM.yyyy HH:mm').format(m.measuredAt)}','Решил: ${m.problemResolvedBy??'—'} · ${m.problemResolvedAt==null?'—':DateFormat('dd.MM.yyyy HH:mm').format(m.problemResolvedAt!)}'].join('\n');return Card(child:ListTile(leading:const CircleAvatar(child:Icon(Icons.task_alt)),title:Text('Скважина ${m.wellNumber}',style:const TextStyle(fontWeight:FontWeight.w800)),subtitle:Text(info)));})]);});


  Widget _dateCard(Measurement m) {
    final key = m.id?.toString() ?? m.measuredAt.toIso8601String();
    final open = selectedDate == key;
    return Card(margin: const EdgeInsets.only(bottom: 10), child: Column(children: [
      ListTile(leading: const CircleAvatar(child: Icon(Icons.calendar_today_outlined)), title: Text(DateFormat('dd.MM.yyyy').format(m.measuredAt), style: const TextStyle(fontWeight: FontWeight.w800)), subtitle: Text(DateFormat('HH:mm').format(m.measuredAt)), trailing: Icon(open ? Icons.expand_less : Icons.expand_more), onTap: () => setState(() => selectedDate = open ? null : key)),
      if (open) _details(m),
    ]));
  }

  Widget _details(Measurement m) {
    final rows = _all(m);
    return Padding(padding: const EdgeInsets.fromLTRB(16, 0, 16, 16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Divider(),
      ...rows.map((e) => Padding(padding: const EdgeInsets.symmetric(vertical: 4), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Expanded(child: Text(e.$1, style: const TextStyle(color: Colors.black54))), Expanded(flex: 2, child: Text(e.$2, style: const TextStyle(fontWeight: FontWeight.w600)))]))),
      if (SessionService.instance.currentUser.canCorrect) ...[
        const SizedBox(height: 10),
        SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: () async { final changed = await Navigator.push<bool>(context, MaterialPageRoute(builder: (_) => CorrectionScreen(measurement: m))); if (changed == true) _load(); }, icon: const Icon(Icons.edit_outlined), label: const Text('Корректировать параметры'))),
      ],
    ]));
  }

  String _f(double? v, String u) => v == null ? 'Не измерено' : '${v.toStringAsFixed(v.truncateToDouble() == v ? 0 : 2).replaceAll('.', ',')} $u';

  List<(String, String)> _all(Measurement m) {
    final common = [('Дата и время', DateFormat('dd.MM.yyyy HH:mm').format(m.measuredAt)), ('Оператор обхода', m.operatorName ?? 'Не указан')];
    if (well?.type == WellType.gasCondensate) {
      return [...common,
        ('Рбуф', _f(m.rBuf, 'МПа')), ('Ртр', _f(m.rtr, 'МПа')), ('Рлин', _f(m.rLine, 'МПа')),
        ('Тдо штуцера', _f(m.tBeforeChoke, '°C')), ('Тлин', _f(m.tLine, '°C')), ('Дросселирование', m.chokeMode ?? 'Не измерено'),
        if (m.chokeMode == 'Дроссель') ('Дроссель 1', _f(m.chokeValue, '%')), if (m.chokeMode == 'Дроссель') ('Дроссель 2', _f(m.chokeValue2, '%')), if (m.chokeMode == 'Штуцер') ('Штуцер', m.nozzle ?? 'Не измерено'),
        ('Подземная телеметрия: Рузд', _f(m.rDownhole, 'МПа')), ('Подземная телеметрия: Тузд', _f(m.tDownhole, '°C')), ('Клапан-отсекатель', m.shutoffValveInstalled ? 'Да' : 'Нет'),
        if (m.shutoffValveInstalled) ('Рко', _f(m.rKo, 'МПа')), ('Ингибитор', m.inhibitorInstalled ? 'Да' : 'Нет'), if (m.inhibitorInstalled) ('Расход ингибитора', _f(m.inhibitorFeed, 'л/ч')), ('Проблема', m.problemNote ?? 'Нет')];
    }
    return [...common,
      ('Ртр', _f(m.rtr, 'кгс/см²')), ('Рз', _f(m.rz, 'кгс/см²')), ('ПКВ установлена', m.pkvInstalled ? 'Да' : 'Нет'),
      if (m.pkvInstalled) ('ПКВ: работа', _f(m.pkvWork?.toDouble(), 'мин')), if (m.pkvInstalled) ('ПКВ: простой', _f(m.pkvIdle?.toDouble(), 'мин')), if (m.pkvInstalled) ('ПКВ: цикл', m.pkvCycle?.toString() ?? 'Не измерено'),
      ('ПИД установлена', m.pidInstalled ? 'Да' : 'Нет'), if (m.pidInstalled) ('Ток ПИД', _f(m.pidCurrent, 'А')), if (m.pidInstalled) ('Диапазон F', m.pidFrequencyRange ?? 'Не измерено'),
      if (m.pidInstalled) ('F', _f(m.frequency, 'Гц')), if (m.pidInstalled) ('Iср', _f(m.current, 'А')), if (m.pidInstalled) ('Загрузка', _f(m.load, '%')),
      ('Рпр', _f(m.rp, 'атм')), ('Тпэд', _f(m.tPed, '°C')), ('Rизол', _f(m.rInsul, 'кОм')), ('Проблема', m.problemNote ?? 'Нет')];
  }
}

