import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../features/history/history_screen.dart';
import '../features/auth/login_screen.dart';
import '../features/corrections/correction_screen.dart';
import '../features/home/home_screen.dart';
import '../features/pads/pad_screen.dart';
import '../features/wells/well_screen.dart';
import '../features/wells/well_card_screen.dart';
import '../features/organization/organization_screen.dart';
import '../features/organization/personnel_screen.dart';
import '../features/areas/area_screen.dart';
import '../features/areas/wells_hierarchy_screen.dart';
import '../features/organization/profile_screen.dart';
import '../features/walk/walk_start_screen.dart';
import '../features/walk/walk_area_screen.dart';
import '../features/walk/pad_walk_card_screen.dart';
import '../core/models/measurement.dart';
import '../core/models/pad.dart';
import '../features/walk/walk_summary_screen.dart';
import '../features/tasks/tasks_screen.dart';
import 'theme.dart';

class OilmanApp extends StatelessWidget {
  const OilmanApp({super.key, this.initializationError});
  final Object? initializationError;

  static final _rootKey = GlobalKey<NavigatorState>();
  static final GoRouter _router = GoRouter(
    navigatorKey: _rootKey,
    initialLocation: '/login',
    routes: [
      GoRoute(path: '/login', parentNavigatorKey: _rootKey, builder: (_, __) => const LoginScreen()),
      StatefulShellRoute.indexedStack(
        builder: (context, state, shell) => _MainShell(shell: shell),
        branches: [
          StatefulShellBranch(routes: [
            GoRoute(path: '/', builder: (_, __) => const HomeScreen(), routes: [
              GoRoute(path: 'area/:areaId', builder: (_, s) => AreaScreen(areaId:s.pathParameters['areaId']!)),
              GoRoute(path: 'personnel', builder: (_, __) => const PersonnelScreen()),
            ]),
          ]),
          StatefulShellBranch(routes: [
            GoRoute(path: '/wells', builder: (_, __) => const WellsHierarchyScreen(), routes: [
              GoRoute(path: 'pad/:padId', builder: (_, s) => PadScreen(padId:s.pathParameters['padId']!)),
              GoRoute(path: 'pad/:padId/card/:wellId', builder: (_, s) => WellCardScreen(padId:s.pathParameters['padId']!,wellId:s.pathParameters['wellId']!)),
            ]),
          ]),
          StatefulShellBranch(routes: [
            GoRoute(path: '/walk', builder: (_, __) => const WalkStartScreen(), routes: [
              GoRoute(path: 'area/:areaId', builder: (_, s) => WalkAreaScreen(areaId:s.pathParameters['areaId']!)),
              GoRoute(path: 'pad/:padId', builder: (_, s) => PadWalkCardScreen(padId:s.pathParameters['padId']!)),
              GoRoute(path: 'pad/:padId/well/:wellId', builder: (_, s) => WellScreen(padId:s.pathParameters['padId']!,wellId:s.pathParameters['wellId']!)),
              GoRoute(path: 'pad/:padId/step/:index', builder: (_, s) {final padId=s.pathParameters['padId']!;final index=int.tryParse(s.pathParameters['index']!)??0;final pad=demoPads.firstWhere((p)=>p.id==padId);final safe=index.clamp(0,pad.wells.length-1).toInt();return WellScreen(key:ValueKey('walk-$padId-$safe'),padId:padId,wellId:pad.wells[safe].id,walkIndex:safe);}),
              GoRoute(path: 'pad/:padId/summary', builder: (_, s) => WalkSummaryScreen(padId:s.pathParameters['padId']!)),
            ]),
          ]),
          StatefulShellBranch(routes: [GoRoute(path: '/tasks', builder: (_, __) => const TasksScreen())]),
          StatefulShellBranch(routes: [GoRoute(path: '/history', builder: (_, __) => const HistoryScreen())]),
          StatefulShellBranch(routes: [GoRoute(path: '/profile', builder: (_, __) => const ProfileScreen())]),
        ],
      ),
      GoRoute(path: '/correction', parentNavigatorKey: _rootKey, builder: (_, s) => CorrectionScreen(measurement:s.extra! as Measurement)),
      GoRoute(path: '/organization', parentNavigatorKey: _rootKey, builder: (_, __) => const OrganizationScreen()),
    ],
  );

  @override Widget build(BuildContext context)=>MaterialApp.router(title:'Нефтяник',debugShowCheckedModeBanner:false,theme:buildAppTheme(),routerConfig:_router,builder:(context,child){if(initializationError==null)return child??const SizedBox.shrink();return Material(child:SafeArea(child:Center(child:Padding(padding:const EdgeInsets.all(24),child:Text('Не удалось открыть локальные данные\n$initializationError',textAlign:TextAlign.center)))));});
}

class _MainShell extends StatelessWidget {
  const _MainShell({required this.shell});
  final StatefulNavigationShell shell;
  @override Widget build(BuildContext context)=>Scaffold(
    body:shell,
    bottomNavigationBar:NavigationBar(
      selectedIndex:shell.currentIndex,
      onDestinationSelected:(i)=>shell.goBranch(i,initialLocation:i==shell.currentIndex),
      destinations:const [
        NavigationDestination(icon:Icon(Icons.dashboard_outlined),selectedIcon:Icon(Icons.dashboard),label:'Главная'),
        NavigationDestination(icon:Icon(Icons.oil_barrel_outlined),selectedIcon:Icon(Icons.oil_barrel),label:'Скважины'),
        NavigationDestination(icon:Icon(Icons.assignment_turned_in_outlined),selectedIcon:Icon(Icons.assignment_turned_in),label:'Обход'),
        NavigationDestination(icon:Icon(Icons.task_alt_outlined),selectedIcon:Icon(Icons.task_alt),label:'Задания'),
        NavigationDestination(icon:Icon(Icons.history_outlined),selectedIcon:Icon(Icons.history),label:'История'),
        NavigationDestination(icon:Icon(Icons.person_outline),selectedIcon:Icon(Icons.person),label:'Профиль'),
      ],
    ),
  );
}
