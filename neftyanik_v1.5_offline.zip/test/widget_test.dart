import 'package:flutter_test/flutter_test.dart';
import 'package:oilman_app/app/app.dart';

void main() {
  testWidgets('Главный экран отображает кусты', (tester) async {
    await tester.pumpWidget(const OilmanApp());
    expect(find.text('КП 1017'), findsOneWidget);
    expect(find.text('КП 3А02'), findsOneWidget);
  });
}
