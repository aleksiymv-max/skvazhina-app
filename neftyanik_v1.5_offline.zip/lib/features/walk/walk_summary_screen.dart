import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../core/database/app_database.dart';
import '../../core/models/pad.dart';

class WalkSummaryScreen extends StatelessWidget {
  const WalkSummaryScreen({super.key, required this.padId});
  final String padId;

  @override
  Widget build(BuildContext context) {
    final pad = demoPads.firstWhere((p) => p.id == padId);
    return Scaffold(
      appBar: AppBar(title: const Text('Обход завершён')),
      body: FutureBuilder(
        future: AppDatabase.instance.history(padId: padId, limit: 200),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          final measurements = snapshot.data!;
          final checked = measurements.map((m) => m.wellId).toSet();
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Card(child: Padding(padding: const EdgeInsets.all(20), child: Column(children: [
                const Icon(Icons.check_circle_outline, size: 56),
                const SizedBox(height: 12),
                const Text('Обход сохранён', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
                const SizedBox(height: 8),
                Text('${checked.length} из ${pad.wells.length} скважин имеют сохранённый замер'),
              ]))),
              const SizedBox(height: 12),
              ...pad.wells.map((well) {
                final ok = checked.contains(well.id);
                return Card(child: ListTile(leading: Icon(ok ? Icons.check_circle : Icons.radio_button_unchecked), title: Text('Скважина ${well.number}'), subtitle: Text(ok ? 'Замер сохранён' : 'Замер отсутствует')));
              }),
              const SizedBox(height: 12),
              FilledButton.icon(onPressed: () => context.go('/pad/$padId'), icon: const Icon(Icons.arrow_back), label: const Text('Вернуться к кусту')),
            ],
          );
        },
      ),
    );
  }
}
