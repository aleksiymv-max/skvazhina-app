import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../core/models/measurement.dart';
import '../../core/models/pad.dart';
import '../../core/models/well.dart';
import '../../core/repositories/measurement_repository.dart';
import '../../core/services/export_service.dart';
import '../../core/services/session_service.dart';

class HistoryScreen extends StatefulWidget { const HistoryScreen({super.key}); @override State<HistoryScreen> createState()=>_HistoryScreenState(); }

class _HistoryScreenState extends State<HistoryScreen> {
  final repo=MeasurementRepository();
  String? padId, wellId;
  List<Measurement> items=[];
  bool loading=false;

  Pad? get selectedPad=>padId==null?null:demoPads.where((p)=>p.id==padId).firstOrNull;
  Well? get selectedWell=>selectedPad?.wells.where((w)=>w.id==wellId).firstOrNull;

  @override void initState(){super.initState();padId=demoPads.first.id;_setDefaultWell();_load();}
  void _setDefaultWell(){final wells=selectedPad?.wells??const <Well>[];wellId=wells.isEmpty?null:wells.first.id;}
  Future<void> _load() async {setState(()=>loading=true);items=await repo.history(wellId:wellId,limit:500);if(mounted)setState(()=>loading=false);}

  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('История'),actions:[if(SessionService.instance.currentUser.canExport)IconButton(icon:const Icon(Icons.file_download_outlined),tooltip:'Экспорт Excel',onPressed:_export)]),
    body:ListView(padding:const EdgeInsets.all(16),children:[
      const Text('Выбор объекта',style:TextStyle(fontSize:18,fontWeight:FontWeight.w800)),const SizedBox(height:8),
      DropdownButtonFormField<String>(value:padId,decoration:const InputDecoration(labelText:'Кустовая площадка'),items:demoPads.map((p)=>DropdownMenuItem(value:p.id,child:Text(p.name))).toList(),onChanged:(v){setState((){padId=v;_setDefaultWell();});_load();}),
      const SizedBox(height:10),
      DropdownButtonFormField<String>(value:wellId,decoration:const InputDecoration(labelText:'Скважина'),items:(selectedPad?.wells??const <Well>[]).map((w)=>DropdownMenuItem(value:w.id,child:Text('Скважина ${w.number}'))).toList(),onChanged:(v){setState(()=>wellId=v);_load();}),
      const SizedBox(height:16),
      if(selectedWell!=null)Text('История внесения параметров: скважина ${selectedWell!.number}',style:const TextStyle(fontSize:18,fontWeight:FontWeight.w800)),
      const SizedBox(height:10),
      if(loading)const Center(child:Padding(padding:EdgeInsets.all(24),child:CircularProgressIndicator()))
      else if(items.isEmpty)const Card(child:Padding(padding:EdgeInsets.all(18),child:Text('Для выбранной скважины замеров пока нет.')))
      else ...items.map(_measurementCard),
    ],),
  );

  Widget _measurementCard(Measurement m){
    final date=DateFormat('dd.MM.yyyy HH:mm').format(m.measuredAt);
    final values=<String>[
      if(m.rtr!=null)'Ртр ${_fmt(m.rtr!)}',if(m.rz!=null)'Рз ${_fmt(m.rz!)}',if(m.pkvInstalled&&m.pkvWork!=null&&m.pkvIdle!=null)'ПКВ ${m.pkvWork}/${m.pkvIdle}',if(m.frequency!=null)'F ${_fmt(m.frequency!)}',if(m.current!=null)'Iср ${_fmt(m.current!)}',if(m.load!=null)'Загрузка ${_fmt(m.load!)}%',if(m.rBuf!=null)'Рбуф ${_fmt(m.rBuf!)}',if(m.rLine!=null)'Рлин ${_fmt(m.rLine!)}',
    ];
    return Card(margin:const EdgeInsets.only(bottom:10),child:ListTile(title:Text('Скважина ${m.wellNumber}',style:const TextStyle(fontWeight:FontWeight.w700)),subtitle:Text('$date\n${values.isEmpty?'Нет внесённых параметров':values.join(' · ')}'),isThreeLine:true,trailing:SessionService.instance.currentUser.canCorrect?IconButton(icon:const Icon(Icons.edit_outlined),tooltip:'Корректировать все параметры',onPressed:()async{final changed=await Navigator.push<bool>(context,MaterialPageRoute(builder:(_)=>_CorrectionScreen(measurement:m)));if(changed==true)_load();}):null));
  }

  Future<void> _export() async {if(items.isEmpty)return;final pad=selectedPad??demoPads.first;try{final file=await ExportService.createXlsx(measurements:items,padName:pad.name);await ExportService.shareXlsx(file);}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Не удалось сформировать Excel: $e')));}}
  String _fmt(double v)=>v.toStringAsFixed(v.truncateToDouble()==v?0:2).replaceAll('.',',');
}

class _CorrectionScreen extends StatefulWidget { const _CorrectionScreen({required this.measurement}); final Measurement measurement; @override State<_CorrectionScreen> createState()=>_CorrectionScreenState(); }
class _CorrectionScreenState extends State<_CorrectionScreen>{
  final db=MeasurementRepository();
  final value=TextEditingController(),reason=TextEditingController(),comment=TextEditingController();
  late String parameter;
  bool saving=false;
  late final List<MapEntry<String,String>> fields;

  @override void initState(){super.initState();parameter='rtr';fields=<String,String>{
    'rtr':'Ртр','rz':'Рз','pkv_installed':'ПКВ установлена','pid_installed':'ПИД установлен','pkv_work':'ПКВ: работа','pkv_idle':'ПКВ: простой','pid_current':'Ток ПИД','pid_frequency_range':'Диапазон F','frequency':'F','current':'Iср','load':'Загрузка','rp':'Рпр','t_ped':'Тпэд','r_insul':'Rизол',
    'r_buf':'Рбуф','r_buf_source':'Источник Рбуф','r_inter_dr':'Рмеж. др.','r_casing':'Рзатр','r_line':'Рлин','r_line_source':'Источник Рлин','t_before_choke':'Т до дросселя','t_line':'Тлин','choke_mode':'Режим дросселирования','choke_value':'Дроссель, %','nozzle':'Штуцер','r_downhole':'Рузд','t_downhole':'Тузд','r_ko':'Рко','inhibitor_feed':'Подача ингибитора','note':'Замечание',
  }.entries.toList();}

  String? _old(){final m=widget.measurement;switch(parameter){case'rtr':return m.rtr?.toString();case'rz':return m.rz?.toString();case'pkv_installed':return m.pkvInstalled?'Да':'Нет';case'pid_installed':return m.pidInstalled?'Да':'Нет';case'pkv_work':return m.pkvWork?.toString();case'pkv_idle':return m.pkvIdle?.toString();case'pid_current':return m.pidCurrent?.toString();case'pid_frequency_range':return m.pidFrequencyRange;case'frequency':return m.frequency?.toString();case'current':return m.current?.toString();case'load':return m.load?.toString();case'rp':return m.rp?.toString();case't_ped':return m.tPed?.toString();case'r_insul':return m.rInsul?.toString();case'r_buf':return m.rBuf?.toString();case'r_buf_source':return m.rBufSource;case'r_inter_dr':return m.rInterDr?.toString();case'r_casing':return m.rCasing?.toString();case'r_line':return m.rLine?.toString();case'r_line_source':return m.rLineSource;case't_before_choke':return m.tBeforeChoke?.toString();case't_line':return m.tLine?.toString();case'choke_mode':return m.chokeMode;case'choke_value':return m.chokeValue?.toString();case'nozzle':return m.nozzle;case'r_downhole':return m.rDownhole?.toString();case't_downhole':return m.tDownhole?.toString();case'r_ko':return m.rKo?.toString();case'inhibitor_feed':return m.inhibitorFeed?.toString();case'note':return m.note;default:return null;}}

  @override Widget build(BuildContext context){return Scaffold(appBar:AppBar(title:const Text('Корректировка замера')),body:ListView(padding:const EdgeInsets.all(16),children:[Card(child:ListTile(title:Text('Скважина ${widget.measurement.wellNumber}'),subtitle:Text(DateFormat('dd.MM.yyyy HH:mm').format(widget.measurement.measuredAt)))),const SizedBox(height:12),DropdownButtonFormField<String>(value:parameter,decoration:const InputDecoration(labelText:'Параметр для корректировки'),items:fields.map((e)=>DropdownMenuItem(value:e.key,child:Text(e.value))).toList(),onChanged:(v){if(v!=null)setState((){parameter=v;value.text=_old()??'';});}),const SizedBox(height:8),Text('Текущее значение: ${_old()??'—'}',style:const TextStyle(fontWeight:FontWeight.w700)),if(parameter=='pkv_installed'||parameter=='pid_installed') DropdownButtonFormField<String>(value:(value.text=='Да'||value.text=='Нет')?value.text:null,decoration:const InputDecoration(labelText:'Новое значение'),items:const[DropdownMenuItem(value:'Да',child:Text('Да')),DropdownMenuItem(value:'Нет',child:Text('Нет'))],onChanged:(v)=>setState(()=>value.text=v??'')) else TextField(controller:value,decoration:InputDecoration(labelText:'Новое значение',hintText:parameter=='note'?'Текст':'Число или текст')),TextField(controller:reason,decoration:const InputDecoration(labelText:'Причина исправления *')),TextField(controller:comment,decoration:const InputDecoration(labelText:'Комментарий')),const SizedBox(height:18),FilledButton.icon(onPressed:saving?null:_save,icon:const Icon(Icons.check),label:const Text('Сохранить корректировку'))]);}

  Future<void> _save()async{if(reason.text.trim().isEmpty){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Укажите причину исправления')));return;}setState(()=>saving=true);try{await db.correct(measurementId:widget.measurement.id!,parameter:parameter,newValue:value.text,userId:SessionService.instance.currentUser.id,userName:SessionService.instance.currentUser.name,reason:reason.text.trim(),comment:comment.text.trim().isEmpty?null:comment.text.trim());if(mounted)Navigator.pop(context,true);}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Ошибка: $e')));}finally{if(mounted)setState(()=>saving=false);}}
  @override void dispose(){value.dispose();reason.dispose();comment.dispose();super.dispose();}
}
