class ApiConfig {
  ApiConfig._();

  // Android Emulator: http://10.0.2.2:8000
  // Реальный телефон: укажи IP компьютера в локальной сети через --dart-define.
  static const String baseUrl = String.fromEnvironment(
    'OILMAN_API_URL',
    defaultValue: 'http://10.0.2.2:8000',
  );
}
