class SyncItem {
  const SyncItem({required this.id, required this.entityType, required this.entityId, required this.createdAt, required this.status});

  final int id;
  final String entityType;
  final int entityId;
  final DateTime createdAt;
  final String status;

  String get statusLabel => switch (status) {
    'pending' => 'Ожидает отправки',
    'syncing' => 'Синхронизация',
    'synced' => 'Синхронизировано',
    'error' => 'Ошибка синхронизации',
    _ => status,
  };
}
