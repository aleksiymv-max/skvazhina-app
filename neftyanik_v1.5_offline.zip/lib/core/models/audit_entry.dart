class AuditEntry {
  const AuditEntry({required this.id, required this.measurementId, required this.userName, required this.createdAt, required this.parameter, required this.oldValue, required this.newValue, required this.reason, this.comment});
  final int id;
  final int measurementId;
  final String userName;
  final DateTime createdAt;
  final String parameter;
  final String? oldValue;
  final String? newValue;
  final String reason;
  final String? comment;
}
