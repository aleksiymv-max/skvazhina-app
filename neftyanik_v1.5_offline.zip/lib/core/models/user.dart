enum UserRole { operator, engineer, manager, admin }

extension UserRoleX on UserRole {
  String get label => switch (this) {
    UserRole.operator => 'Оператор',
    UserRole.engineer => 'Инженер',
    UserRole.manager => 'Руководитель',
    UserRole.admin => 'Администратор',
  };
}

class AppUser {
  const AppUser({required this.id, required this.name, required this.role});
  final String id;
  final String name;
  final UserRole role;

  bool get canCorrect => role == UserRole.engineer || role == UserRole.admin;
  bool get canExport => role != UserRole.operator;
}
