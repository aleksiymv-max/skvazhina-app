enum WellType { oil, gasCondensate }

enum WellStatus { working, stopped, krs, pdf, disabled, underload }

class Well {
  const Well({
    required this.id,
    required this.number,
    required this.type,
    required this.status,
    this.pkvWork,
    this.pkvIdle,
    this.rtr,
    this.rz,
    this.frequency,
    this.current,
    this.load,
    this.rp,
    this.tPed,
    this.rInsul,
    this.pkvInstalled,
    this.pidInstalled,
  });

  final String id;
  final String number;
  final WellType type;
  final WellStatus status;
  final int? pkvWork, pkvIdle;
  final double? rtr, rz, frequency, current, load, rp, tPed, rInsul;
  final bool? pkvInstalled, pidInstalled;

  int? get pkvCycle => pkvWork != null && pkvIdle != null ? pkvWork! + pkvIdle! : null;
}
