import 'well.dart';

class Pad {
  const Pad({required this.id, required this.name, required this.type, required this.wells});

  final String id;
  final String name;
  final String type;
  final List<Well> wells;
}

final demoPads = <Pad>[
  Pad(
    id: '1017',
    name: 'КП 1017',
    type: 'Механизированный фонд',
    wells: [
      Well(id: '10076', number: '10076', type: WellType.oil, status: WellStatus.krs),
      Well(id: '10079', number: '10079', type: WellType.oil, status: WellStatus.working, pkvWork: 11, pkvIdle: 9, rtr: 32.5, rz: 37, frequency: 55, current: 31.4, load: 57.6, rp: 61.8, tPed: 92.3, rInsul: 9999),
      Well(id: '10113', number: '10113', type: WellType.oil, status: WellStatus.working, pkvWork: 7, pkvIdle: 13, rtr: 32, rz: 33.5, frequency: 49.2, current: 46.7, load: 63, rp: 44.3, tPed: 97.6, rInsul: 9999),
      Well(id: '10121', number: '10121', type: WellType.oil, status: WellStatus.working, pkvWork: 17, pkvIdle: 13, rtr: 32, rz: 33, frequency: 100, current: 14.8, load: 51, rp: 56.65, tPed: 86.8, rInsul: 9999),
      Well(id: '10123', number: '10123', type: WellType.oil, status: WellStatus.pdf, rtr: 32, rz: 32.5, frequency: 50, current: 33.8, load: 40, rp: 52, tPed: 88, rInsul: 9999),
      Well(id: '10124', number: '10124', type: WellType.oil, status: WellStatus.stopped, rtr: 7, rz: 42.8, rp: 87.6, tPed: 79, rInsul: 9999),
      Well(id: '10125', number: '10125', type: WellType.oil, status: WellStatus.pdf, rtr: 34, rz: 34.5, frequency: 169.3, current: 8.5, load: 20, rp: 69.24, tPed: 84.6, rInsul: 9999),
      Well(id: '10171', number: '10171', type: WellType.oil, status: WellStatus.working, rz: 35, rp: 91.47, tPed: 81.5),
      Well(id: '10213', number: '10213', type: WellType.oil, status: WellStatus.working, pkvWork: 11, pkvIdle: 9, rtr: 32, rz: 34, frequency: 50, current: 29.6, load: 56, rp: 62.51, tPed: 85.4, rInsul: 9999),
      Well(id: '10313', number: '10313', type: WellType.oil, status: WellStatus.working, pkvWork: 12, pkvIdle: 18, rtr: 32, rz: 34, frequency: 93.7, current: 26.4, load: 74, rInsul: 0),
      Well(id: '10413', number: '10413', type: WellType.oil, status: WellStatus.working, pkvWork: 11, pkvIdle: 9, rtr: 32, rz: 34, frequency: 48.5, current: 27.4, load: 52, rp: 64.5, tPed: 97.4, rInsul: 9999),
      Well(id: '11121', number: '11121', type: WellType.oil, status: WellStatus.disabled, pkvWork: 9, pkvIdle: 6, rtr: 32, rz: 32, rInsul: 0),
      Well(id: '12121', number: '12121', type: WellType.oil, status: WellStatus.underload, pkvWork: 9, pkvIdle: 21, rtr: 32, rz: 34.5, frequency: 99.2, current: 11.8, load: 45, rp: 57.3, tPed: 81.6, rInsul: 9999),
    ],
  ),
  Pad(
    id: '3A02',
    name: 'КП 3А02',
    type: 'Газоконденсатный фонд',
    wells: [
      Well(id: '3A021', number: '3А021', type: WellType.gasCondensate, status: WellStatus.working),
      Well(id: '3A022', number: '3А022', type: WellType.gasCondensate, status: WellStatus.working),
      Well(id: '3A023', number: '3А023', type: WellType.gasCondensate, status: WellStatus.working),
      Well(id: '3A024', number: '3А024', type: WellType.gasCondensate, status: WellStatus.working),
      Well(id: '3A025', number: '3А025', type: WellType.gasCondensate, status: WellStatus.working),
      Well(id: '3A026', number: '3А026', type: WellType.gasCondensate, status: WellStatus.working),
      Well(id: '3A027', number: '3А027', type: WellType.gasCondensate, status: WellStatus.working),
    ],
  ),
];
