import '../database/app_database.dart';
import '../models/measurement.dart';

class MeasurementRepository {
  MeasurementRepository({AppDatabase? database}) : _database = database ?? AppDatabase.instance;
  final AppDatabase _database;
  Future<int> save(Measurement m) => _database.insertMeasurement(m);
  Future<Measurement?> latestForWell(String id) => _database.latestForWell(id);
  Future<List<Measurement>> history({String? padId,String? wellId,int limit=100}) => _database.history(padId:padId,wellId:wellId,limit:limit);
  Future<List<Measurement>> trends({required String wellId,required DateTime from,required DateTime to}) => _database.trendMeasurements(wellId:wellId,from:from,to:to);
  Future<int> correct({required int measurementId,required String parameter,required String? newValue,required String userId,required String userName,required String reason,String? comment}) => _database.correctMeasurement(measurementId:measurementId,parameter:parameter,newValue:newValue,userId:userId,userName:userName,reason:reason,comment:comment);
  Future<void> saveWalk(String padId,int index) => _database.saveWalk(padId,index);
  Future<Map<String,Object?>?> activeWalk(String padId) => _database.activeWalk(padId);
  Future<void> finishWalk(String padId) => _database.finishWalk(padId);
  Future<int> checkedCount(String padId) => _database.checkedCount(padId);
}
