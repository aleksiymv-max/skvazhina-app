import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import '../database/app_database.dart';
import 'session_service.dart';

/// В версии 1.4 синхронизация отключена: приложение работает полностью офлайн.
/// Очередь и серверная синхронизация сохраняются в архитектуре для следующего этапа.
class SyncService extends ChangeNotifier {
  SyncService._();
  static final instance = SyncService._();

  final AppDatabase _db = AppDatabase.instance;
  StreamSubscription<List<ConnectivityResult>>? _subscription;
  bool _online = false;
  bool _syncing = false;
  bool _serverAvailable = false;
  int pending = 0;
  DateTime? lastSyncAt;
  String status = 'Офлайн-режим · данные сохраняются на устройстве';

  bool get online => _online;
  bool get syncing => _syncing;
  bool get serverAvailable => _serverAvailable;

  Future<void> initialize() async {
    _online = false;
    _serverAvailable = false;
    await _refreshCount();
  }

  Future<void> _refreshCount() async {
    pending = await _db.pendingSyncCount();
    status = pending == 0
        ? 'Офлайн-режим · данные сохраняются на устройстве'
        : 'Офлайн-режим · в очереди: $pending';
    notifyListeners();
  }

  Future<void> syncNow() async {
    // Серверная синхронизация будет включена на следующем этапе.
    await _refreshCount();
  }

  Future<void> dispose() async {
    await _subscription?.cancel();
    super.dispose();
  }
}
