import 'dart:io';
import 'package:excel/excel.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import '../models/measurement.dart';

class ExportService {
  static Future<File> createXlsx({required List<Measurement> measurements, required String padName}) async {
    final excel=Excel.createExcel();final sheet=excel['Замеры'];
    final headers=['Дата и время','Куст','Скважина','Тип','Ртр, кгс/см²','Рз, кгс/см²','ПКВ установлена','ПКВ работа, мин','ПКВ простой, мин','ПКВ цикл, мин','ПИД установлен','Ток ПИД, А','Диапазон F','F, Гц','Iср, А','Загрузка, %','Рпр, атм','Тпэд, °C','Rизол, кОм','Рбуф, МПа','Источник Рбуф','Рмеж. др., МПа','Рзатр, МПа','Рлин, МПа','Источник Рлин','Т до дросселя, °C','Тлин, °C','Режим дросселирования','Дроссель, %','Штуцер','Рузд, МПа','Тузд, °C','Рко, МПа','Подача ингибитора, кг/ч','Замечание'];
    sheet.appendRow(headers.map(TextCellValue.new).toList());
    for(final m in measurements){final values=[m.measuredAt.toLocal().toIso8601String().replaceFirst('T',' '),padName,m.wellNumber,_wellType(m),m.rtr,m.rz,m.pkvInstalled?'Да':'Нет',m.pkvWork,m.pkvIdle,m.pkvCycle,m.pidInstalled?'Да':'Нет',m.pidCurrent,m.pidFrequencyRange,m.frequency,m.current,m.load,m.rp,m.tPed,m.rInsul,m.rBuf,m.rBufSource,m.rInterDr,m.rCasing,m.rLine,m.rLineSource,m.tBeforeChoke,m.tLine,m.chokeMode,m.chokeValue,m.nozzle,m.rDownhole,m.tDownhole,m.rKo,m.inhibitorFeed,m.note];sheet.appendRow(values.map(_cell).toList());}
    final dir=await getTemporaryDirectory();final safePad=padName.replaceAll(RegExp(r'[^A-Za-zА-Яа-я0-9_-]'),'_');final file=File('${dir.path}/замеры_${safePad}_${DateTime.now().millisecondsSinceEpoch}.xlsx');final bytes=excel.encode();if(bytes==null)throw StateError('Не удалось сформировать Excel-файл');await file.writeAsBytes(bytes,flush:true);return file;
  }
  static CellValue _cell(dynamic v){if(v==null)return TextCellValue('');if(v is int)return IntCellValue(v);if(v is double)return DoubleCellValue(v);if(v is num)return DoubleCellValue(v.toDouble());return TextCellValue(v.toString());}
  static String _wellType(Measurement m)=>m.rBuf!=null||m.rLine!=null?'Газоконденсатная':'Механизированная';
  static Future<void> shareXlsx(File file)async=>Share.shareXFiles([XFile(file.path)],text:'Выгрузка замеров — Нефтяник');
}
