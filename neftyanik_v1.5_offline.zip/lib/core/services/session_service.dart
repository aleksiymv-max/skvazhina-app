import '../models/user.dart';
import '../network/api_client.dart';

class SessionService {
  SessionService._();
  static final instance = SessionService._();

  AppUser currentUser = const AppUser(
    id: 'op-001',
    name: 'Оператор',
    role: UserRole.operator,
  );

  final ApiClient api = ApiClient.instance;
  String? get token => api.token;

  Future<void> logout() async {
    api.token = null;
    currentUser = const AppUser(id: '', name: '', role: UserRole.operator);
  }

  /// Полностью офлайн-вход. Сервер для работы приложения не требуется.
  Future<void> login(String username, String password) async {
    const users = <String, Map<String, String>>{
      'op-001': {'password': 'operator', 'name': 'Оператор', 'role': 'operator'},
      'eng-001': {'password': 'engineer', 'name': 'Инженер', 'role': 'engineer'},
      'mgr-001': {'password': 'manager', 'name': 'Руководитель', 'role': 'manager'},
      'adm-001': {'password': 'admin', 'name': 'Администратор', 'role': 'admin'},
    };

    final record = users[username];
    if (record == null || record['password'] != password) {
      throw const ApiException('Неверный логин или пароль');
    }

    final role = UserRole.values.firstWhere((r) => r.name == record['role']);
    currentUser = AppUser(id: username, name: record['name']!, role: role);
    api.token = 'offline-$username';
  }
}
