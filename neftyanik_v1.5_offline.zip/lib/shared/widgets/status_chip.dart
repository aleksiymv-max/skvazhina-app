import 'package:flutter/material.dart';

class StatusChip extends StatelessWidget {
  const StatusChip({super.key, required this.label, required this.kind});

  final String label;
  final StatusKind kind;

  @override
  Widget build(BuildContext context) {
    final (bg, fg) = switch (kind) {
      StatusKind.ok => (const Color(0xFFE9F6EE), const Color(0xFF23864B)),
      StatusKind.warning => (const Color(0xFFFFF3D9), const Color(0xFFA86B00)),
      StatusKind.problem => (const Color(0xFFFBE9E8), const Color(0xFFBD3B35)),
    };
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(99)),
      child: Text(label, style: TextStyle(color: fg, fontWeight: FontWeight.w700, fontSize: 12)),
    );
  }
}

enum StatusKind { ok, warning, problem }
