import 'package:flutter/material.dart';

import 'app/app.dart';
import 'core/database/app_database.dart';
import 'core/services/sync_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // UI запускается независимо от сети и серверной части.
  // Ошибка локальной БД больше не оставляет пользователя на белом экране.
  Object? initializationError;
  try {
    await AppDatabase.instance.database;
  } catch (e) {
    initializationError = e;
  }

  runApp(OilmanApp(initializationError: initializationError));

  // Синхронизация выполняется после запуска интерфейса и не блокирует его.
  try {
    await SyncService.instance.initialize();
  } catch (_) {
    // Офлайн-режим должен продолжать работать даже без сервера.
  }
}
