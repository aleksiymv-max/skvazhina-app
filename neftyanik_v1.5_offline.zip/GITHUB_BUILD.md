# Сборка APK через GitHub Actions

В репозитории используется `.github/workflows/build.yml`.

Workflow умеет:
- найти распакованный Flutter-проект;
- либо найти ZIP проекта и распаковать его;
- установить Flutter;
- удалить старую Android-конфигурацию;
- создать чистую Android-конфигурацию через `flutter create`;
- установить зависимости;
- собрать release APK;
- сохранить APK как GitHub Actions Artifact.

Важно: если этот ZIP загружается в GitHub как один файл, GitHub не распаковывает его автоматически. В таком случае в репозитории должен отдельно находиться workflow `.github/workflows/build.yml`, либо ZIP должен распаковываться существующим workflow.
