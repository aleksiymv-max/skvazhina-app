from datetime import datetime, timedelta, timezone
from enum import Enum
from typing import Any
import csv
import io

import jwt
from fastapi import Depends, FastAPI, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from passlib.context import CryptContext
from pydantic import BaseModel, Field
from pydantic_settings import BaseSettings, SettingsConfigDict
from sqlalchemy import DateTime, Float, Integer, String, Text, create_engine, select
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import DeclarativeBase, Mapped, Session, mapped_column, sessionmaker


class Settings(BaseSettings):
    database_url: str = "postgresql+psycopg://oilman:oilman@localhost:5432/oilman"
    jwt_secret: str = "change-this-secret"
    jwt_expire_minutes: int = 480
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")


settings = Settings()
engine = create_engine(settings.database_url, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine, expire_on_commit=False)
pwd = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2 = OAuth2PasswordBearer(tokenUrl="/api/v1/auth/login")


class Base(DeclarativeBase):
    pass


class User(Base):
    __tablename__ = "users"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    role: Mapped[str] = mapped_column(String(32), nullable=False)
    password_hash: Mapped[str] = mapped_column(String(255), nullable=False)


class Pad(Base):
    __tablename__ = "pads"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    pad_type: Mapped[str] = mapped_column(String(100), nullable=False)


class Well(Base):
    __tablename__ = "wells"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    pad_id: Mapped[str] = mapped_column(String(64), index=True, nullable=False)
    number: Mapped[str] = mapped_column(String(64), nullable=False)
    well_type: Mapped[str] = mapped_column(String(32), nullable=False)
    status: Mapped[str] = mapped_column(String(64), nullable=False)


class Measurement(Base):
    __tablename__ = "measurements"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    pad_id: Mapped[str] = mapped_column(String(64), index=True, nullable=False)
    well_id: Mapped[str] = mapped_column(String(64), index=True, nullable=False)
    well_number: Mapped[str] = mapped_column(String(64), nullable=False)
    measured_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    payload: Mapped[dict[str, Any]] = mapped_column(JSONB, nullable=False, default=dict)
    statuses: Mapped[dict[str, str]] = mapped_column(JSONB, nullable=False, default=dict)
    source: Mapped[str] = mapped_column(String(100), nullable=False)
    created_by: Mapped[str] = mapped_column(String(64), nullable=False)
    version: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class AuditLog(Base):
    __tablename__ = "audit_log"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    measurement_id: Mapped[str] = mapped_column(String(64), index=True, nullable=False)
    user_id: Mapped[str] = mapped_column(String(64), nullable=False)
    user_name: Mapped[str] = mapped_column(String(200), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    parameter: Mapped[str] = mapped_column(String(100), nullable=False)
    old_value: Mapped[str | None] = mapped_column(Text)
    new_value: Mapped[str | None] = mapped_column(Text)
    reason: Mapped[str] = mapped_column(Text, nullable=False)
    comment: Mapped[str | None] = mapped_column(Text)


Base.metadata.create_all(engine)


class Role(str, Enum):
    operator = "operator"
    engineer = "engineer"
    manager = "manager"
    admin = "admin"


class LoginRequest(BaseModel):
    username: str
    password: str


class MeasurementIn(BaseModel):
    id: str
    pad_id: str
    well_id: str
    well_number: str
    measured_at: datetime
    payload: dict[str, Any] = Field(default_factory=dict)
    statuses: dict[str, str] = Field(default_factory=dict)
    source: str = "Оператор"


class CorrectionIn(BaseModel):
    parameter: str
    new_value: str | None
    reason: str = Field(min_length=1)
    comment: str | None = None


def db_session():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def token_for(user: User) -> str:
    exp = datetime.now(timezone.utc) + timedelta(minutes=settings.jwt_expire_minutes)
    return jwt.encode({"sub": user.id, "role": user.role, "exp": exp}, settings.jwt_secret, algorithm="HS256")


def current_user(token: str = Depends(oauth2), db: Session = Depends(db_session)) -> User:
    try:
        data = jwt.decode(token, settings.jwt_secret, algorithms=["HS256"])
        user = db.get(User, data["sub"])
    except Exception as exc:
        raise HTTPException(status_code=401, detail="Недействительный токен") from exc
    if user is None:
        raise HTTPException(status_code=401, detail="Пользователь не найден")
    return user


def require(*roles: Role):
    def checker(user: User = Depends(current_user)) -> User:
        if user.role not in {r.value for r in roles}:
            raise HTTPException(status_code=403, detail="Недостаточно прав")
        return user
    return checker


def seed() -> None:
    with SessionLocal() as db:
        if db.get(User, "op-001") is None:
            db.add_all([
                User(id="op-001", name="Оператор", role="operator", password_hash=pwd.hash("operator")),
                User(id="eng-001", name="Инженер", role="engineer", password_hash=pwd.hash("engineer")),
                User(id="mgr-001", name="Руководитель", role="manager", password_hash=pwd.hash("manager")),
                User(id="adm-001", name="Администратор", role="admin", password_hash=pwd.hash("admin")),
            ])
        if db.get(Pad, "1017") is None:
            db.add(Pad(id="1017", name="КП 1017", pad_type="Механизированный фонд"))
        if db.get(Pad, "3A02") is None:
            db.add(Pad(id="3A02", name="КП 3А02", pad_type="Газоконденсатный фонд"))
        wells_1017 = [
            ("10076", "oil", "КРС"), ("10079", "oil", "В работе"), ("10113", "oil", "В работе"),
            ("10121", "oil", "В работе"), ("10123", "oil", "ПДФ"), ("10124", "oil", "Остановлена"),
            ("10125", "oil", "ПДФ"), ("10171", "oil", "В работе"), ("10213", "oil", "В работе"),
            ("10313", "oil", "В работе"), ("10413", "oil", "В работе"), ("11121", "oil", "Отключен"),
            ("12121", "oil", "Недогруз"),
        ]
        wells_3a02 = [(f"3A02{i}", "gas_condensate", "В работе") for i in range(1, 8)]
        for number, wtype, wstatus in wells_1017 + wells_3a02:
            wid = number
            pid = "1017" if number in {x[0] for x in wells_1017} else "3A02"
            if db.get(Well, wid) is None:
                db.add(Well(id=wid, pad_id=pid, number=number, well_type=wtype, status=wstatus))
        db.commit()


seed()
app = FastAPI(title="Приложение нефтяника API", version="1.0.0")


@app.get("/health")
def health():
    return {"status": "ok", "service": "oilman-api", "version": "0.9.0"}


@app.post("/api/v1/auth/login")
def login(data: LoginRequest, db: Session = Depends(db_session)):
    user = db.scalar(select(User).where(User.id == data.username))
    if user is None or not pwd.verify(data.password, user.password_hash):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Неверный логин или пароль")
    return {"access_token": token_for(user), "token_type": "bearer", "user": {"id": user.id, "name": user.name, "role": user.role}}


@app.get("/api/v1/pads")
def pads(_: User = Depends(current_user), db: Session = Depends(db_session)):
    return [{"id": p.id, "name": p.name, "type": p.pad_type} for p in db.scalars(select(Pad).order_by(Pad.name)).all()]


@app.get("/api/v1/pads/{pad_id}/wells")
def wells(pad_id: str, _: User = Depends(current_user), db: Session = Depends(db_session)):
    return [{"id": w.id, "number": w.number, "type": w.well_type, "status": w.status} for w in db.scalars(select(Well).where(Well.pad_id == pad_id).order_by(Well.number)).all()]


@app.post("/api/v1/sync/measurements")
def sync_measurements(items: list[MeasurementIn], user: User = Depends(current_user), db: Session = Depends(db_session)):
    accepted: list[str] = []
    duplicates: list[str] = []
    now = datetime.now(timezone.utc)
    for item in items:
        existing = db.get(Measurement, item.id)
        if existing:
            duplicates.append(item.id)
            continue
        db.add(Measurement(id=item.id, pad_id=item.pad_id, well_id=item.well_id, well_number=item.well_number,
                           measured_at=item.measured_at, payload=item.payload, statuses=item.statuses,
                           source=item.source, created_by=user.id, version=1, updated_at=now))
        accepted.append(item.id)
    db.commit()
    return {"accepted": accepted, "duplicates": duplicates, "server_time": now}


@app.get("/api/v1/measurements")
def measurements(pad_id: str | None = None, well_id: str | None = None, limit: int = 100,
                 _: User = Depends(current_user), db: Session = Depends(db_session)):
    stmt = select(Measurement).order_by(Measurement.measured_at.desc()).limit(min(limit, 500))
    if pad_id:
        stmt = stmt.where(Measurement.pad_id == pad_id)
    if well_id:
        stmt = stmt.where(Measurement.well_id == well_id)
    rows = db.scalars(stmt).all()
    return [measurement_dict(m) for m in rows]


@app.post("/api/v1/measurements/{measurement_id}/corrections")
def correction(measurement_id: str, data: CorrectionIn,
               user: User = Depends(require(Role.engineer, Role.admin)), db: Session = Depends(db_session)):
    m = db.get(Measurement, measurement_id)
    if m is None:
        raise HTTPException(404, "Замер не найден")
    old = m.payload.get(data.parameter)
    payload = dict(m.payload)
    payload[data.parameter] = data.new_value
    m.payload = payload
    m.version += 1
    m.updated_at = datetime.now(timezone.utc)
    db.add(AuditLog(measurement_id=m.id, user_id=user.id, user_name=user.name,
                    created_at=datetime.now(timezone.utc), parameter=data.parameter,
                    old_value=None if old is None else str(old), new_value=data.new_value,
                    reason=data.reason, comment=data.comment))
    db.commit()
    return {"measurement_id": m.id, "version": m.version, "message": "Исправление сохранено"}


@app.get("/api/v1/export/measurements.csv")
def export_measurements_csv(pad_id: str | None = None, well_id: str | None = None,
                            _: User = Depends(require(Role.engineer, Role.manager, Role.admin)),
                            db: Session = Depends(db_session)):
    stmt = select(Measurement).order_by(Measurement.measured_at.asc())
    if pad_id:
        stmt = stmt.where(Measurement.pad_id == pad_id)
    if well_id:
        stmt = stmt.where(Measurement.well_id == well_id)
    rows = db.scalars(stmt).all()
    output = io.StringIO()
    writer = csv.writer(output, delimiter=';')
    writer.writerow(['Дата и время','Куст','Скважина','Ртр','Рз','ПКВ работа','ПКВ простой','ПКВ цикл','F','Iср','Загрузка','Рпр','Тпэд','Rизол','Рбуф','Источник Рбуф','Рзатр','Рлин','Тлин','Т до дросселя','Т после дросселя','Дроссель 1','Дроссель 2','Штуцер','Траб','Рузд','Тузд','Рко','Шибер ДУ','Подача ингибитора','Статусы','Версия'])
    for m in rows:
        p = m.payload
        s = m.statuses
        writer.writerow([m.measured_at.isoformat(), m.pad_id, m.well_number, p.get('rtr'), p.get('rz'), p.get('pkvWork'), p.get('pkvIdle'),
                         (p.get('pkvWork') + p.get('pkvIdle')) if isinstance(p.get('pkvWork'), (int,float)) and isinstance(p.get('pkvIdle'), (int,float)) else '',
                         p.get('frequency'), p.get('current'), p.get('load'), p.get('rp'), p.get('tPed'), p.get('rInsul'), p.get('rBuf'), p.get('rBufSource'),
                         p.get('rCasing'), p.get('rLine'), p.get('tLine'), p.get('tBeforeChoke'), p.get('tAfterChoke'), p.get('choke1'), p.get('choke2'), p.get('nozzle'),
                         p.get('tWork'), p.get('rDownhole'), p.get('tDownhole'), p.get('rKo'), p.get('duValve'), p.get('inhibitorFeed'),
                         '; '.join(f'{k}: {v}' for k,v in s.items()), m.version])
    from fastapi.responses import StreamingResponse
    return StreamingResponse(iter([output.getvalue().encode('utf-8-sig')]), media_type='text/csv; charset=utf-8',
                             headers={'Content-Disposition':'attachment; filename="measurements.csv"'})


@app.get("/api/v1/measurements/{measurement_id}/audit")
def audit(measurement_id: str, _: User = Depends(current_user), db: Session = Depends(db_session)):
    rows = db.scalars(select(AuditLog).where(AuditLog.measurement_id == measurement_id).order_by(AuditLog.created_at.desc())).all()
    return [{"id": a.id, "user": a.user_name, "created_at": a.created_at, "parameter": a.parameter,
             "old_value": a.old_value, "new_value": a.new_value, "reason": a.reason, "comment": a.comment} for a in rows]


def measurement_dict(m: Measurement) -> dict[str, Any]:
    return {"id": m.id, "pad_id": m.pad_id, "well_id": m.well_id, "well_number": m.well_number,
            "measured_at": m.measured_at, "payload": m.payload, "statuses": m.statuses,
            "source": m.source, "created_by": m.created_by, "version": m.version, "updated_at": m.updated_at}
