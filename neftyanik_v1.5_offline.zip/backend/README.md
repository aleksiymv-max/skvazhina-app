# Сервер «Приложения нефтяника» v0.8

FastAPI + PostgreSQL. Это первый серверный слой проекта.

## Быстрый запуск

```bash
cp .env.example .env
docker compose up --build
```

API будет доступен на `http://localhost:8000`.
Документация Swagger: `http://localhost:8000/docs`.

## Тестовые пользователи

- `op-001` / `operator`
- `eng-001` / `engineer`
- `mgr-001` / `manager`
- `adm-001` / `admin`

Перед эксплуатацией пароли и JWT_SECRET обязательно заменить.

## Основные API

- `GET /health`
- `POST /api/v1/auth/login`
- `GET /api/v1/pads`
- `GET /api/v1/pads/{pad_id}/wells`
- `POST /api/v1/sync/measurements`
- `GET /api/v1/measurements`
- `POST /api/v1/measurements/{id}/corrections`
- `GET /api/v1/measurements/{id}/audit`
