import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';

import '../../core/models/measurement.dart';
import '../../core/repositories/measurement_repository.dart';
import '../../core/services/session_service.dart';
import '../../core/services/export_service.dart';
import '../../core/models/pad.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  final repository = MeasurementRepository();
  late Future<List<Measurement>> future;

  @override
  void initState() {
    super.initState();
    future = repository.history();
  }

  Future<void> _refresh() async {
    setState(() => future = repository.history());
    await future;
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('История'), actions: [if (SessionService.instance.currentUser.canExport) IconButton(icon: const Icon(Icons.file_download_outlined), tooltip: 'Экспорт Excel', onPressed: () => _export())]), 
    body: FutureBuilder<List<Measurement>>(
      future: future,
      builder: (context, snapshot) {
        if (snapshot.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator());
        if (snapshot.hasError) return Center(child: Text('Ошибка загрузки: ${snapshot.error}'));
        final items = snapshot.data ?? [];
        if (items.isEmpty) return const Center(child: Text('Замеров пока нет'));
        return RefreshIndicator(
          onRefresh: _refresh,
          child: ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: items.length + 1,
            itemBuilder: (context, index) {
              if (index == items.length) return const Padding(padding: EdgeInsets.only(top: 8), child: Text('Прошлые замеры доступны только для просмотра. Оператор не может изменять историю.', style: TextStyle(color: Colors.black54)));
              return _measurementCard(items[index]);
            },
          ),
        );
      },
    ),
  );


  Future<void> _export() async {
    final items = await future;
    if (items.isEmpty || !mounted) return;
    final padId = items.first.padId;
    final pad = demoPads.firstWhere((p) => p.id == padId, orElse: () => demoPads.first);
    try {
      final file = await ExportService.createXlsx(measurements: items, padName: pad.name);
      if (!mounted) return;
      await ExportService.shareXlsx(file);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Не удалось сформировать Excel: $e')));
    }
  }

  Widget _measurementCard(Measurement m) {
    final date = DateFormat('dd.MM.yyyy HH:mm').format(m.measuredAt);
    final quality = m.statuses.values.where((v) => v != 'measured').length;
    final values = <String>[
      if (m.rtr != null) 'Ртр ${_fmt(m.rtr!)}',
      if (m.pkvWork != null && m.pkvIdle != null) 'ПКВ ${m.pkvWork}/${m.pkvIdle}',
      if (m.frequency != null) 'F ${_fmt(m.frequency!)}',
      if (m.current != null) 'Iср ${_fmt(m.current!)}',
      if (m.load != null) 'Загрузка ${_fmt(m.load!)}%',
    ];
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: ListTile(
        title: Text('Скважина ${m.wellNumber}', style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Text('$date\n${values.isEmpty ? 'Нет измеренных параметров' : values.join(' · ')}\nИсточник: ${m.source}'),
        isThreeLine: true,
        trailing: SessionService.instance.currentUser.canCorrect ? IconButton(icon: const Icon(Icons.edit_outlined), tooltip: 'Исправить', onPressed: () async { final changed = await context.push('/correction', extra: m); if (changed == true) _refresh(); }) : const Icon(Icons.lock_outline),
      ),
    );
  }

  String _fmt(double value) => value.toStringAsFixed(value.truncateToDouble() == value ? 0 : 2).replaceAll('.', ',');
}
