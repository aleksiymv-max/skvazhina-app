import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../core/models/measurement.dart';
import '../../core/models/pad.dart';
import '../../core/models/well.dart';
import '../../core/repositories/measurement_repository.dart';

class WellScreen extends StatefulWidget {
  const WellScreen({super.key, required this.padId, required this.wellId, this.walkIndex});
  final String padId;
  final String wellId;
  final int? walkIndex;

  @override
  State<WellScreen> createState() => _WellScreenState();
}

class _WellScreenState extends State<WellScreen> {
  final formKey = GlobalKey<FormState>();
  final repository = MeasurementRepository();
  late Well well;
  late final TextEditingController rtr;
  late final TextEditingController rz;
  late final TextEditingController pkvWork;
  late final TextEditingController pkvIdle;
  late final TextEditingController pidCurrent;
  late final TextEditingController pidFrequencyRange;
  late final TextEditingController frequency;
  late final TextEditingController current;
  late final TextEditingController load;
  late final TextEditingController rp;
  late final TextEditingController tPed;
  late final TextEditingController rInsul;
  late final TextEditingController gasState, rBuf, rBufSource, rInterDr, rCasing, tBeforeChoke, rLine, tLine, tAfterChoke, choke1, choke2, nozzle, tWork, rDownhole, tDownhole, rKo, duValve, inhibitorFeed, note;
  bool loading = true;
  bool saving = false;
  final Map<String, String> statuses = {};

  static const statusLabels = <String, String>{
    'measured': 'Измерено',
    'no_reading': 'Нет показаний',
    'unavailable': 'Недоступно',
    'not_applicable': 'Не применяется',
    'device_error': 'Ошибка прибора',
  };

  @override
  void initState() {
    super.initState();
    final pad = demoPads.firstWhere((p) => p.id == widget.padId);
    well = pad.wells.firstWhere((w) => w.id == widget.wellId);
    rtr = TextEditingController();
    rz = TextEditingController();
    pkvWork = TextEditingController();
    pkvIdle = TextEditingController();
    pidCurrent = TextEditingController();
    pidFrequencyRange = TextEditingController();
    frequency = TextEditingController();
    current = TextEditingController();
    load = TextEditingController();
    rp = TextEditingController();
    tPed = TextEditingController();
    rInsul = TextEditingController();
    gasState=TextEditingController(); rBuf=TextEditingController(); rBufSource=TextEditingController(); rInterDr=TextEditingController(); rCasing=TextEditingController();
    tBeforeChoke=TextEditingController(); rLine=TextEditingController(); tLine=TextEditingController(); tAfterChoke=TextEditingController(); choke1=TextEditingController(); choke2=TextEditingController();
    nozzle=TextEditingController(); tWork=TextEditingController(); rDownhole=TextEditingController(); tDownhole=TextEditingController(); rKo=TextEditingController(); duValve=TextEditingController(); inhibitorFeed=TextEditingController(); note=TextEditingController();
    _loadLatest();
  }

  Future<void> _loadLatest() async {
    final latest = await repository.latestForWell(widget.wellId);
    final m = latest;
    if (m != null) {
      _setControllers(m);
      statuses.addAll(m.statuses);
    } else {
      _setFromWell();
    }
    if (mounted) setState(() => loading = false);
  }

  void _setFromWell() {
    rtr.text = _value(well.rtr);
    rz.text = _value(well.rz);
    pkvWork.text = well.pkvWork?.toString() ?? '';
    pkvIdle.text = well.pkvIdle?.toString() ?? '';
    frequency.text = _value(well.frequency);
    current.text = _value(well.current);
    load.text = _value(well.load);
    rp.text = _value(well.rp);
    tPed.text = _value(well.tPed);
    rInsul.text = _value(well.rInsul);
  }

  void _setControllers(Measurement m) {
    rtr.text = _value(m.rtr);
    rz.text = _value(m.rz);
    pkvWork.text = m.pkvWork?.toString() ?? '';
    pkvIdle.text = m.pkvIdle?.toString() ?? '';
    pidCurrent.text = _value(m.pidCurrent);
    pidFrequencyRange.text = m.pidFrequencyRange ?? '';
    frequency.text = _value(m.frequency);
    current.text = _value(m.current);
    load.text = _value(m.load);
    rp.text = _value(m.rp);
    tPed.text = _value(m.tPed);
    rInsul.text = _value(m.rInsul);
    gasState.text=m.gasState??''; rBuf.text=_value(m.rBuf); rBufSource.text=m.rBufSource??''; rInterDr.text=_value(m.rInterDr); rCasing.text=_value(m.rCasing);
    tBeforeChoke.text=_value(m.tBeforeChoke); rLine.text=_value(m.rLine); tLine.text=_value(m.tLine); tAfterChoke.text=_value(m.tAfterChoke); choke1.text=_value(m.choke1); choke2.text=_value(m.choke2);
    nozzle.text=m.nozzle??''; tWork.text=_value(m.tWork); rDownhole.text=_value(m.rDownhole); tDownhole.text=_value(m.tDownhole); rKo.text=_value(m.rKo); duValve.text=_value(m.duValve); inhibitorFeed.text=_value(m.inhibitorFeed); note.text=m.note??'';
  }

  String _value(double? value) => value == null ? '' : value.toString();

  @override
  void dispose() {
    for (final c in [rtr, rz, pkvWork, pkvIdle, pidCurrent, pidFrequencyRange, frequency, current, load, rp, tPed, rInsul, gasState, rBuf, rBufSource, rInterDr, rCasing, tBeforeChoke, rLine, tLine, tAfterChoke, choke1, choke2, nozzle, tWork, rDownhole, tDownhole, rKo, duValve, inhibitorFeed, note]) {
      c.dispose();
    }
    super.dispose();
  }

  int? get pkvCycle {
    final a = int.tryParse(pkvWork.text);
    final b = int.tryParse(pkvIdle.text);
    return a != null && b != null ? a + b : null;
  }

  double? _double(TextEditingController c) => double.tryParse(c.text.trim().replaceAll(',', '.'));
  int? _int(TextEditingController c) => int.tryParse(c.text.trim());

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    if (well.type == WellType.gasCondensate) return _gasCondensateScreen(context);
    return Scaffold(
      appBar: AppBar(
        title: Text('Скважина ${well.number}'),
        bottom: _walkIndicator(),
      ),
      body: Form(
        key: formKey,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 28),
          children: [
            Row(children: [Text(_statusText(well.status), style: const TextStyle(color: Colors.black54)), const Spacer(), const Text('Данные сохраняются локально', style: TextStyle(color: Colors.black54, fontSize: 12))]),
            const SizedBox(height: 16),
            _section('Давление', [_number('Ртр', rtr, 'кгс/см²'), _number('Рз', rz, 'кгс/см²')]),
            _section('ПКВ', [
              Row(children: [Expanded(child: _number('Работа', pkvWork, 'мин', integer: true)), const SizedBox(width: 10), Expanded(child: _number('Простой', pkvIdle, 'мин', integer: true))]),
              AnimatedBuilder(animation: Listenable.merge([pkvWork, pkvIdle]), builder: (_, __) => Padding(padding: const EdgeInsets.only(top: 8), child: Text('Цикл: ${pkvCycle == null ? '—' : '$pkvCycle мин'}', style: const TextStyle(color: Colors.black54)))),
            ]),
            _section('ПИД', [
              Row(children: [Expanded(child: _number('Ток ПИД', pidCurrent, 'А')), const SizedBox(width: 10), Expanded(child: _textWithStatus('Диапазон F', pidFrequencyRange, 'Диапазон F'))]),
            ]),
            _section('Фактические параметры', [
              Row(children: [Expanded(child: _number('F', frequency, 'Гц')), const SizedBox(width: 10), Expanded(child: _number('Iср', current, 'А'))]),
              const SizedBox(height: 10),
              Row(children: [Expanded(child: _number('Загрузка', load, '%')), const SizedBox(width: 10), Expanded(child: _number('Рпр', rp, 'атм'))]),
              const SizedBox(height: 10),
              Row(children: [Expanded(child: _number('Тпэд', tPed, '°C')), const SizedBox(width: 10), Expanded(child: _number('Rизол', rInsul, 'кОм'))]),
            ]),
            const SizedBox(height: 8),
            const Text('ПЭД: Рпр, Тпэд и Rизол', style: TextStyle(color: Colors.black54)),
            const SizedBox(height: 18),
            FilledButton.icon(onPressed: saving ? null : _save, icon: saving ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.save_outlined), label: Text(saving ? 'Сохранение…' : 'Сохранить замер'), style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 15))),
          ],
        ),
      ),
    );
  }

  PreferredSizeWidget? _walkIndicator() {
    final index = widget.walkIndex;
    if (index == null) return null;
    final pad = demoPads.firstWhere((p) => p.id == widget.padId);
    return PreferredSize(
      preferredSize: const Size.fromHeight(34),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
        child: Align(
          alignment: Alignment.centerLeft,
          child: Text('${index + 1} из ${pad.wells.length}', style: const TextStyle(fontSize: 12)),
        ),
      ),
    );
  }

  Widget _gasCondensateScreen(BuildContext context) {
    return Scaffold(
    appBar: AppBar(
      title: Text('Скважина ${well.number}'),
      bottom: _walkIndicator(),
    ),
    body: Form(key: formKey, child: ListView(padding: const EdgeInsets.fromLTRB(16,4,16,28), children: [
      const Text('Газоконденсатный профиль', style: TextStyle(fontSize:20,fontWeight:FontWeight.w800)),
      const SizedBox(height:12),
      _section('Режим работы', [DropdownButtonFormField<String>(value: gasState.text.isEmpty?null:gasState.text, decoration: const InputDecoration(labelText:'Состояние'), items: const [DropdownMenuItem(value:'Работает в общий коллектор',child:Text('Работает в общий коллектор')),DropdownMenuItem(value:'Работает на коллектор',child:Text('Работает на коллектор'))], onChanged:(v)=>gasState.text=v??'')]),
      _section('Буфер и затрубное давление', [_number('Рбуф',rBuf,'МПа'), DropdownButtonFormField<String>(value:rBufSource.text.isEmpty?null:rBufSource.text, decoration:const InputDecoration(labelText:'Источник Рбуф'), items:const [DropdownMenuItem(value:'Механический манометр',child:Text('Механический манометр')),DropdownMenuItem(value:'БЭЛП',child:Text('БЭЛП')),DropdownMenuItem(value:'УМТ',child:Text('УМТ'))], onChanged:(v)=>rBufSource.text=v??''), _number('Рмеж. др.',rInterDr,'МПа'), _number('Рзатр',rCasing,'МПа')]),
      _section('Температура и линия', [Row(children:[Expanded(child:_number('Т до дросселя',tBeforeChoke,'°C')),const SizedBox(width:10),Expanded(child:_number('Рлин',rLine,'МПа'))]), const SizedBox(height:10), Row(children:[Expanded(child:_number('Тлин',tLine,'°C')),const SizedBox(width:10),Expanded(child:_number('Т после дросселя',tAfterChoke,'°C'))])]),
      _section('Дросселирование', [Row(children:[Expanded(child:_number('Дроссель 1',choke1,'%')),const SizedBox(width:10),Expanded(child:_number('Дроссель 2',choke2,'%'))]), const SizedBox(height:10), _textWithStatus('Штуцер', nozzle, 'Штуцер', hint:'Если вместо % указано сечение')]),
      _section('Рабочие параметры', [Row(children:[Expanded(child:_number('Траб',tWork,'°C')),const SizedBox(width:10),Expanded(child:_number('Рузд',rDownhole,'МПа'))]), const SizedBox(height:10), Row(children:[Expanded(child:_number('Тузд',tDownhole,'°C')),const SizedBox(width:10),Expanded(child:_number('Рко',rKo,'МПа'))]), _textWithStatus('Шибер ДУ', duValve, 'Шибер ДУ'), _number('Подача ингибитора',inhibitorFeed,'кг/ч')]),
      _section('Замечание', [TextFormField(controller:note,maxLines:3,decoration:const InputDecoration(labelText:'Комментарий оператора',hintText:'Например: показания не меняются / ошибка в БЭЛП'))]),
      const SizedBox(height:8), FilledButton.icon(onPressed:saving?_nullSave:_save, icon:saving?const SizedBox(width:20,height:20,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.save_outlined), label:Text(saving?'Сохранение…':'Сохранить замер'), style:FilledButton.styleFrom(padding:const EdgeInsets.symmetric(vertical:15))),
    ])),
  );
  }

  VoidCallback? get _nullSave => null;

  Widget _section(String title, List<Widget> children) => Card(margin: const EdgeInsets.only(bottom: 12), child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)), const SizedBox(height: 12), ...children])));

  Widget _number(String label, TextEditingController controller, String unit, {bool integer = false, String? key}) {
    final statusKey = key ?? label;
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      TextFormField(
        controller: controller,
        keyboardType: TextInputType.numberWithOptions(decimal: !integer),
        decoration: InputDecoration(labelText: label, suffixText: unit, hintText: 'Не измерено'),
        validator: (v) {
          if (v == null || v.trim().isEmpty) return null;
          final n = double.tryParse(v.replaceAll(',', '.'));
          if (n == null || !n.isFinite || (integer && n % 1 != 0) || n < 0) return 'Проверьте значение';
          return null;
        },
      ),
      DropdownButtonFormField<String>(
        value: statuses[statusKey] ?? 'measured',
        isExpanded: true,
        decoration: const InputDecoration(labelText: 'Статус показания', isDense: true),
        items: statusLabels.entries.map((e) => DropdownMenuItem(value: e.key, child: Text(e.value))).toList(),
        onChanged: (v) { if (v != null) setState(() => statuses[statusKey] = v); },
      ),
    ]);
  }

  Widget _textWithStatus(String label, TextEditingController controller, String key, {String? hint}) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    TextFormField(controller: controller, decoration: InputDecoration(labelText: label, hintText: hint)),
    DropdownButtonFormField<String>(
      value: statuses[key] ?? 'measured', isExpanded: true,
      decoration: const InputDecoration(labelText: 'Статус показания', isDense: true),
      items: statusLabels.entries.map((e) => DropdownMenuItem(value: e.key, child: Text(e.value))).toList(),
      onChanged: (v) { if (v != null) setState(() => statuses[key] = v); },
    ),
  ]);

  String _statusText(WellStatus s) => switch (s) {
    WellStatus.working => 'Работает',
    WellStatus.stopped => 'Остановлена',
    WellStatus.krs => 'КРС',
    WellStatus.pdf => 'ПДФ',
    WellStatus.disabled => 'Отключен',
    WellStatus.underload => 'Недогруз',
  };

  Future<void> _save() async {
    if (!(formKey.currentState?.validate() ?? false)) return;
    setState(() => saving = true);
    try {
      await repository.save(Measurement(
        padId: widget.padId,
        wellId: widget.wellId,
        wellNumber: well.number,
        measuredAt: DateTime.now(),
        rtr: _double(rtr),
        rz: _double(rz),
        pkvWork: _int(pkvWork),
        pkvIdle: _int(pkvIdle),
        frequency: _double(frequency),
        current: _double(current),
        load: _double(load),
        rp: _double(rp),
        tPed: _double(tPed),
        rInsul: _double(rInsul),
        pidCurrent: _double(pidCurrent),
        pidFrequencyRange: pidFrequencyRange.text.trim().isEmpty ? null : pidFrequencyRange.text.trim(),
        gasState: gasState.text.trim().isEmpty ? null : gasState.text.trim(), rBuf: _double(rBuf), rBufSource: rBufSource.text.trim().isEmpty ? null : rBufSource.text.trim(), rInterDr: _double(rInterDr), rCasing: _double(rCasing), tBeforeChoke: _double(tBeforeChoke), rLine: _double(rLine), tLine: _double(tLine), tAfterChoke: _double(tAfterChoke), choke1: _double(choke1), choke2: _double(choke2), nozzle: nozzle.text.trim().isEmpty ? null : nozzle.text.trim(), tWork: _double(tWork), rDownhole: _double(rDownhole), tDownhole: _double(tDownhole), rKo: _double(rKo), duValve: _double(duValve), inhibitorFeed: _double(inhibitorFeed), note: note.text.trim().isEmpty ? null : note.text.trim(),
        statuses: Map<String,String>.from(statuses),
      ));
      if (!mounted) return;
      if (widget.walkIndex != null) {
        final pad = demoPads.firstWhere((p) => p.id == widget.padId);
        if (widget.walkIndex! + 1 < pad.wells.length) {
          await repository.saveWalk(widget.padId, widget.walkIndex! + 1);
          context.go('/pad/${widget.padId}/walk/${widget.walkIndex! + 1}');
        } else {
          await repository.finishWalk(widget.padId);
          context.go('/pad/${widget.padId}/walk-summary');
        }
      } else {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Замер сохранён в памяти телефона')));
        context.pop();
      }
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }
}
