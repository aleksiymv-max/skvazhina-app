import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../core/services/session_service.dart';

class LoginScreen extends StatefulWidget { const LoginScreen({super.key}); @override State<LoginScreen> createState()=>_LoginScreenState(); }
class _LoginScreenState extends State<LoginScreen> {
  final username=TextEditingController(text:'op-001');
  final password=TextEditingController(text:'operator');
  bool loading=false; String? error;
  @override Widget build(BuildContext context)=>Scaffold(body:Center(child:SingleChildScrollView(padding:const EdgeInsets.all(24),child:ConstrainedBox(constraints:const BoxConstraints(maxWidth:440),child:Card(child:Padding(padding:const EdgeInsets.all(24),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
    const Icon(Icons.oil_barrel_outlined,size:48),const SizedBox(height:16),const Text('Приложение нефтяника',style:TextStyle(fontSize:25,fontWeight:FontWeight.w800)),const SizedBox(height:8),const Text('Вход в рабочий профиль',style:TextStyle(color:Colors.black54)),const SizedBox(height:24),
    TextField(controller:username,decoration:const InputDecoration(labelText:'Логин')),const SizedBox(height:12),
    TextField(controller:password,obscureText:true,decoration:const InputDecoration(labelText:'Пароль')),
    if(error!=null) Padding(padding:const EdgeInsets.only(top:12),child:Text(error!,style:const TextStyle(color:Colors.red))),
    const SizedBox(height:18),SizedBox(width:double.infinity,child:FilledButton(onPressed:loading?null:_login,child:Text(loading?'Вход…':'Войти на сервер'))),
    const SizedBox(height:12),const Text('Тестовые учётные записи: op-001/operator, eng-001/engineer, mgr-001/manager, adm-001/admin',style:TextStyle(color:Colors.black54,fontSize:12)),
  ])))))));
  Future<void> _login() async { setState(()=>loading=true); try { await SessionService.instance.login(username.text.trim(),password.text); if(mounted) context.go('/'); } catch(e){ if(mounted)setState(()=>error=e.toString()); } finally { if(mounted)setState(()=>loading=false); } }
  @override void dispose(){username.dispose();password.dispose();super.dispose();}
}
