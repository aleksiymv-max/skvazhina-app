import 'package:flutter/material.dart';

class TrendsScreen extends StatelessWidget {
  const TrendsScreen({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Тренды')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      const Text('КП 1017 · Скважина 10079', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
      const SizedBox(height: 4),
      const Text('Частота F · последние 7 дней', style: TextStyle(color: Colors.black54)),
      const SizedBox(height: 18),
      Card(child: Padding(padding: const EdgeInsets.all(16), child: SizedBox(height: 220, child: CustomPaint(painter: _TrendPainter())))),
      const SizedBox(height: 12),
      const Card(child: ListTile(title: Text('Текущее значение'), trailing: Text('55 Гц', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)))),
    ]),
  );
}

class _TrendPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final axis = Paint()..color = const Color(0xFFD0D6DC)..strokeWidth = 1;
    final line = Paint()..color = const Color(0xFF1769AA)..strokeWidth = 4..style = PaintingStyle.stroke;
    canvas.drawLine(const Offset(20, 10), Offset(20, size.height - 25), axis);
    canvas.drawLine(Offset(20, size.height - 25), Offset(size.width - 10, size.height - 25), axis);
    final points = [
      Offset(30, size.height * .62), Offset(size.width * .2, size.height * .53), Offset(size.width * .36, size.height * .59),
      Offset(size.width * .52, size.height * .38), Offset(size.width * .67, size.height * .45), Offset(size.width * .82, size.height * .30), Offset(size.width * .94, size.height * .40),
    ];
    final path = Path()..moveTo(points.first.dx, points.first.dy);
    for (final p in points.skip(1)) path.lineTo(p.dx, p.dy);
    canvas.drawPath(path, line);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
