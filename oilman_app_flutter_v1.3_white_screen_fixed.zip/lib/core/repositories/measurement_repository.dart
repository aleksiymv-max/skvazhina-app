import '../database/app_database.dart';
import '../models/measurement.dart';

class MeasurementRepository {
  MeasurementRepository({AppDatabase? database}) : _database = database ?? AppDatabase.instance;
  final AppDatabase _database;
  Future<int> save(Measurement m) => _database.insertMeasurement(m);
  Future<Measurement?> latestForWell(String id) => _database.latestForWell(id);
  Future<List<Measurement>> history({String? padId,String? wellId,int limit=100}) => _database.history(padId:padId,wellId:wellId,limit:limit);
  Future<void> saveWalk(String padId,int index) => _database.saveWalk(padId,index);
  Future<Map<String,Object?>?> activeWalk(String padId) => _database.activeWalk(padId);
  Future<void> finishWalk(String padId) => _database.finishWalk(padId);
  Future<int> checkedCount(String padId) => _database.checkedCount(padId);
}
