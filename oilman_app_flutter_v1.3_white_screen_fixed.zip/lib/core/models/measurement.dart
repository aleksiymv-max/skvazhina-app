class Measurement {
  const Measurement({
    this.id,
    required this.padId,
    required this.wellId,
    required this.wellNumber,
    required this.measuredAt,
    this.rtr, this.rz, this.pkvWork, this.pkvIdle,
    this.frequency, this.current, this.load, this.rp, this.tPed, this.rInsul,
    this.pidCurrent, this.pidFrequencyRange,
    this.gasState, this.rBuf, this.rBufSource, this.rInterDr, this.rCasing,
    this.tBeforeChoke, this.rLine, this.tLine, this.tAfterChoke,
    this.choke1, this.choke2, this.nozzle,
    this.tWork, this.rDownhole, this.tDownhole, this.rKo, this.duValve,
    this.inhibitorFeed, this.note,
    this.source = 'Оператор',
    this.statuses = const {},
  });

  final int? id;
  final String padId, wellId, wellNumber;
  final DateTime measuredAt;
  final double? rtr, rz;
  final int? pkvWork, pkvIdle;
  final double? frequency, current, load, rp, tPed, rInsul;
  final double? pidCurrent;
  final String? pidFrequencyRange;
  final String? gasState;
  final double? rBuf;
  final String? rBufSource;
  final double? rInterDr, rCasing, tBeforeChoke, rLine, tLine, tAfterChoke;
  final double? choke1, choke2;
  final String? nozzle;
  final double? tWork, rDownhole, tDownhole, rKo, duValve, inhibitorFeed;
  final String? note;
  final String source;
  /// Статус каждого показания: measured, no_reading, unavailable, not_applicable, device_error.
  final Map<String, String> statuses;

  String statusOf(String key) => statuses[key] ?? 'measured';

  int? get pkvCycle => pkvWork != null && pkvIdle != null ? pkvWork! + pkvIdle! : null;
}
