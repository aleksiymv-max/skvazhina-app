enum WellType { oil, gasCondensate }

enum WellStatus { working, stopped, krs, pdf, disabled, underload }

class Well {
  const Well({
    required this.id,
    required this.number,
    required this.type,
    required this.status,
    this.pkvWork,
    this.pkvIdle,
    this.rtr,
    this.rz,
    this.frequency,
    this.current,
    this.load,
    this.rp,
    this.tPed,
    this.rInsul,
  });

  final String id;
  final String number;
  final WellType type;
  final WellStatus status;
  final int? pkvWork;
  final int? pkvIdle;
  final double? rtr;
  final double? rz;
  final double? frequency;
  final double? current;
  final double? load;
  final double? rp;
  final double? tPed;
  final double? rInsul;

  int? get pkvCycle => pkvWork != null && pkvIdle != null ? pkvWork! + pkvIdle! : null;
}
