import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/measurement.dart';
import 'api_config.dart';

class ApiClient {
  ApiClient({String? baseUrl}) : baseUrl = (baseUrl ?? ApiConfig.baseUrl).replaceFirst(RegExp(r'/$'), '');
  static final ApiClient instance = ApiClient();
  final String baseUrl;
  String? token;

  Map<String, String> get _headers => {
    'Content-Type': 'application/json',
    if (token != null) 'Authorization': 'Bearer $token',
  };

  Future<bool> health() async {
    final response = await http.get(Uri.parse('$baseUrl/health')).timeout(const Duration(seconds: 5));
    return response.statusCode == 200;
  }

  Future<Map<String, dynamic>> login(String username, String password) async {
    final response = await http.post(
      Uri.parse('$baseUrl/api/v1/auth/login'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'username': username, 'password': password}),
    ).timeout(const Duration(seconds: 10));
    if (response.statusCode != 200) throw ApiException('Ошибка входа: ${response.statusCode}', response.statusCode);
    final data = jsonDecode(response.body) as Map<String, dynamic>;
    token = data['access_token'] as String?;
    return data;
  }


  Future<List<Map<String, dynamic>>> fetchPads() async {
    final response = await http.get(Uri.parse('$baseUrl/api/v1/pads'), headers: _headers).timeout(const Duration(seconds: 10));
    if (response.statusCode != 200) throw ApiException('Не удалось загрузить кустовые площадки: ${response.statusCode}', response.statusCode);
    return List<Map<String, dynamic>>.from(jsonDecode(response.body) as List);
  }

  Future<List<Map<String, dynamic>>> fetchWells(String padId) async {
    final response = await http.get(Uri.parse('$baseUrl/api/v1/pads/$padId/wells'), headers: _headers).timeout(const Duration(seconds: 10));
    if (response.statusCode != 200) throw ApiException('Не удалось загрузить скважины: ${response.statusCode}', response.statusCode);
    return List<Map<String, dynamic>>.from(jsonDecode(response.body) as List);
  }

  Future<Map<String, dynamic>> syncMeasurements(List<Measurement> measurements) async {
    if (token == null) throw const ApiException('Нет токена авторизации');
    final response = await http.post(
      Uri.parse('$baseUrl/api/v1/sync/measurements'),
      headers: _headers,
      body: jsonEncode(measurements.map(_measurementJson).toList()),
    ).timeout(const Duration(seconds: 20));
    if (response.statusCode != 200) throw ApiException('Ошибка синхронизации: ${response.statusCode}', response.statusCode);
    return jsonDecode(response.body) as Map<String, dynamic>;
  }

  Map<String, dynamic> _measurementJson(Measurement m) => {
    'id': 'local-${m.id}', 'pad_id': m.padId, 'well_id': m.wellId, 'well_number': m.wellNumber,
    'measured_at': m.measuredAt.toUtc().toIso8601String(), 'source': m.source, 'statuses': m.statuses,
    'payload': {
      'rtr': m.rtr, 'rz': m.rz, 'pkvWork': m.pkvWork, 'pkvIdle': m.pkvIdle, 'frequency': m.frequency,
      'current': m.current, 'load': m.load, 'rp': m.rp, 'tPed': m.tPed, 'rInsul': m.rInsul,
      'pidCurrent': m.pidCurrent, 'pidFrequencyRange': m.pidFrequencyRange, 'gasState': m.gasState,
      'rBuf': m.rBuf, 'rBufSource': m.rBufSource, 'rInterDr': m.rInterDr, 'rCasing': m.rCasing,
      'tBeforeChoke': m.tBeforeChoke, 'rLine': m.rLine, 'tLine': m.tLine, 'tAfterChoke': m.tAfterChoke,
      'choke1': m.choke1, 'choke2': m.choke2, 'nozzle': m.nozzle, 'tWork': m.tWork,
      'rDownhole': m.rDownhole, 'tDownhole': m.tDownhole, 'rKo': m.rKo, 'duValve': m.duValve,
      'inhibitorFeed': m.inhibitorFeed, 'note': m.note,
    }..removeWhere((_, value) => value == null),
  };
}

class ApiException implements Exception {
  const ApiException(this.message, [this.statusCode]);
  final String message;
  final int? statusCode;
  @override String toString() => message;
}
