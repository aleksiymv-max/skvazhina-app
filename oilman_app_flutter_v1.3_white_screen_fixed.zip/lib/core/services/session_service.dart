import '../models/user.dart';
import '../network/api_client.dart';

class SessionService {
  SessionService._();
  static final instance = SessionService._();
  AppUser currentUser = const AppUser(id: 'op-001', name: 'Оператор', role: UserRole.operator);
  final ApiClient api = ApiClient.instance;
  String? get token => api.token;

  Future<void> logout() async { api.token = null; currentUser = const AppUser(id: '', name: '', role: UserRole.operator); }

  Future<void> login(String username, String password) async {
    final data = await api.login(username, password);
    final u = data['user'] as Map<String, dynamic>;
    final role = UserRole.values.firstWhere((r) => r.name == u['role']);
    currentUser = AppUser(id: u['id'] as String, name: u['name'] as String, role: role);
  }
}
