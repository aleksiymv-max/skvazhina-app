import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import '../models/measurement.dart';
import '../database/app_database.dart';
import '../network/api_client.dart';
import 'session_service.dart';

class SyncService extends ChangeNotifier {
  SyncService._();
  static final instance = SyncService._();
  final AppDatabase _db = AppDatabase.instance;
  final ApiClient _api = ApiClient.instance;
  StreamSubscription<List<ConnectivityResult>>? _subscription;
  bool _online = true, _syncing = false, _serverAvailable = false;
  int pending = 0;
  DateTime? lastSyncAt;
  String status = 'Все данные синхронизированы';
  bool get online => _online;
  bool get syncing => _syncing;
  bool get serverAvailable => _serverAvailable;

  Future<void> initialize() async {
    final result = await Connectivity().checkConnectivity();
    _online = !result.contains(ConnectivityResult.none);
    await _refreshCount();
    _subscription ??= Connectivity().onConnectivityChanged.listen((results) {
      _online = !results.contains(ConnectivityResult.none);
      notifyListeners();
      if (_online) syncNow(); else _refreshCount();
    });
    if (_online) await syncNow();
  }

  Future<void> _refreshCount() async {
    pending = await _db.pendingSyncCount();
    if (!_online) status = pending == 0 ? 'Нет связи' : 'Нет связи · в очереди: $pending';
    else if (!_serverAvailable) status = pending == 0 ? 'Связь есть · сервер недоступен' : 'Сервер недоступен · в очереди: $pending';
    else if (_api.token == null) status = pending == 0 ? 'Сервер доступен · войдите в систему' : 'Войдите для синхронизации · в очереди: $pending';
    else status = pending == 0 ? 'Все данные синхронизированы' : 'Ожидает синхронизации: $pending';
    notifyListeners();
  }

  Future<void> syncNow() async {
    if (!_online || _syncing) return;
    _syncing = true; status = 'Проверка сервера…'; notifyListeners();
    try {
      try { _serverAvailable = await _api.health(); } catch (_) { _serverAvailable = false; }
      if (!_serverAvailable || _api.token == null) return;
      final rows = await _db.pendingSyncItems();
      final measurements = <Measurement>[];
      final queueIds = <int>[];
      for (final row in rows) {
        final m = await _db.byId(row['entity_id'] as int);
        if (m != null) { measurements.add(m); queueIds.add(row['id'] as int); }
      }
      if (measurements.isEmpty) { lastSyncAt = DateTime.now(); return; }
      status = 'Синхронизация: ${measurements.length}'; notifyListeners();
      final result = await _api.syncMeasurements(measurements);
      final accepted = {for (final x in (result['accepted'] as List? ?? const [])) x.toString()};
      final duplicates = {for (final x in (result['duplicates'] as List? ?? const [])) x.toString()};
      for (var i=0; i<measurements.length; i++) {
        final remoteId = 'local-${measurements[i].id}';
        if (accepted.contains(remoteId) || duplicates.contains(remoteId)) {
          await _db.markSynced(queueIds[i], measurements[i].id!);
        }
      }
      lastSyncAt = DateTime.now();
    } catch (e) {
      status = 'Ошибка синхронизации: $e';
    } finally {
      _syncing = false;
      await _refreshCount();
    }
  }

  Future<void> dispose() async => _subscription?.cancel();
}
