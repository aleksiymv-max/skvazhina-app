package ru.oilman.oilman_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
