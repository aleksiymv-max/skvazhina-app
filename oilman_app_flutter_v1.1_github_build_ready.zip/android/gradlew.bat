@echo off
setlocal
set GRADLE_VERSION=8.9
set CACHE_ROOT=%USERPROFILE%\.gradle\oilman-gradle
set GRADLE_HOME=%CACHE_ROOT%\gradle-%GRADLE_VERSION%
if not exist "%GRADLE_HOME%\bin\gradle.bat" (
  if not exist "%CACHE_ROOT%" mkdir "%CACHE_ROOT%"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%CACHE_ROOT%\gradle-%GRADLE_VERSION%-bin.zip'"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force '%CACHE_ROOT%\gradle-%GRADLE_VERSION%-bin.zip' '%CACHE_ROOT%'"
)
call "%GRADLE_HOME%\bin\gradle.bat" %*
endlocal
