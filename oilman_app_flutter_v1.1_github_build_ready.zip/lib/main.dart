import 'package:flutter/material.dart';
import 'core/services/sync_service.dart';

import 'app/app.dart';
import 'core/database/app_database.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await AppDatabase.instance.database;
  await SyncService.instance.initialize();
  runApp(const OilmanApp());
}
