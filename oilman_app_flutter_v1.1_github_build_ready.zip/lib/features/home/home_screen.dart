import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../core/models/pad.dart';
import '../../shared/widgets/status_chip.dart';
import '../../core/services/session_service.dart';
import '../../core/services/sync_service.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final searchController = TextEditingController();
  List<Pad> pads = demoPads;
  bool loadingPads = true;
  String? catalogError;

  @override
  void initState() {
    super.initState();
    _loadPads();
  }

  Future<void> _loadPads() async {
    try {
      if (SessionService.instance.token != null) {
        final rows = await SessionService.instance.api.fetchPads();
        pads = rows.map((row) => Pad(id: row['id'].toString(), name: row['name'].toString(), type: row['type'].toString(), wells: const [])).toList();
      }
    } catch (e) {
      catalogError = 'Не удалось загрузить данные сервера. Используются сохранённые данные.';
    } finally {
      if (mounted) setState(() => loadingPads = false);
    }
  }

  @override
  void dispose() {
    searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final query = searchController.text.trim().toLowerCase();
    final filteredPads = pads.where((p) => p.name.toLowerCase().contains(query)).toList();

    return Scaffold(
      appBar: AppBar(title: const Text('Приложение нефтяника'), actions: [Padding(padding: const EdgeInsets.only(right: 12), child: Center(child: Text(SessionService.instance.currentUser.role.label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)))), IconButton(tooltip: 'Выйти', onPressed: () async { await SessionService.instance.logout(); if (context.mounted) context.go('/login'); }, icon: const Icon(Icons.logout))]),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
        children: [
          _syncCard(),
          const SizedBox(height: 18),
          TextField(
            controller: searchController,
            onChanged: (_) => setState(() {}),
            decoration: const InputDecoration(
              labelText: 'Поиск кустовой площадки',
              hintText: 'Например, КП 1017',
              prefixIcon: Icon(Icons.search),
            ),
          ),
          const SizedBox(height: 12),
          if (catalogError != null) Padding(padding: const EdgeInsets.only(bottom: 10), child: Text(catalogError!, style: const TextStyle(color: Colors.orange))),
          const SizedBox(height: 8),
          const Text('Кустовые площадки', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
          const SizedBox(height: 10),
          if (loadingPads) const Padding(padding: EdgeInsets.all(24), child: Center(child: CircularProgressIndicator())),
          ...filteredPads.map((pad) => _padCard(context, pad)),
          const SizedBox(height: 18),
          Row(children: [
            Expanded(child: _bottomButton(context, Icons.show_chart, 'Тренды', '/trends')),
            const SizedBox(width: 10),
            Expanded(child: _bottomButton(context, Icons.history, 'История', '/history')),
          ]),
        ],
      ),
    );
  }

  Widget _syncCard() => AnimatedBuilder(
        animation: SyncService.instance,
        builder: (context, _) {
          final sync = SyncService.instance;
          final ok = sync.online && sync.pending == 0 && !sync.syncing;
          return Card(
            margin: EdgeInsets.zero,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(children: [
                Icon(sync.online ? Icons.cloud_outlined : Icons.cloud_off_outlined,
                    color: ok ? const Color(0xFF23864B) : Colors.orange.shade800),
                const SizedBox(width: 12),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('Синхронизация', style: TextStyle(fontWeight: FontWeight.w700)),
                  const SizedBox(height: 3),
                  Text(sync.status, style: const TextStyle(color: Colors.black54)),
                ])),
                if (sync.online && sync.pending > 0)
                  IconButton(tooltip: 'Синхронизировать', onPressed: sync.syncing ? null : sync.syncNow, icon: const Icon(Icons.sync)),
                StatusChip(label: sync.syncing ? 'Синхронизация' : (sync.online ? 'Онлайн' : 'Офлайн'), kind: ok ? StatusKind.ok : StatusKind.warning),
              ]),
            ),
          );
        },
      );

  Widget _padCard(BuildContext context, Pad pad) => Card(
        margin: const EdgeInsets.only(bottom: 10),
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: () => context.push('/pad/${pad.id}'),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(color: Theme.of(context).colorScheme.primaryContainer, borderRadius: BorderRadius.circular(14)),
                child: const Icon(Icons.factory_outlined),
              ),
              const SizedBox(width: 14),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(pad.name, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
                const SizedBox(height: 3),
                Text('${pad.wells.length} скважин · ${pad.type}', style: const TextStyle(color: Colors.black54)),
              ])),
              const Icon(Icons.chevron_right),
            ]),
          ),
        ),
      );

  Widget _bottomButton(BuildContext context, IconData icon, String title, String route) => OutlinedButton.icon(
        onPressed: () => context.push(route),
        icon: Icon(icon),
        label: Text(title),
        style: OutlinedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 14)),
      );
}
