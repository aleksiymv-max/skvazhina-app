import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../core/models/measurement.dart';
import '../../core/models/pad.dart';
import '../../core/models/well.dart';
import '../../core/repositories/measurement_repository.dart';

class WellCardScreen extends StatefulWidget {
  const WellCardScreen({super.key, required this.padId, required this.wellId});
  final String padId, wellId;
  @override State<WellCardScreen> createState()=>_WellCardScreenState();
}
class _WellCardScreenState extends State<WellCardScreen>{
  final repo=MeasurementRepository(); Measurement? latest; List<Measurement> data=[]; int days=7; final Set<String> selected={}; bool loading=true; int? touched;
  Pad get pad=>demoPads.firstWhere((p)=>p.id==widget.padId); Well get well=>pad.wells.firstWhere((w)=>w.id==widget.wellId);
  List<MapEntry<String,String>> get params=>well.type==WellType.gasCondensate?const {'r_buf':'Рбуф, МПа','rtr':'Ртр, МПа','r_line':'Рлин, МПа','t_before_choke':'Тдо штуцера, °C','t_line':'Тлин, °C','choke_value':'Дроссель 1','choke_value2':'Дроссель 2','r_downhole':'Рузд, МПа','t_downhole':'Тузд, °C','r_ko':'Рко, МПа','inhibitor_feed':'Ингибитор, л/ч'}.entries.toList():const {'rtr':'Ртр, МПа','rz':'Рз, МПа','frequency':'F, Гц','current':'Iср, А','load':'Загрузка, %','rp':'Рпр, МПа','t_ped':'Тпэд, °C','r_insul':'Rизол'}.entries.toList();
  @override void initState(){super.initState();selected.addAll(params.take(2).map((e)=>e.key));_load();}
  Future<void> _load()async{setState(()=>loading=true);latest=await repo.latestForWell(well.id);data=await repo.trends(wellId:well.id,from:DateTime.now().subtract(Duration(days:days)),to:DateTime.now());if(mounted)setState((){loading=false;touched=null;});}
  double? value(Measurement m,String k)=>switch(k){'rtr'=>m.rtr,'rz'=>m.rz,'frequency'=>m.frequency,'current'=>m.current,'load'=>m.load,'rp'=>m.rp,'t_ped'=>m.tPed,'r_insul'=>m.rInsul,'r_buf'=>m.rBuf,'r_line'=>m.rLine,'t_before_choke'=>m.tBeforeChoke,'t_line'=>m.tLine,'choke_value'=>m.chokeValue,'choke_value2'=>m.chokeValue2,'r_downhole'=>m.rDownhole,'t_downhole'=>m.tDownhole,'r_ko'=>m.rKo,'inhibitor_feed'=>m.inhibitorFeed,_=>null};
  String get typeName=>well.type==WellType.oil?'Нефтяная':'Газоконденсатная';
  String get statusName=>switch(well.status){WellStatus.working=>'В работе',WellStatus.workover=>'ВНР',WellStatus.stopped=>'Остановлена'};
  String labelFor(String k)=>params.firstWhere((e)=>e.key==k,orElse:()=>MapEntry(k,k)).value;
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text('Скважина ${well.number}')),body:loading?const Center(child:CircularProgressIndicator()):ListView(padding:const EdgeInsets.all(16),children:[
    Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Row(children:[Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('Скважина ${well.number}',style:const TextStyle(fontSize:22,fontWeight:FontWeight.w900)),Text('$typeName · ${pad.areaName} · ${pad.name}',style:const TextStyle(color:Colors.black54))])),Chip(label:Text(statusName))]),if(latest!=null)...[const Divider(height:26),Text('Последний замер: ${DateFormat('dd.MM.yyyy HH:mm').format(latest!.measuredAt)}'),Text('Оператор: ${latest!.operatorName??'—'}')]]))),
    const SizedBox(height:12),_latestCard(),const SizedBox(height:12),
    Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      const Text('Тренды',style:TextStyle(fontSize:20,fontWeight:FontWeight.w900)),const SizedBox(height:5),const Text('Можно выбрать несколько параметров. Нажмите на график, чтобы увидеть показания и время.',style:TextStyle(color:Colors.black54,fontSize:12)),const SizedBox(height:12),
      SegmentedButton<int>(segments:const [ButtonSegment(value:1,label:Text('24 ч')),ButtonSegment(value:7,label:Text('7 д')),ButtonSegment(value:30,label:Text('30 д')),ButtonSegment(value:90,label:Text('90 д'))],selected:{days},onSelectionChanged:(v){days=v.first;_load();}),const SizedBox(height:12),
      Wrap(spacing:6,runSpacing:6,children:params.map((e)=>FilterChip(label:Text(e.value),selected:selected.contains(e.key),onSelected:(v)=>setState((){if(v)selected.add(e.key);else selected.remove(e.key);touched=null;}))).toList()),const SizedBox(height:12),
      if(selected.isEmpty)const SizedBox(height:280,child:Center(child:Text('Выберите хотя бы один параметр')))
      else _interactiveChart(),
    ]))),
  ]));
  Widget _interactiveChart(){final keys=selected.toList();return Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('Левая шкала — первый параметр, правая — остальные выбранные параметры',style:TextStyle(fontWeight:FontWeight.w700,fontSize:12)),const SizedBox(height:6),SizedBox(height:330,child:LayoutBuilder(builder:(context,c)=>GestureDetector(behavior:HitTestBehavior.opaque,onTapDown:(d){if(data.isEmpty)return;const left=58.0,right=58.0;final usable=(c.maxWidth-left-right).clamp(1.0,double.infinity);final f=((d.localPosition.dx-left)/usable).clamp(0.0,1.0);setState(()=>touched=(f*(data.length-1)).round().clamp(0,data.length-1));},child:CustomPaint(size:Size(c.maxWidth,330),painter:_TrendPainter(data:data,keys:keys,getter:value,touched:touched))))),if(touched!=null&&touched!<data.length)_tooltip(data[touched!],keys)]);}
  Widget _tooltip(Measurement m,List<String> keys)=>Container(margin:const EdgeInsets.only(top:8),padding:const EdgeInsets.all(12),decoration:BoxDecoration(color:const Color(0xFFF2F7FF),borderRadius:BorderRadius.circular(12)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(DateFormat('dd.MM.yyyy HH:mm').format(m.measuredAt),style:const TextStyle(fontWeight:FontWeight.w900)),const SizedBox(height:5),...keys.map((k)=>Text('${labelFor(k)}: ${value(m,k)?.toStringAsFixed(2)??'—'}'))]));
  Widget _latestCard(){if(latest==null)return const Card(child:Padding(padding:EdgeInsets.all(18),child:Text('По скважине пока нет замеров.')));final m=latest!;return Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('Текущие параметры',style:TextStyle(fontSize:18,fontWeight:FontWeight.w900)),const SizedBox(height:10),Wrap(spacing:8,runSpacing:8,children:params.map((e){final v=value(m,e.key);return Container(width:150,padding:const EdgeInsets.all(12),decoration:BoxDecoration(color:const Color(0xFFF2F7FF),borderRadius:BorderRadius.circular(14)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(e.value,style:const TextStyle(fontSize:11,color:Colors.black54)),Text(v==null?'—':v.toStringAsFixed(2),style:const TextStyle(fontSize:18,fontWeight:FontWeight.w900))]));}).toList())])));}
}
class _TrendPainter extends CustomPainter{
  _TrendPainter({required this.data,required this.keys,required this.getter,this.touched});
  final List<Measurement> data; final List<String> keys; final double? Function(Measurement,String) getter; final int? touched;
  static const palette=[Colors.blue,Colors.orange,Colors.green,Colors.purple,Colors.red,Colors.teal];
  @override void paint(Canvas c,Size s){
    const l=58.0,r=58.0,t=18.0,b=46.0;final w=s.width-l-r,h=s.height-t-b;if(w<=0||h<=0)return;
    final axis=Paint()..color=Colors.black26..strokeWidth=1;c.drawLine(Offset(l,t),Offset(l,t+h),axis);c.drawLine(Offset(l+w,t),Offset(l+w,t+h),axis);c.drawLine(Offset(l,t+h),Offset(l+w,t+h),axis);
    final tp=TextPainter(textDirection:TextDirection.ltr);
    for(int g=0;g<=4;g++){final y=t+h*g/4;c.drawLine(Offset(l,y),Offset(l+w,y),Paint()..color=Colors.black12..strokeWidth=1);}
    if(data.isNotEmpty){for(int i=0;i<3;i++){final idx=((data.length-1)*i/2).round();final x=l+w*i/2;tp.text=TextSpan(text:DateFormat('dd.MM\nHH:mm').format(data[idx].measuredAt),style:const TextStyle(fontSize:8,color:Colors.black54));tp.layout(textAlign:TextAlign.center);tp.paint(c,Offset((x-tp.width/2).clamp(l,s.width-r-tp.width).toDouble(),t+h+6));}}
    final primary=keys.first;final pvals=data.map((m)=>getter(m,primary)).whereType<double>().toList();final pmin=pvals.isEmpty?0.0:pvals.reduce((a,b)=>a<b?a:b),pmax=pvals.isEmpty?1.0:pvals.reduce((a,b)=>a>b?a:b);final pspan=pmax==pmin?1.0:pmax-pmin;
    final secondary=keys.skip(1).expand((k)=>data.map((m)=>getter(m,k)).whereType<double>()).toList();final smin=secondary.isEmpty?pmin:secondary.reduce((a,b)=>a<b?a:b),smax=secondary.isEmpty?pmax:secondary.reduce((a,b)=>a>b?a:b);final sspan=smax==smin?1.0:smax-smin;
    _axisText(c,tp,l-5,t,'${pmax.toStringAsFixed(1)}',true,palette[0]);_axisText(c,tp,l-5,t+h-10,'${pmin.toStringAsFixed(1)}',true,palette[0]);
    if(keys.length>1){_axisText(c,tp,l+w+5,t,'${smax.toStringAsFixed(1)}',false,palette[1]);_axisText(c,tp,l+w+5,t+h-10,'${smin.toStringAsFixed(1)}',false,palette[1]);}
    for(int ki=0;ki<keys.length;ki++){final k=keys[ki];final path=Path();bool first=true;for(int i=0;i<data.length;i++){final v=getter(data[i],k);if(v==null)continue;final x=l+w*(data.length == 1 ? 0.5 : i / (data.length - 1));final y=t+h*(1-(v-(ki==0?pmin:smin))/(ki==0?pspan:sspan));if(first){path.moveTo(x,y);first=false;}else{path.lineTo(x,y);}}c.drawPath(path,Paint()..color=palette[ki%palette.length]..strokeWidth=2.5..style=PaintingStyle.stroke);}
    if(touched!=null&&touched!<data.length){final x=l+w*(data.length == 1 ? 0.5 : touched! / (data.length - 1));c.drawLine(Offset(x,t),Offset(x,t+h),Paint()..color=Colors.black45..strokeWidth=1);for(int ki=0;ki<keys.length;ki++){final v=getter(data[touched!],keys[ki]);if(v==null)continue;final y=t+h*(1-(v-(ki==0?pmin:smin))/(ki==0?pspan:sspan));c.drawCircle(Offset(x,y),4,Paint()..color=palette[ki%palette.length]);}}
  }
  void _axisText(Canvas c,TextPainter tp,double x,double y,String text,bool left,Color color){tp.text=TextSpan(text:text,style:TextStyle(fontSize:9,color:color,fontWeight:FontWeight.w700));tp.layout();tp.paint(c,Offset(left?x-tp.width:x,y));}
  @override bool shouldRepaint(covariant _TrendPainter old)=>true;
}
