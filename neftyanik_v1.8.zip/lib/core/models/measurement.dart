class Measurement {
  const Measurement({
    this.id,
    required this.padId,
    required this.wellId,
    required this.wellNumber,
    required this.measuredAt,
    this.rtr, this.rz, this.pkvWork, this.pkvIdle,
    this.frequency, this.current, this.load, this.rp, this.tPed, this.rInsul,
    this.pidCurrent, this.pidFrequencyRange,
    this.pkvInstalled = false, this.pidInstalled = false,
    this.gasState, this.rBuf, this.rBufSource, this.rInterDr, this.rCasing,
    this.rLine, this.rLineSource, this.tBeforeChoke, this.tLine,
    this.chokeMode, this.chokeValue, this.chokeValue2, this.nozzle,
    this.rDownhole, this.tDownhole, this.shutoffValveInstalled = false, this.rKo,
    this.inhibitorInstalled = false, this.inhibitorFeed, this.note, this.problemNote,
    this.source = 'Оператор',
  });

  final int? id;
  final String padId, wellId, wellNumber;
  final DateTime measuredAt;
  final double? rtr, rz;
  final int? pkvWork, pkvIdle;
  final double? frequency, current, load, rp, tPed, rInsul;
  final double? pidCurrent;
  final String? pidFrequencyRange;
  final bool pkvInstalled, pidInstalled;

  // Газоконденсатная скважина.
  final String? gasState;
  final double? rBuf;
  final String? rBufSource;
  final double? rInterDr, rCasing; // оставлены для совместимости со старыми замерами
  final double? rLine;
  final String? rLineSource;
  final double? tBeforeChoke, tLine;
  final String? chokeMode; // Штуцер / Дроссель
  final double? chokeValue, chokeValue2; // открытие первого и второго дросселя, %
  final String? nozzle;
  final double? rDownhole, tDownhole; // подземная телеметрия
  final bool shutoffValveInstalled;
  final double? rKo;
  final bool inhibitorInstalled;
  final double? inhibitorFeed;
  final String? note;
  final String? problemNote;
  final String source;

  int? get pkvCycle => pkvWork != null && pkvIdle != null ? pkvWork! + pkvIdle! : null;
}
