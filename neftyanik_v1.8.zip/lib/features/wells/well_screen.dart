import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../core/models/measurement.dart';
import '../../core/models/pad.dart';
import '../../core/models/well.dart';
import '../../core/repositories/measurement_repository.dart';

class WellScreen extends StatefulWidget {
  const WellScreen({super.key, required this.padId, required this.wellId, this.walkIndex});
  final String padId;
  final String wellId;
  final int? walkIndex;
  @override State<WellScreen> createState() => _WellScreenState();
}

class _WellScreenState extends State<WellScreen> {
  final formKey = GlobalKey<FormState>();
  final repository = MeasurementRepository();
  late Well well;
  late final TextEditingController rtr, rz, pkvWork, pkvIdle, pidCurrent, pidFrequencyRange, frequency, current, load, rp, tPed, rInsul;
  late final TextEditingController rBuf, rBufSource, rLine, rLineSource, tBeforeChoke, tLine, nozzle, rDownhole, tDownhole, rKo, inhibitorFeed, problemNote;
  bool loading = true, saving = false, pkvInstalled = false, pidInstalled = false, pkvConfirmed = false, pidConfirmed = false;
  String chokeMode = 'Штуцер';
  double chokeValue = 50, chokeValue2 = 20;
  bool shutoffValveInstalled = false, inhibitorInstalled = false;

  @override
  void initState() {
    super.initState();
    final pad = demoPads.firstWhere((p) => p.id == widget.padId);
    well = pad.wells.firstWhere((w) => w.id == widget.wellId);
    rtr = TextEditingController(); rz = TextEditingController(); pkvWork = TextEditingController(); pkvIdle = TextEditingController();
    pidCurrent = TextEditingController(); pidFrequencyRange = TextEditingController(); frequency = TextEditingController(); current = TextEditingController();
    load = TextEditingController(); rp = TextEditingController(); tPed = TextEditingController(); rInsul = TextEditingController();
    rBuf = TextEditingController(); rBufSource = TextEditingController(); rLine = TextEditingController(); rLineSource = TextEditingController();
    tBeforeChoke = TextEditingController(); tLine = TextEditingController(); nozzle = TextEditingController(); rDownhole = TextEditingController();
    tDownhole = TextEditingController(); rKo = TextEditingController(); inhibitorFeed = TextEditingController(); problemNote = TextEditingController();
    _loadLatest();
  }

  Future<void> _loadLatest() async {
    final m = await repository.latestForWell(widget.wellId);
    if (m != null) {
      _setControllers(m);
      pkvInstalled = m.pkvInstalled;
      pidInstalled = m.pidInstalled;
      pkvConfirmed = true;
      pidConfirmed = true;
      chokeMode = m.chokeMode ?? 'Штуцер';
      chokeValue = m.chokeValue ?? 50;
      chokeValue2 = m.chokeValue2 ?? 20;
      shutoffValveInstalled = m.shutoffValveInstalled;
      inhibitorInstalled = m.inhibitorInstalled;
    } else {
      _setFromWell();
      pkvInstalled = well.pkvInstalled ?? false;
      pidInstalled = well.pidInstalled ?? false;
    }
    if (mounted) setState(() => loading = false);
  }

  void _setFromWell() {
    rtr.text = _v(well.rtr); rz.text = _v(well.rz); pkvWork.text = well.pkvWork?.toString() ?? ''; pkvIdle.text = well.pkvIdle?.toString() ?? '';
    frequency.text = _v(well.frequency); current.text = _v(well.current); load.text = _v(well.load); rp.text = _v(well.rp); tPed.text = _v(well.tPed); rInsul.text = _v(well.rInsul);
  }

  void _setControllers(Measurement m) {
    rtr.text = _v(m.rtr); rz.text = _v(m.rz); pkvWork.text = m.pkvWork?.toString() ?? ''; pkvIdle.text = m.pkvIdle?.toString() ?? '';
    pidCurrent.text = _v(m.pidCurrent); pidFrequencyRange.text = m.pidFrequencyRange ?? ''; frequency.text = _v(m.frequency); current.text = _v(m.current); load.text = _v(m.load);
    rp.text = _v(m.rp); tPed.text = _v(m.tPed); rInsul.text = _v(m.rInsul); rBuf.text = _v(m.rBuf); rBufSource.text = m.rBufSource ?? '';
    rLine.text = _v(m.rLine); rLineSource.text = m.rLineSource ?? ''; tBeforeChoke.text = _v(m.tBeforeChoke); tLine.text = _v(m.tLine); nozzle.text = m.nozzle ?? '';
    rDownhole.text = _v(m.rDownhole); tDownhole.text = _v(m.tDownhole); rKo.text = _v(m.rKo); inhibitorFeed.text = _v(m.inhibitorFeed); problemNote.text = m.problemNote ?? '';
  }

  String _v(double? v) => v == null ? '' : v.toString();
  double? _d(TextEditingController c) => double.tryParse(c.text.trim().replaceAll(',', '.'));
  int? _i(TextEditingController c) => int.tryParse(c.text.trim());
  int? get pkvCycle { final a = _i(pkvWork), b = _i(pkvIdle); return a != null && b != null ? a + b : null; }

  @override
  void dispose() {
    for (final c in [rtr, rz, pkvWork, pkvIdle, pidCurrent, pidFrequencyRange, frequency, current, load, rp, tPed, rInsul, rBuf, rBufSource, rLine, rLineSource, tBeforeChoke, tLine, nozzle, rDownhole, tDownhole, rKo, inhibitorFeed, problemNote]) c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    return well.type == WellType.gasCondensate ? _gas() : _oil();
  }

  Scaffold _oil() => Scaffold(
    appBar: AppBar(title: Text('Скважина ${well.number}'), bottom: _walk()),
    body: Form(key: formKey, child: ListView(padding: const EdgeInsets.fromLTRB(16, 4, 16, 28), children: [
      Row(children: [Text(_status(well.status), style: const TextStyle(color: Colors.black54)), const Spacer(), const Text('Данные сохраняются локально', style: TextStyle(color: Colors.black54, fontSize: 12))]),
      const SizedBox(height: 14),
      _section('Давление', [_row(_number('Ртр', rtr, 'кгс/см²'), _number('Рз', rz, 'кгс/см²'))]),
      _section('ПКВ', [
        CheckboxListTile(contentPadding: EdgeInsets.zero, value: pkvInstalled, onChanged: (v) => setState(() { pkvInstalled = v ?? false; pkvConfirmed = true; }), title: const Text('Программа ПКВ установлена'), subtitle: Text(pkvConfirmed ? 'Подтверждено' : 'Подтвердите наличие или отсутствие')),
        if (pkvInstalled) _row(_number('Работа', pkvWork, 'мин', integer: true), _number('Простой', pkvIdle, 'мин', integer: true)),
        if (pkvInstalled) AnimatedBuilder(animation: Listenable.merge([pkvWork, pkvIdle]), builder: (_, __) => Text('Цикл: ${pkvCycle == null ? '—' : '$pkvCycle мин'}')),
      ]),
      _section('ПИД', [
        CheckboxListTile(contentPadding: EdgeInsets.zero, value: pidInstalled, onChanged: (v) => setState(() { pidInstalled = v ?? false; pidConfirmed = true; }), title: const Text('Программа ПИД установлена'), subtitle: Text(pidConfirmed ? 'Подтверждено' : 'Подтвердите наличие или отсутствие')),
        if (pidInstalled) _row(_number('Ток ПИД', pidCurrent, 'А'), _text('Диапазон F', pidFrequencyRange, 'Например 40–60 Гц')),
      ]),
      _section('Фактические параметры', [
        _row(_number('F', frequency, 'Гц', enabled: pidInstalled), _number('Iср', current, 'А', enabled: pidInstalled)),
        const SizedBox(height: 10), _row(_number('Загрузка', load, '%', enabled: pidInstalled), _number('Рпр', rp, 'атм')),
        const SizedBox(height: 10), _row(_number('Тпэд', tPed, '°C'), _number('Rизол', rInsul, 'кОм')),
      ]),
      _problem(), _save(),
    ])),
  );

  Scaffold _gas() => Scaffold(
    appBar: AppBar(title: Text('Скважина ${well.number}'), bottom: _walk()),
    body: Form(key: formKey, child: ListView(padding: const EdgeInsets.fromLTRB(16, 4, 16, 28), children: [
      const Text('Газоконденсатные параметры', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)), const SizedBox(height: 12),
      _section('Давления', [
        _row(_number('Рбуф', rBuf, 'МПа'), _number('Ртр', rtr, 'МПа')),
        const SizedBox(height: 10), _number('Рлин', rLine, 'МПа'),
        const SizedBox(height: 4), _row(_sourceField('Источник Рбуф', rBufSource), _sourceField('Источник Рлин', rLineSource)),
      ]),
      _section('Температуры', [_row(_number('Тдо штуцера', tBeforeChoke, '°C'), _number('Тлин', tLine, '°C'))]),
      _section('Дросселирование', [
        SegmentedButton<String>(segments: const [ButtonSegment(value: 'Штуцер', label: Text('Штуцер'), icon: Icon(Icons.tune)), ButtonSegment(value: 'Дроссель', label: Text('Дроссель'), icon: Icon(Icons.settings_input_component))], selected: {chokeMode}, onSelectionChanged: (v) => setState(() => chokeMode = v.first)),
        if (chokeMode == 'Дроссель') ...[_slider('Дроссель 1', chokeValue, (v) => setState(() => chokeValue = v)), _slider('Дроссель 2', chokeValue2, (v) => setState(() => chokeValue2 = v))]
        else _text('Штуцер', nozzle, 'Сечение штуцера'),
      ]),
      _section('Подземная телеметрия', [_row(_number('Рузд', rDownhole, 'МПа'), _number('Тузд', tDownhole, '°C'))]),
      _section('Клапан-отсекатель', [
        SwitchListTile(contentPadding: EdgeInsets.zero, value: shutoffValveInstalled, onChanged: (v) => setState(() => shutoffValveInstalled = v), title: const Text('Клапан-отсекатель установлен'), subtitle: Text(shutoffValveInstalled ? 'Да' : 'Нет'), secondary: const Icon(Icons.toggle_on_outlined)),
        if (shutoffValveInstalled) _number('Рко', rKo, 'МПа'),
      ]),
      _section('Ингибитор', [
        SwitchListTile(contentPadding: EdgeInsets.zero, value: inhibitorInstalled, onChanged: (v) => setState(() => inhibitorInstalled = v), title: const Text('Подача ингибитора'), subtitle: Text(inhibitorInstalled ? 'Да' : 'Нет'), secondary: const Icon(Icons.water_drop_outlined)),
        if (inhibitorInstalled) _number('Расход', inhibitorFeed, 'л/ч'),
      ]),
      _problem(), _save(),
    ])),
  );

  Widget _problem() => _section('Проблемы по скважине', [TextFormField(controller: problemNote, maxLines: 4, decoration: const InputDecoration(labelText: 'Описание проблемы', hintText: 'Опишите неисправность, отклонение или замечание'))]);
  Widget _slider(String label, double value, ValueChanged<double> onChanged) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('$label: ${value.round()} %', style: const TextStyle(fontWeight: FontWeight.w600)), Slider(value: value, min: 0, max: 100, divisions: 100, label: '${value.round()} %', onChanged: onChanged)]);
  Widget _save() => Padding(padding: const EdgeInsets.only(top: 4), child: FilledButton.icon(onPressed: saving ? null : _saveMeasurement, icon: saving ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.save_outlined), label: Text(saving ? 'Сохранение…' : 'Сохранить замер'), style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 15))));
  Widget _row(Widget a, Widget b) => Row(children: [Expanded(child: a), const SizedBox(width: 10), Expanded(child: b)]);
  Widget _section(String title, List<Widget> children) => Card(margin: const EdgeInsets.only(bottom: 12), child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)), const SizedBox(height: 10), ...children])));
  Widget _number(String label, TextEditingController c, String unit, {bool integer = false, bool enabled = true}) => TextFormField(controller: c, enabled: enabled, keyboardType: TextInputType.numberWithOptions(decimal: !integer), decoration: InputDecoration(labelText: label, suffixText: unit, hintText: 'Не измерено'), validator: (v) { if (!enabled || v == null || v.trim().isEmpty) return null; final n = double.tryParse(v.replaceAll(',', '.')); if (n == null || !n.isFinite || (integer && n % 1 != 0) || n < 0) return 'Проверьте значение'; return null; });
  Widget _text(String label, TextEditingController c, String hint) => TextFormField(controller: c, decoration: InputDecoration(labelText: label, hintText: hint));
  Widget _sourceField(String label, TextEditingController c) => DropdownButtonFormField<String>(value: c.text.isEmpty ? null : c.text, decoration: InputDecoration(labelText: label), items: const [DropdownMenuItem(value: 'Механический манометр', child: Text('Механический манометр')), DropdownMenuItem(value: 'БЭЛП', child: Text('БЭЛП')), DropdownMenuItem(value: 'УМТ', child: Text('УМТ'))], onChanged: (v) => c.text = v ?? '');
  PreferredSizeWidget? _walk() { final i = widget.walkIndex; if (i == null) return null; final pad = demoPads.firstWhere((p) => p.id == widget.padId); return PreferredSize(preferredSize: const Size.fromHeight(34), child: Padding(padding: const EdgeInsets.fromLTRB(16, 0, 16, 10), child: Align(alignment: Alignment.centerLeft, child: Text('${i + 1} из ${pad.wells.length}', style: const TextStyle(fontSize: 12))))); }
  String _status(WellStatus s) => switch (s) { WellStatus.working => 'Работает', WellStatus.stopped => 'Остановлена', WellStatus.krs => 'КРС', WellStatus.pdf => 'ПДФ', WellStatus.disabled => 'Отключен', WellStatus.underload => 'Недогруз' };

  Future<void> _saveMeasurement() async {
    if (!(formKey.currentState?.validate() ?? false)) return;
    if (well.type == WellType.oil && (!pkvConfirmed || !pidConfirmed)) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Сначала подтвердите наличие или отсутствие программ ПКВ и ПИД.'))); return; }
    setState(() => saving = true);
    try {
      await repository.save(Measurement(padId: widget.padId, wellId: widget.wellId, wellNumber: well.number, measuredAt: DateTime.now(), rtr: _d(rtr), rz: _d(rz), pkvWork: pkvInstalled ? _i(pkvWork) : null, pkvIdle: pkvInstalled ? _i(pkvIdle) : null, frequency: pidInstalled ? _d(frequency) : null, current: pidInstalled ? _d(current) : null, load: pidInstalled ? _d(load) : null, rp: _d(rp), tPed: _d(tPed), rInsul: _d(rInsul), pidCurrent: pidInstalled ? _d(pidCurrent) : null, pidFrequencyRange: pidInstalled ? pidFrequencyRange.text.trim() : null, pkvInstalled: pkvInstalled, pidInstalled: pidInstalled, rBuf: _d(rBuf), rBufSource: rBufSource.text.trim().isEmpty ? null : rBufSource.text.trim(), rLine: _d(rLine), rLineSource: rLineSource.text.trim().isEmpty ? null : rLineSource.text.trim(), tBeforeChoke: _d(tBeforeChoke), tLine: _d(tLine), chokeMode: chokeMode, chokeValue: chokeMode == 'Дроссель' ? chokeValue : null, chokeValue2: chokeMode == 'Дроссель' ? chokeValue2 : null, nozzle: chokeMode == 'Штуцер' && nozzle.text.trim().isNotEmpty ? nozzle.text.trim() : null, rDownhole: _d(rDownhole), tDownhole: _d(tDownhole), shutoffValveInstalled: shutoffValveInstalled, rKo: shutoffValveInstalled ? _d(rKo) : null, inhibitorInstalled: inhibitorInstalled, inhibitorFeed: inhibitorInstalled ? _d(inhibitorFeed) : null, problemNote: problemNote.text.trim().isEmpty ? null : problemNote.text.trim(), note: problemNote.text.trim().isEmpty ? null : problemNote.text.trim()));
      if (!mounted) return;
      if (widget.walkIndex != null) {
        final pad = demoPads.firstWhere((p) => p.id == widget.padId);
        final next = widget.walkIndex! + 1;
        if (next < pad.wells.length) { await repository.saveWalk(widget.padId, next); if (mounted) context.go('/pad/${widget.padId}/walk/$next'); }
        else { await repository.finishWalk(widget.padId); if (mounted) context.go('/pad/${widget.padId}/walk-summary'); }
      } else { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Замер сохранён в памяти телефона'))); context.pop(); }
    } finally { if (mounted) setState(() => saving = false); }
  }
}
