import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../core/models/measurement.dart';
import '../../core/models/pad.dart';
import '../../core/models/well.dart';
import '../../core/repositories/measurement_repository.dart';
import '../../core/services/session_service.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});
  @override State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  final repo = MeasurementRepository();
  String? padId, wellId, selectedDate;
  List<Measurement> items = [];
  bool loading = false;
  Pad? get pad => padId == null ? null : demoPads.where((p) => p.id == padId).firstOrNull;
  Well? get well => pad?.wells.where((w) => w.id == wellId).firstOrNull;

  @override void initState() { super.initState(); padId = demoPads.first.id; _setWell(); _load(); }
  void _setWell() { final ws = pad?.wells ?? const <Well>[]; wellId = ws.isEmpty ? null : ws.first.id; selectedDate = null; }
  Future<void> _load() async { setState(() => loading = true); items = wellId == null ? [] : await repo.history(wellId: wellId, limit: 500); if (mounted) setState(() => loading = false); }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('История')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      const Text('Выбор скважины', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)), const SizedBox(height: 10),
      DropdownButtonFormField<String>(value: padId, decoration: const InputDecoration(labelText: 'Кустовая площадка'), items: demoPads.map((p) => DropdownMenuItem(value: p.id, child: Text(p.name))).toList(), onChanged: (v) { setState(() { padId = v; _setWell(); }); _load(); }),
      const SizedBox(height: 10),
      DropdownButtonFormField<String>(value: wellId, decoration: const InputDecoration(labelText: 'Скважина'), items: (pad?.wells ?? const <Well>[]).map((w) => DropdownMenuItem(value: w.id, child: Text('Скважина ${w.number} · ${w.type == WellType.oil ? 'нефтяная' : 'газовая'}'))).toList(), onChanged: (v) { setState(() { wellId = v; selectedDate = null; }); _load(); }),
      const SizedBox(height: 18),
      if (well != null) Text('Замеры скважины ${well!.number}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
      const SizedBox(height: 8),
      if (loading) const Center(child: Padding(padding: EdgeInsets.all(24), child: CircularProgressIndicator()))
      else if (items.isEmpty) const Card(child: Padding(padding: EdgeInsets.all(18), child: Text('Для выбранной скважины замеров пока нет.')))
      else ...items.map(_dateCard),
    ]),
  );

  Widget _dateCard(Measurement m) {
    final key = m.id?.toString() ?? m.measuredAt.toIso8601String();
    final open = selectedDate == key;
    return Card(margin: const EdgeInsets.only(bottom: 10), child: Column(children: [
      ListTile(leading: const CircleAvatar(child: Icon(Icons.calendar_today_outlined)), title: Text(DateFormat('dd.MM.yyyy').format(m.measuredAt), style: const TextStyle(fontWeight: FontWeight.w800)), subtitle: Text(DateFormat('HH:mm').format(m.measuredAt)), trailing: Icon(open ? Icons.expand_less : Icons.expand_more), onTap: () => setState(() => selectedDate = open ? null : key)),
      if (open) _details(m),
    ]));
  }

  Widget _details(Measurement m) {
    final rows = _all(m);
    return Padding(padding: const EdgeInsets.fromLTRB(16, 0, 16, 16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Divider(),
      ...rows.map((e) => Padding(padding: const EdgeInsets.symmetric(vertical: 4), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Expanded(child: Text(e.$1, style: const TextStyle(color: Colors.black54))), Expanded(flex: 2, child: Text(e.$2, style: const TextStyle(fontWeight: FontWeight.w600)))]))),
      if (SessionService.instance.currentUser.canCorrect) ...[
        const SizedBox(height: 10),
        SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: () async { final changed = await Navigator.push<bool>(context, MaterialPageRoute(builder: (_) => CorrectionScreen(measurement: m))); if (changed == true) _load(); }, icon: const Icon(Icons.edit_outlined), label: const Text('Корректировать параметры'))),
      ],
    ]));
  }

  String _f(double? v, String u) => v == null ? 'Не измерено' : '${v.toStringAsFixed(v.truncateToDouble() == v ? 0 : 2).replaceAll('.', ',')} $u';

  List<(String, String)> _all(Measurement m) {
    final common = [('Дата и время', DateFormat('dd.MM.yyyy HH:mm').format(m.measuredAt)), ('Источник', m.source)];
    if (well?.type == WellType.gasCondensate) {
      return [...common,
        ('Рбуф', _f(m.rBuf, 'МПа')), ('Источник Рбуф', m.rBufSource ?? 'Не измерено'), ('Ртр', _f(m.rtr, 'МПа')), ('Рлин', _f(m.rLine, 'МПа')), ('Источник Рлин', m.rLineSource ?? 'Не измерено'),
        ('Тдо штуцера', _f(m.tBeforeChoke, '°C')), ('Тлин', _f(m.tLine, '°C')), ('Дросселирование', m.chokeMode ?? 'Не измерено'),
        if (m.chokeMode == 'Дроссель') ('Дроссель 1', _f(m.chokeValue, '%')), if (m.chokeMode == 'Дроссель') ('Дроссель 2', _f(m.chokeValue2, '%')), if (m.chokeMode == 'Штуцер') ('Штуцер', m.nozzle ?? 'Не измерено'),
        ('Подземная телеметрия: Рузд', _f(m.rDownhole, 'МПа')), ('Подземная телеметрия: Тузд', _f(m.tDownhole, '°C')), ('Клапан-отсекатель', m.shutoffValveInstalled ? 'Да' : 'Нет'),
        if (m.shutoffValveInstalled) ('Рко', _f(m.rKo, 'МПа')), ('Ингибитор', m.inhibitorInstalled ? 'Да' : 'Нет'), if (m.inhibitorInstalled) ('Расход ингибитора', _f(m.inhibitorFeed, 'л/ч')), ('Проблема', m.problemNote ?? 'Нет')];
    }
    return [...common,
      ('Ртр', _f(m.rtr, 'кгс/см²')), ('Рз', _f(m.rz, 'кгс/см²')), ('ПКВ установлена', m.pkvInstalled ? 'Да' : 'Нет'),
      if (m.pkvInstalled) ('ПКВ: работа', _f(m.pkvWork?.toDouble(), 'мин')), if (m.pkvInstalled) ('ПКВ: простой', _f(m.pkvIdle?.toDouble(), 'мин')), if (m.pkvInstalled) ('ПКВ: цикл', m.pkvCycle?.toString() ?? 'Не измерено'),
      ('ПИД установлена', m.pidInstalled ? 'Да' : 'Нет'), if (m.pidInstalled) ('Ток ПИД', _f(m.pidCurrent, 'А')), if (m.pidInstalled) ('Диапазон F', m.pidFrequencyRange ?? 'Не измерено'),
      if (m.pidInstalled) ('F', _f(m.frequency, 'Гц')), if (m.pidInstalled) ('Iср', _f(m.current, 'А')), if (m.pidInstalled) ('Загрузка', _f(m.load, '%')),
      ('Рпр', _f(m.rp, 'атм')), ('Тпэд', _f(m.tPed, '°C')), ('Rизол', _f(m.rInsul, 'кОм')), ('Проблема', m.problemNote ?? 'Нет')];
  }
}

class CorrectionScreen extends StatefulWidget {
  const CorrectionScreen({super.key, required this.measurement});
  final Measurement measurement;
  @override State<CorrectionScreen> createState() => _CorrectionScreenState();
}

class _CorrectionScreenState extends State<CorrectionScreen> {
  final repo = MeasurementRepository();
  final value = TextEditingController(); final reason = TextEditingController(); final comment = TextEditingController();
  late String parameter; late List<MapEntry<String, String>> fields; bool saving = false;

  @override void initState() { super.initState(); fields = _fields(); parameter = fields.first.key; value.text = _old() ?? ''; }
  List<MapEntry<String, String>> _fields() {
    final m = widget.measurement;
    if (m.rBuf != null || m.rLine != null || m.tBeforeChoke != null || m.rDownhole != null) return <String, String>{'r_buf':'Рбуф','r_buf_source':'Источник Рбуф','rtr':'Ртр','r_line':'Рлин','r_line_source':'Источник Рлин','t_before_choke':'Тдо штуцера','t_line':'Тлин','choke_mode':'Дросселирование','choke_value':'Дроссель 1','choke_value2':'Дроссель 2','nozzle':'Штуцер','r_downhole':'Рузд','t_downhole':'Тузд','shutoff_valve_installed':'Клапан-отсекатель','r_ko':'Рко','inhibitor_installed':'Ингибитор','inhibitor_feed':'Расход ингибитора','problem_note':'Проблема'}.entries.toList();
    return <String, String>{'rtr':'Ртр','rz':'Рз','pkv_installed':'ПКВ установлена','pkv_work':'ПКВ: работа','pkv_idle':'ПКВ: простой','pid_installed':'ПИД установлена','pid_current':'Ток ПИД','pid_frequency_range':'Диапазон F','frequency':'F','current':'Iср','load':'Загрузка','rp':'Рпр','t_ped':'Тпэд','r_insul':'Rизол','problem_note':'Проблема'}.entries.toList();
  }
  String? _old() { final m = widget.measurement; switch (parameter) { case 'rtr': return m.rtr?.toString(); case 'rz': return m.rz?.toString(); case 'pkv_installed': return m.pkvInstalled ? 'Да' : 'Нет'; case 'pkv_work': return m.pkvWork?.toString(); case 'pkv_idle': return m.pkvIdle?.toString(); case 'pid_installed': return m.pidInstalled ? 'Да' : 'Нет'; case 'pid_current': return m.pidCurrent?.toString(); case 'pid_frequency_range': return m.pidFrequencyRange; case 'frequency': return m.frequency?.toString(); case 'current': return m.current?.toString(); case 'load': return m.load?.toString(); case 'rp': return m.rp?.toString(); case 't_ped': return m.tPed?.toString(); case 'r_insul': return m.rInsul?.toString(); case 'r_buf': return m.rBuf?.toString(); case 'r_buf_source': return m.rBufSource; case 'r_line': return m.rLine?.toString(); case 'r_line_source': return m.rLineSource; case 't_before_choke': return m.tBeforeChoke?.toString(); case 't_line': return m.tLine?.toString(); case 'choke_mode': return m.chokeMode; case 'choke_value': return m.chokeValue?.toString(); case 'choke_value2': return m.chokeValue2?.toString(); case 'nozzle': return m.nozzle; case 'r_downhole': return m.rDownhole?.toString(); case 't_downhole': return m.tDownhole?.toString(); case 'shutoff_valve_installed': return m.shutoffValveInstalled ? 'Да' : 'Нет'; case 'r_ko': return m.rKo?.toString(); case 'inhibitor_installed': return m.inhibitorInstalled ? 'Да' : 'Нет'; case 'inhibitor_feed': return m.inhibitorFeed?.toString(); case 'problem_note': return m.problemNote; default: return null; } }
  @override Widget build(BuildContext context) { final toggle = {'pkv_installed','pid_installed','shutoff_valve_installed','inhibitor_installed'}.contains(parameter); return Scaffold(appBar: AppBar(title: const Text('Корректировка замера')), body: ListView(padding: const EdgeInsets.all(16), children: [Card(child: ListTile(title: Text('Скважина ${widget.measurement.wellNumber}'), subtitle: Text(DateFormat('dd.MM.yyyy HH:mm').format(widget.measurement.measuredAt)))), const SizedBox(height: 12), DropdownButtonFormField<String>(value: parameter, decoration: const InputDecoration(labelText: 'Параметр для корректировки'), items: fields.map((e) => DropdownMenuItem(value: e.key, child: Text(e.value))).toList(), onChanged: (v) { if (v != null) setState(() { parameter = v; value.text = _old() ?? ''; }); }), const SizedBox(height: 8), Text('Текущее значение: ${_old() ?? '—'}', style: const TextStyle(fontWeight: FontWeight.w700)), const SizedBox(height: 8), if (toggle) DropdownButtonFormField<String>(value: (value.text == 'Да' || value.text == 'Нет') ? value.text : null, decoration: const InputDecoration(labelText: 'Новое значение'), items: const [DropdownMenuItem(value: 'Да', child: Text('Да')), DropdownMenuItem(value: 'Нет', child: Text('Нет'))], onChanged: (v) => setState(() => value.text = v ?? '')) else TextField(controller: value, maxLines: parameter == 'problem_note' || parameter == 'nozzle' || parameter == 'pid_frequency_range' ? 3 : 1, decoration: InputDecoration(labelText: 'Новое значение')), const SizedBox(height: 10), TextField(controller: reason, decoration: const InputDecoration(labelText: 'Причина исправления *')), const SizedBox(height: 10), TextField(controller: comment, maxLines: 2, decoration: const InputDecoration(labelText: 'Комментарий')), const SizedBox(height: 18), FilledButton.icon(onPressed: saving ? null : _save, icon: const Icon(Icons.check), label: const Text('Сохранить корректировку'))])); }
  Future<void> _save() async { if (reason.text.trim().isEmpty) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Укажите причину исправления'))); return; } setState(() => saving = true); try { await repo.correct(measurementId: widget.measurement.id!, parameter: parameter, newValue: value.text, userId: SessionService.instance.currentUser.id, userName: SessionService.instance.currentUser.name, reason: reason.text.trim(), comment: comment.text.trim().isEmpty ? null : comment.text.trim()); if (mounted) Navigator.pop(context, true); } catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Ошибка: $e'))); } finally { if (mounted) setState(() => saving = false); } }
  @override void dispose() { value.dispose(); reason.dispose(); comment.dispose(); super.dispose(); }
}
