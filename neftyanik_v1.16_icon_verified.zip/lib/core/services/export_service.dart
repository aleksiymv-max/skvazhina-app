import 'dart:io';
import 'package:excel/excel.dart';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import '../models/measurement.dart';
import '../models/production_area.dart';
import '../models/pad.dart';
import '../models/well.dart';

class ExportService {
 static Future<File> createChessXlsx({required List<Measurement> measurements})async{
  final book=Excel.createExcel();book.delete('Sheet1');
  for(final area in demoAreas){final ms=measurements.where((m)=>area.padIds.contains(m.padId)).toList()..sort((a,b)=>a.measuredAt.compareTo(b.measuredAt));final sheet=book[_safeSheet(area.name)];
   final dates=<DateTime>[];for(final m in ms){if(!dates.any((d)=>_sameMinute(d,m.measuredAt)))dates.add(m.measuredAt);}
   sheet.appendRow([const TextCellValue('Кустовая площадка'),const TextCellValue('Скважина'),const TextCellValue('Параметр'),...dates.map((d)=>TextCellValue(DateFormat('dd.MM.yy\nHH:mm').format(d)))]);
   for(final pad in area.pads){final padMs=ms.where((m)=>m.padId==pad.id).toList();for(final well in pad.wells){final wm=padMs.where((m)=>m.wellId==well.id).toList();for(final spec in _specs(well.type)){sheet.appendRow([TextCellValue(pad.name),TextCellValue(well.number),TextCellValue(spec.$2),...dates.map((d){final m=wm.where((x)=>_sameMinute(x.measuredAt,d)).firstOrNull;return _cell(m==null?null:spec.$3(m));})]);}}
   }
  }
  final dir=await getTemporaryDirectory();final f=File('${dir.path}/Нефтяник_шахматка_${DateFormat('yyyyMMdd_HHmm').format(DateTime.now())}.xlsx');final bytes=book.encode();if(bytes==null)throw StateError('Не удалось сформировать Excel');await f.writeAsBytes(bytes,flush:true);return f;
 }
 static List<(String,String,dynamic Function(Measurement))> _specs(WellType t)=>t==WellType.gasCondensate?[
  ('rbuf','Рбуф, МПа',(m)=>m.rBuf),('rtr','Ртр, МПа',(m)=>m.rtr),('rline','Рлин, МПа',(m)=>m.rLine),('tb','Тдо штуцера, °C',(m)=>m.tBeforeChoke),('tl','Тлин, °C',(m)=>m.tLine),('rd','Рузд, МПа',(m)=>m.rDownhole),('td','Тузд, °C',(m)=>m.tDownhole),('rko','Рко, МПа',(m)=>m.rKo),('inh','Ингибитор, л/ч',(m)=>m.inhibitorFeed)
 ]:[('rtr','Ртр, кгс/см²',(m)=>m.rtr),('rz','Рз, кгс/см²',(m)=>m.rz),('f','F, Гц',(m)=>m.frequency),('i','Iср, А',(m)=>m.current),('load','Загрузка, %',(m)=>m.load),('rp','Рпр, атм',(m)=>m.rp),('tped','Тпэд, °C',(m)=>m.tPed),('riz','Rизол, кОм',(m)=>m.rInsul)];
 static bool _sameMinute(DateTime a,DateTime b)=>a.year==b.year&&a.month==b.month&&a.day==b.day&&a.hour==b.hour&&a.minute==b.minute;
 static String _safeSheet(String s){final x=s.replaceAll(RegExp(r'[\\/*?:\[\]]'),' ').trim();return x.length>31?x.substring(0,31):x;}
 static CellValue _cell(dynamic v){if(v==null)return const TextCellValue('');if(v is int)return IntCellValue(v);if(v is double)return DoubleCellValue(v);if(v is num)return DoubleCellValue(v.toDouble());return TextCellValue(v.toString());}
 static Future<void> shareXlsx(File file)async=>Share.shareXFiles([XFile(file.path)],text:'Шахматка параметров — Нефтяник');
}
