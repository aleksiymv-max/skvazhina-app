import 'package:flutter/material.dart';

ThemeData buildAppTheme() {
  const blue = Color(0xFF0877F9);
  const navy = Color(0xFF0755A5);
  const background = Color(0xFFF3F8FF);
  final scheme = ColorScheme.fromSeed(seedColor: blue, brightness: Brightness.light).copyWith(primary: blue, secondary: navy, surface: Colors.white);
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: background,
    appBarTheme: const AppBarTheme(backgroundColor: navy, foregroundColor: Colors.white, surfaceTintColor: Colors.transparent, elevation: 0, centerTitle: false),
    cardTheme: CardThemeData(color: Colors.white, elevation: 0.8, surfaceTintColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18), side: const BorderSide(color: Color(0xFFD9E9FB)))),
    navigationBarTheme: NavigationBarThemeData(backgroundColor: Colors.white, indicatorColor: const Color(0xFFDDEEFF), labelTextStyle: WidgetStateProperty.resolveWith((s) => TextStyle(fontWeight: s.contains(WidgetState.selected) ? FontWeight.w800 : FontWeight.w500, fontSize: 11))),
    filledButtonTheme: FilledButtonThemeData(style: FilledButton.styleFrom(backgroundColor: blue, foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)))),
    inputDecorationTheme: InputDecorationTheme(filled: true, fillColor: Colors.white, border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: Color(0xFFD5E5F7))), enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: Color(0xFFD5E5F7))), focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: blue, width: 2)), contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14)),
  );
}
