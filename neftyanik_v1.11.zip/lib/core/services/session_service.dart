import '../models/user.dart';
import '../network/api_client.dart';

class PendingUser {
  PendingUser({required this.id, required this.name, required this.role, this.subrole, required this.chiefId});
  final String id;
  final String name;
  final UserRole role;
  final ItrSubrole? subrole;
  final String chiefId;
  bool approved = false;
}

class SessionService {
  SessionService._();
  static final instance = SessionService._();

  AppUser currentUser = const AppUser(id: 'op-001', name: 'Оператор ДНГ', role: UserRole.operator, chiefId: 'chief-001');
  final ApiClient api = ApiClient.instance;
  String? get token => api.token;

  final List<AppUser> _workers = [
    const AppUser(id: 'chief-001', name: 'Иванов Алексей Николаевич', role: UserRole.shopChief),
    const AppUser(id: 'eng-001', name: 'Петров Сергей Андреевич', role: UserRole.engineer, itrSubrole: ItrSubrole.leadingGeologist, chiefId: 'chief-001'),
    const AppUser(id: 'op-001', name: 'Смирнов Дмитрий Олегович', role: UserRole.operator, chiefId: 'chief-001'),
    const AppUser(id: 'op-002', name: 'Кузнецов Максим Игоревич', role: UserRole.operator, chiefId: 'chief-001'),
  ];
  final List<PendingUser> pendingUsers = [];

  List<AppUser> workersForChief(String chiefId) => _workers.where((u) => u.chiefId == chiefId && u.approved).toList();
  List<PendingUser> pendingForChief(String chiefId) => pendingUsers.where((u) => u.chiefId == chiefId && !u.approved).toList();

  Future<void> logout() async {
    api.token = null;
    currentUser = const AppUser(id: '', name: '', role: UserRole.operator, approved: false);
  }

  Future<void> login(String username, String password) async {
    const demo = <String, Map<String, String>>{
      'chief-001': {'password': 'chief', 'name': 'Иванов Алексей Николаевич', 'role': 'shopChief'},
      'op-001': {'password': 'operator', 'name': 'Смирнов Дмитрий Олегович', 'role': 'operator'},
      'eng-001': {'password': 'engineer', 'name': 'Петров Сергей Андреевич', 'role': 'engineer'},
      'op-002': {'password': 'operator', 'name': 'Кузнецов Максим Игоревич', 'role': 'operator'},
      'adm-001': {'password': 'admin', 'name': 'Администратор', 'role': 'admin'},
    };
    final record = demo[username];
    if (record == null || record['password'] != password) throw const ApiException('Неверный логин или пароль');
    final role = UserRole.values.firstWhere((r) => r.name == record['role']);
    final saved = _workers.where((u) => u.id == username).firstOrNull;
    if (saved != null && !saved.approved) throw const ApiException('Доступ ожидает подтверждения начальника цеха');
    currentUser = AppUser(id: username, name: record['name']!, role: role, chiefId: saved?.chiefId, itrSubrole: saved?.itrSubrole, approved: true);
    api.token = 'offline-$username';
  }

  Future<String> register({required String name, required UserRole role, ItrSubrole? subrole, required String chiefId}) async {
    if (role == UserRole.shopChief) throw const ApiException('Начальник цеха создаёт месторождение первым и не выбирает начальника');
    final id = '${role.name}-${DateTime.now().millisecondsSinceEpoch}';
    pendingUsers.add(PendingUser(id: id, name: name, role: role, subrole: subrole, chiefId: chiefId));
    return id;
  }

  void approve(String id) {
    final p = pendingUsers.where((u) => u.id == id).firstOrNull;
    if (p == null) return;
    p.approved = true;
    _workers.add(AppUser(id: p.id, name: p.name, role: p.role, itrSubrole: p.subrole, chiefId: p.chiefId, approved: true));
  }
}
