import 'pad.dart';

class ProductionArea {
  const ProductionArea({required this.id, required this.name, required this.padIds});
  final String id;
  final String name;
  final List<String> padIds;

  List<Pad> get pads => demoPads.where((p) => padIds.contains(p.id)).toList();
}

final demoAreas = <ProductionArea>[
  const ProductionArea(id: 'area-1', name: 'Участок добычи №1', padIds: ['1017']),
  const ProductionArea(id: 'area-2', name: 'Участок добычи №2', padIds: ['3A02']),
];

ProductionArea? areaForPad(String padId) {
  for (final area in demoAreas) {
    if (area.padIds.contains(padId)) return area;
  }
  return null;
}
