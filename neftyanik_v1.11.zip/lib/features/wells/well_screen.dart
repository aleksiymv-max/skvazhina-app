import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../core/models/measurement.dart';
import '../../core/models/pad.dart';
import '../../core/models/well.dart';
import '../../core/repositories/measurement_repository.dart';
import '../../core/services/session_service.dart';

class WellScreen extends StatefulWidget {
  const WellScreen({super.key, required this.padId, required this.wellId, this.walkIndex});
  final String padId;
  final String wellId;
  final int? walkIndex;
  @override State<WellScreen> createState() => _WellScreenState();
}

class _WellScreenState extends State<WellScreen> {
  final formKey = GlobalKey<FormState>();
  final repository = MeasurementRepository();
  late Well well;
  late final TextEditingController rtr, rz, pkvWork, pkvIdle, pidCurrent, pidFrequencyRange, frequency, current, load, rp, tPed, rInsul;
  late final TextEditingController rBuf, rLine, tBeforeChoke, tLine, choke1, choke2, nozzle, rDownhole, tDownhole, rKo, inhibitorFeed, problemNote;
  bool loading = true, saving = false, pkvInstalled = false, pidInstalled = false, pkvConfirmed = false, pidConfirmed = false;
  bool shutoffValveInstalled = false, inhibitorInstalled = false;
  String chokeMode = 'Штуцер';
  WellStatus wellStatus = WellStatus.working;

  @override
  void initState() {
    super.initState();
    final pad = demoPads.firstWhere((p) => p.id == widget.padId);
    well = pad.wells.firstWhere((w) => w.id == widget.wellId);
    rtr=TextEditingController(); rz=TextEditingController(); pkvWork=TextEditingController(); pkvIdle=TextEditingController();
    pidCurrent=TextEditingController(); pidFrequencyRange=TextEditingController(); frequency=TextEditingController(); current=TextEditingController();
    load=TextEditingController(); rp=TextEditingController(); tPed=TextEditingController(); rInsul=TextEditingController();
    rBuf=TextEditingController(); rLine=TextEditingController(); tBeforeChoke=TextEditingController(); tLine=TextEditingController();
    choke1=TextEditingController(); choke2=TextEditingController(); nozzle=TextEditingController(); rDownhole=TextEditingController(); tDownhole=TextEditingController();
    rKo=TextEditingController(); inhibitorFeed=TextEditingController(); problemNote=TextEditingController();
    _loadLatest();
  }

  Future<void> _loadLatest() async {
    final savedStatus = await repository.wellStatus(widget.wellId);
    final m = await repository.latestForWell(widget.wellId);
    if (m != null) {
      _setControllers(m);
      pkvInstalled=m.pkvInstalled; pidInstalled=m.pidInstalled; pkvConfirmed=true; pidConfirmed=true;
      chokeMode=m.chokeMode ?? 'Штуцер';
      shutoffValveInstalled=m.shutoffValveInstalled; inhibitorInstalled=m.inhibitorInstalled;
    } else { _setFromWell(); pkvInstalled=well.pkvInstalled??false; pidInstalled=well.pidInstalled??false; }
    wellStatus=savedStatus ?? well.status;
    if (mounted) setState(()=>loading=false);
  }

  void _setFromWell(){
    rtr.text=_v(well.rtr); rz.text=_v(well.rz); pkvWork.text=well.pkvWork?.toString()??''; pkvIdle.text=well.pkvIdle?.toString()??'';
    frequency.text=_v(well.frequency); current.text=_v(well.current); load.text=_v(well.load); rp.text=_v(well.rp); tPed.text=_v(well.tPed); rInsul.text=_v(well.rInsul);
  }
  void _setControllers(Measurement m){
    rtr.text=_v(m.rtr); rz.text=_v(m.rz); pkvWork.text=m.pkvWork?.toString()??''; pkvIdle.text=m.pkvIdle?.toString()??'';
    pidCurrent.text=_v(m.pidCurrent); pidFrequencyRange.text=m.pidFrequencyRange??''; frequency.text=_v(m.frequency); current.text=_v(m.current); load.text=_v(m.load);
    rp.text=_v(m.rp); tPed.text=_v(m.tPed); rInsul.text=_v(m.rInsul); rBuf.text=_v(m.rBuf); rLine.text=_v(m.rLine); tBeforeChoke.text=_v(m.tBeforeChoke); tLine.text=_v(m.tLine);
    choke1.text=_v(m.chokeValue); choke2.text=_v(m.chokeValue2); nozzle.text=m.nozzle??''; rDownhole.text=_v(m.rDownhole); tDownhole.text=_v(m.tDownhole); rKo.text=_v(m.rKo); inhibitorFeed.text=_v(m.inhibitorFeed); problemNote.text=m.problemNote??'';
  }
  String _v(double? v)=>v==null?'':v.toString();
  double? _d(TextEditingController c)=>double.tryParse(c.text.trim().replaceAll(',','.'));
  int? _i(TextEditingController c)=>int.tryParse(c.text.trim());
  int? get pkvCycle { final a=_i(pkvWork), b=_i(pkvIdle); return a!=null&&b!=null?a+b:null; }
  @override void dispose(){for(final c in [rtr,rz,pkvWork,pkvIdle,pidCurrent,pidFrequencyRange,frequency,current,load,rp,tPed,rInsul,rBuf,rLine,tBeforeChoke,tLine,choke1,choke2,nozzle,rDownhole,tDownhole,rKo,inhibitorFeed,problemNote])c.dispose();super.dispose();}

  @override Widget build(BuildContext context){if(loading)return const Scaffold(body:Center(child:CircularProgressIndicator()));return well.type==WellType.gasCondensate?_gas():_oil();}

  Widget _statusSelector()=>Card(child:Padding(padding:const EdgeInsets.all(12),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
    const Text('Состояние скважины',style:TextStyle(fontWeight:FontWeight.w800,fontSize:16)),const SizedBox(height:8),
    DropdownButtonFormField<WellStatus>(value:wellStatus,decoration:const InputDecoration(labelText:'Состояние'),items:const[
      DropdownMenuItem(value:WellStatus.working,child:Text('В работе')),
      DropdownMenuItem(value:WellStatus.workover,child:Text('ВНР')),
      DropdownMenuItem(value:WellStatus.stopped,child:Text('Остановлена')),
    ],onChanged:(v){if(v!=null)setState(()=>wellStatus=v);}),
  ])));

  Scaffold _oil()=>Scaffold(appBar:AppBar(title:Text('Скважина ${well.number}'),bottom:_walk()),body:Form(key:formKey,child:ListView(padding:const EdgeInsets.fromLTRB(16,4,16,28),children:[
    _statusSelector(),
    _section('Давление',[_row(_number('Ртр',rtr,'кгс/см²'),_number('Рз',rz,'кгс/см²'))]),
    _section('ПКВ',[CheckboxListTile(contentPadding:EdgeInsets.zero,value:pkvInstalled,onChanged:(v)=>setState(() { pkvInstalled=v??false; pkvConfirmed=true; }),title:const Text('Программа ПКВ установлена'),subtitle:Text(pkvConfirmed?'Подтверждено':'Подтвердите наличие или отсутствие')),if(pkvInstalled)_row(_number('Работа',pkvWork,'мин',integer:true),_number('Простой',pkvIdle,'мин',integer:true)),if(pkvInstalled)AnimatedBuilder(animation:Listenable.merge([pkvWork,pkvIdle]),builder:(_,__)=>Text('Цикл: ${pkvCycle??'—'} мин'))]),
    _section('ПИД',[CheckboxListTile(contentPadding:EdgeInsets.zero,value:pidInstalled,onChanged:(v)=>setState(() { pidInstalled=v??false; pidConfirmed=true; }),title:const Text('Программа ПИД установлена'),subtitle:Text(pidConfirmed?'Подтверждено':'Подтвердите наличие или отсутствие')),if(pidInstalled)_row(_number('Ток ПИД',pidCurrent,'А'),_text('Диапазон F',pidFrequencyRange,'Например 40–60 Гц'))]),
    _section('Фактические параметры',[_row(_number('F',frequency,'Гц',enabled:pidInstalled),_number('Iср',current,'А',enabled:pidInstalled)),const SizedBox(height:10),_row(_number('Загрузка',load,'%',enabled:pidInstalled),_number('Рпр',rp,'атм')),const SizedBox(height:10),_row(_number('Тпэд',tPed,'°C'),_number('Rизол',rInsul,'кОм'))]),
    _problem(),_save(),
  ])));

  Scaffold _gas()=>Scaffold(appBar:AppBar(title:Text('Скважина ${well.number}'),bottom:_walk()),body:Form(key:formKey,child:ListView(padding:const EdgeInsets.fromLTRB(16,4,16,28),children:[
    _statusSelector(),
    _section('Давления',[_row(_number('Рбуф',rBuf,'МПа'),_number('Ртр',rtr,'МПа')),const SizedBox(height:10),_number('Рлин',rLine,'МПа')]),
    _section('Температуры',[_row(_number('Тдо штуцера',tBeforeChoke,'°C'),_number('Тлин',tLine,'°C'))]),
    _section('Дросселирование',[
      SegmentedButton<String>(segments:const[ButtonSegment(value:'Штуцер',label:Text('Штуцер'),icon:Icon(Icons.tune)),ButtonSegment(value:'Дроссель',label:Text('Дроссель'),icon:Icon(Icons.settings_input_component))],selected:{chokeMode},onSelectionChanged:(v)=>setState(()=>chokeMode=v.first)),
      const SizedBox(height:10),if(chokeMode=='Дроссель')_row(_number('Дроссель 1',choke1,'%',integer:true),_number('Дроссель 2',choke2,'%',integer:true)) else _text('Штуцер',nozzle,'Сечение штуцера'),
    ]),
    _section('Подземная телеметрия',[_row(_number('Рузд',rDownhole,'МПа'),_number('Тузд',tDownhole,'°C'))]),
    _section('Клапан-отсекатель',[SwitchListTile(contentPadding:EdgeInsets.zero,value:shutoffValveInstalled,onChanged:(v)=>setState(()=>shutoffValveInstalled=v),title:const Text('Клапан-отсекатель установлен'),subtitle:Text(shutoffValveInstalled?'Да':'Нет')),if(shutoffValveInstalled)_number('Рко',rKo,'МПа')]),
    _section('Ингибитор',[SwitchListTile(contentPadding:EdgeInsets.zero,value:inhibitorInstalled,onChanged:(v)=>setState(()=>inhibitorInstalled=v),title:const Text('Подача ингибитора'),subtitle:Text(inhibitorInstalled?'Да':'Нет')),if(inhibitorInstalled)_number('Расход',inhibitorFeed,'л/ч')]),
    _problem(),_save(),
  ])));

  Widget _problem()=>_section('Проблемы по скважине',[TextFormField(controller:problemNote,maxLines:4,decoration:const InputDecoration(labelText:'Описание проблемы',hintText:'Опишите неисправность, отклонение или замечание'))]);
  Widget _save()=>Padding(padding:const EdgeInsets.only(top:4),child:FilledButton.icon(onPressed:saving?null:_saveMeasurement,icon:saving?const SizedBox(width:20,height:20,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.save_outlined),label:Text(saving?'Сохранение…':'Сохранить замер'),style:FilledButton.styleFrom(padding:const EdgeInsets.symmetric(vertical:15))));
  Widget _row(Widget a,Widget b)=>Row(children:[Expanded(child:a),const SizedBox(width:10),Expanded(child:b)]);
  Widget _section(String title,List<Widget> children)=>Card(margin:const EdgeInsets.only(bottom:12),child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(title,style:const TextStyle(fontWeight:FontWeight.w800,fontSize:16)),const SizedBox(height:10),...children])));
  Widget _number(String label,TextEditingController c,String unit,{bool integer=false,bool enabled=true})=>TextFormField(controller:c,enabled:enabled,keyboardType:TextInputType.numberWithOptions(decimal:!integer),decoration:InputDecoration(labelText:label,suffixText:unit,hintText:'Не измерено'),validator:(v){if(!enabled||v==null||v.trim().isEmpty)return null;final n=double.tryParse(v.replaceAll(',','.'));if(n==null||!n.isFinite||(integer&&n%1!=0)||n<0)return'Проверьте значение';return null;});
  Widget _text(String label,TextEditingController c,String hint)=>TextFormField(controller:c,decoration:InputDecoration(labelText:label,hintText:hint));
  PreferredSizeWidget? _walk(){final i=widget.walkIndex;if(i==null)return null;final pad=demoPads.firstWhere((p)=>p.id==widget.padId);return PreferredSize(preferredSize:const Size.fromHeight(34),child:Padding(padding:const EdgeInsets.fromLTRB(16,0,16,10),child:Align(alignment:Alignment.centerLeft,child:Text('${i+1} из ${pad.wells.length}',style:const TextStyle(fontSize:12)))));}

  Future<void> _saveMeasurement() async {
    if(!(formKey.currentState?.validate()??false))return;
    if(well.type==WellType.oil&&(!pkvConfirmed||!pidConfirmed)){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Сначала подтвердите наличие или отсутствие программ ПКВ и ПИД.')));return;}
    setState(()=>saving=true);
    try{
      await repository.setWellStatus(widget.wellId,wellStatus);
      await repository.save(Measurement(padId:widget.padId,wellId:widget.wellId,wellNumber:well.number,measuredAt:DateTime.now(),rtr:_d(rtr),rz:_d(rz),pkvWork:pkvInstalled?_i(pkvWork):null,pkvIdle:pkvInstalled?_i(pkvIdle):null,frequency:pidInstalled?_d(frequency):null,current:pidInstalled?_d(current):null,load:pidInstalled?_d(load):null,rp:_d(rp),tPed:_d(tPed),rInsul:_d(rInsul),pidCurrent:pidInstalled?_d(pidCurrent):null,pidFrequencyRange:pidInstalled?pidFrequencyRange.text.trim():null,pkvInstalled:pkvInstalled,pidInstalled:pidInstalled,rBuf:_d(rBuf),rLine:_d(rLine),tBeforeChoke:_d(tBeforeChoke),tLine:_d(tLine),chokeMode:chokeMode,chokeValue:chokeMode=='Дроссель'?_d(choke1):null,chokeValue2:chokeMode=='Дроссель'?_d(choke2):null,nozzle:chokeMode=='Штуцер'&&nozzle.text.trim().isNotEmpty?nozzle.text.trim():null,rDownhole:_d(rDownhole),tDownhole:_d(tDownhole),shutoffValveInstalled:shutoffValveInstalled,rKo:shutoffValveInstalled?_d(rKo):null,inhibitorInstalled:inhibitorInstalled,inhibitorFeed:inhibitorInstalled?_d(inhibitorFeed):null,problemNote:problemNote.text.trim().isEmpty?null:problemNote.text.trim(),operatorName:SessionService.instance.currentUser.name));
      if(!mounted)return;
      if(widget.walkIndex!=null){final pad=demoPads.firstWhere((p)=>p.id==widget.padId);final next=widget.walkIndex!+1;if(next<pad.wells.length){await repository.saveWalk(widget.padId,next);if(mounted)context.go('/pad/${widget.padId}/walk/$next');}else{await repository.finishWalk(widget.padId);if(mounted)context.go('/pad/${widget.padId}/walk-summary');}}else{ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Замер сохранён в памяти телефона')));context.pop();}
    }finally{if(mounted)setState(()=>saving=false);}
  }
}
