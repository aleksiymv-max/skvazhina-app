import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../core/models/user.dart';
import '../../core/services/session_service.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final username = TextEditingController(text: 'op-001');
  final password = TextEditingController(text: 'operator');
  final name = TextEditingController();
  bool loading = false, register = false;
  String? error;
  UserRole role = UserRole.operator;
  ItrSubrole subrole = ItrSubrole.geologist;
  String chiefId = 'chief-001';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 460),
            child: Card(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Icon(Icons.oil_barrel_outlined, size: 48),
                    const SizedBox(height: 12),
                    const Text('Нефтяник', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w900)),
                    const SizedBox(height: 6),
                    Text(register ? 'Регистрация сотрудника' : 'Офлайн-вход · интернет не требуется', style: const TextStyle(color: Colors.black54)),
                    const SizedBox(height: 22),
                    if (register) ...[
                      TextField(controller: name, decoration: const InputDecoration(labelText: 'ФИО')),
                      const SizedBox(height: 10),
                      DropdownButtonFormField<UserRole>(
                        value: role,
                        decoration: const InputDecoration(labelText: 'Роль'),
                        items: const [
                          DropdownMenuItem(value: UserRole.operator, child: Text('Оператор ДНГ')),
                          DropdownMenuItem(value: UserRole.engineer, child: Text('ИТР')),
                        ],
                        onChanged: (v) => setState(() => role = v ?? UserRole.operator),
                      ),
                      if (role == UserRole.engineer)
                        Padding(
                          padding: const EdgeInsets.only(top: 10),
                          child: DropdownButtonFormField<ItrSubrole>(
                            value: subrole,
                            decoration: const InputDecoration(labelText: 'Градация ИТР'),
                            items: ItrSubrole.values.map((r) => DropdownMenuItem(value: r, child: Text(r.label))).toList(),
                            onChanged: (v) => setState(() => subrole = v ?? ItrSubrole.geologist),
                          ),
                        ),
                      const SizedBox(height: 10),
                      DropdownButtonFormField<String>(
                        value: chiefId,
                        decoration: const InputDecoration(labelText: 'Начальник цеха'),
                        items: const [DropdownMenuItem(value: 'chief-001', child: Text('Иванов Алексей Николаевич'))],
                        onChanged: (v) => setState(() => chiefId = v ?? 'chief-001'),
                      ),
                    ] else ...[
                      TextField(controller: username, decoration: const InputDecoration(labelText: 'Логин')),
                      const SizedBox(height: 10),
                      TextField(controller: password, obscureText: true, decoration: const InputDecoration(labelText: 'Пароль')),
                    ],
                    if (error != null)
                      Padding(padding: const EdgeInsets.only(top: 12), child: Text(error!, style: const TextStyle(color: Colors.red))),
                    const SizedBox(height: 18),
                    SizedBox(
                      width: double.infinity,
                      child: FilledButton(
                        onPressed: loading ? null : (register ? _register : _login),
                        child: Text(loading ? 'Подождите…' : (register ? 'Зарегистрироваться' : 'Войти')),
                      ),
                    ),
                    const SizedBox(height: 8),
                    SizedBox(
                      width: double.infinity,
                      child: TextButton(
                        onPressed: () => setState(() { register = !register; error = null; }),
                        child: Text(register ? 'Вернуться ко входу' : 'Регистрация сотрудника'),
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Text('Тест: chief-001/chief · op-001/operator · eng-001/engineer · adm-001/admin', style: TextStyle(color: Colors.black54, fontSize: 12)),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _login() async {
    setState(() => loading = true);
    try { await SessionService.instance.login(username.text.trim(), password.text); if (mounted) context.go('/'); }
    catch (e) { if (mounted) setState(() => error = e.toString()); }
    finally { if (mounted) setState(() => loading = false); }
  }

  Future<void> _register() async {
    if (name.text.trim().isEmpty) { setState(() => error = 'Введите ФИО'); return; }
    setState(() => loading = true);
    try {
      final id = await SessionService.instance.register(name: name.text.trim(), role: role, subrole: role == UserRole.engineer ? subrole : null, chiefId: chiefId);
      if (mounted) {
        showDialog(context: context, builder: (_) => AlertDialog(
          title: const Text('Заявка отправлена'),
          content: Text('Ваш логин: $id\nПосле подтверждения начальником цеха доступ к месторождению будет открыт.'),
          actions: [TextButton(onPressed: () { Navigator.pop(context); setState(() => register = false); }, child: const Text('Понятно'))],
        ));
      }
    } catch (e) { if (mounted) setState(() => error = e.toString()); }
    finally { if (mounted) setState(() => loading = false); }
  }

  @override void dispose() { username.dispose(); password.dispose(); name.dispose(); super.dispose(); }
}
