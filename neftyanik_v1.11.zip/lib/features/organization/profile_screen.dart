import 'package:flutter/material.dart';
import '../../core/models/user.dart';
import '../../core/services/session_service.dart';

class ProfileScreen extends StatefulWidget { const ProfileScreen({super.key}); @override State<ProfileScreen> createState()=>_ProfileScreenState(); }
class _ProfileScreenState extends State<ProfileScreen> {
  bool customPhoto=false;
  @override Widget build(BuildContext context){ final u=SessionService.instance.currentUser; final position=u.role==UserRole.engineer ? (u.itrSubrole?.label ?? 'ИТР') : u.role.label; return Scaffold(appBar:AppBar(title:const Text('Профиль')),body:ListView(padding:const EdgeInsets.all(16),children:[
    Center(child:Stack(children:[CircleAvatar(radius:54,backgroundColor:Theme.of(context).colorScheme.primaryContainer,child:customPhoto?const Icon(Icons.person,size:60):const Icon(Icons.person_outline,size:60)),Positioned(right:0,bottom:0,child:IconButton.filled(onPressed:()=>setState(()=>customPhoto=true),icon:const Icon(Icons.photo_camera_outlined),tooltip:'Изменить фотографию'))])),
    const SizedBox(height:14),Center(child:Text(u.name,style:const TextStyle(fontSize:21,fontWeight:FontWeight.w900))),Center(child:Text(position,style:const TextStyle(color:Colors.black54))),const SizedBox(height:20),
    Card(child:Column(children:[ListTile(leading:const Icon(Icons.badge_outlined),title:const Text('ФИО'),subtitle:Text(u.name)),const Divider(height:1),ListTile(leading:const Icon(Icons.work_outline),title:const Text('Должность'),subtitle:Text(position)),const Divider(height:1),ListTile(leading:const Icon(Icons.business_outlined),title:const Text('Подразделение'),subtitle:const Text('Добыча нефти и газа'))])),
    const SizedBox(height:12),OutlinedButton.icon(onPressed:()=>setState(()=>customPhoto=!customPhoto),icon:const Icon(Icons.add_a_photo_outlined),label:const Text('Поменять фотографию')),
  ])); }
}
