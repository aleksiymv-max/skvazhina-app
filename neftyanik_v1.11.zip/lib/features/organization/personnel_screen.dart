import 'package:flutter/material.dart';
import '../../core/services/session_service.dart';
import '../../core/models/user.dart';

class PersonnelScreen extends StatelessWidget {
  const PersonnelScreen({super.key});
  @override Widget build(BuildContext context) {
    final user=SessionService.instance.currentUser; final chiefId=user.isChief?user.id:(user.chiefId??'chief-001');
    final workers=SessionService.instance.workersForChief(chiefId); final chiefs=<AppUser>[const AppUser(id:'chief-001',name:'Иванов Алексей Николаевич',role:UserRole.shopChief)];
    final engineers=workers.where((x)=>x.role==UserRole.engineer).toList(); final operators=workers.where((x)=>x.role==UserRole.operator).toList();
    return Scaffold(appBar:AppBar(title:const Text('Персонал')),body:ListView(padding:const EdgeInsets.all(16),children:[
      _group(context,'Начальники цеха',chiefs,Icons.supervisor_account_outlined),const SizedBox(height:10),
      _group(context,'ИТР',engineers,Icons.engineering_outlined),const SizedBox(height:10),
      _group(context,'Операторы ДНГ',operators,Icons.person_outline),
    ]));
  }
  Widget _group(BuildContext context,String title,List<AppUser> users,IconData icon)=>Card(child:ExpansionTile(initiallyExpanded:true,leading:CircleAvatar(backgroundColor:Theme.of(context).colorScheme.primaryContainer,child:Icon(icon)),title:Text(title,style:const TextStyle(fontWeight:FontWeight.w900)),subtitle:Text('${users.length} чел.'),children:users.map((u)=>ListTile(contentPadding:const EdgeInsets.only(left:28,right:16),leading:const CircleAvatar(child:Icon(Icons.person_outline)),title:Text(u.name),subtitle:Text(u.role==UserRole.engineer?(u.itrSubrole?.label??'ИТР'):u.role.label))).toList()));
}
