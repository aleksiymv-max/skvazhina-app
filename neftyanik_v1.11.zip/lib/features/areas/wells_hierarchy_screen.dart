import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../core/models/production_area.dart';
import '../../core/models/well.dart';

class WellsHierarchyScreen extends StatelessWidget {
  const WellsHierarchyScreen({super.key});
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Скважины')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      const Text('Участки добычи', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
      const SizedBox(height: 6), const Text('Выберите участок, затем кустовую площадку для просмотра фонда и начала обхода.', style: TextStyle(color: Colors.black54)),
      const SizedBox(height: 14),
      ...demoAreas.map((a) { final wells=a.pads.expand((p)=>p.wells).toList(); final oil=wells.where((w)=>w.type==WellType.oil).length; return Card(child: ExpansionTile(leading: const CircleAvatar(child: Icon(Icons.account_tree_outlined)), title: Text(a.name, style: const TextStyle(fontWeight: FontWeight.w800)), subtitle: Text('${a.pads.length} кустов · ${wells.length} скважин · нефть $oil · газ ${wells.length-oil}'), children: a.pads.map((p)=>ListTile(contentPadding: const EdgeInsets.only(left: 28,right:16), leading: const Icon(Icons.factory_outlined), title: Text(p.name, style: const TextStyle(fontWeight: FontWeight.w700)), subtitle: Text('${p.wells.length} скважин'), trailing: const Icon(Icons.chevron_right), onTap:()=>context.push('/pad/${p.id}'))).toList())); }).toList(),
    ]),
  );
}
