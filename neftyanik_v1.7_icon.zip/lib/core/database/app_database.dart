import 'dart:convert';
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';
import '../models/measurement.dart';
import '../models/pad.dart';

class AppDatabase {
  AppDatabase._();
  static final AppDatabase instance = AppDatabase._();
  Database? _db;

  Future<Database> get database async => _db ??= await _open();

  Future<Database> _open() async {
    final path = p.join(await getDatabasesPath(), 'oilman_app.db');
    return openDatabase(path, version: 7, onCreate: (db, v) async {
      await _createMeasurements(db);
      await _createWalks(db);
      await _createAudit(db);
      await _createSyncQueue(db);
      await _seedDemoData(db);
    }, onUpgrade: (db, old, current) async {
      if (old < 2) {
        await _addGasColumns(db);
        await _createWalks(db);
      }
      if (old < 3) {
        await db.execute("ALTER TABLE measurements ADD COLUMN field_statuses TEXT NOT NULL DEFAULT '{}'");
      }
      if (old < 4) {
        await _createAudit(db);
      }
      if (old < 5) {
        await _migrateSyncColumns(db);
        await _createSyncQueue(db);
      }
      if (old < 6) {
        await _migrateSyncColumns(db);
      }
      if (old < 7) {
        await _addV7Columns(db);
      }
    });
  }

  Future<void> _createMeasurements(Database db) async {
    await db.execute('''CREATE TABLE measurements (
      id INTEGER PRIMARY KEY AUTOINCREMENT, pad_id TEXT NOT NULL, well_id TEXT NOT NULL, well_number TEXT NOT NULL,
      measured_at TEXT NOT NULL, rtr REAL, rz REAL, pkv_work INTEGER, pkv_idle INTEGER, frequency REAL, current REAL,
      load REAL, rp REAL, t_ped REAL, r_insul REAL, pid_current REAL, pid_frequency_range TEXT, source TEXT NOT NULL, sync_status TEXT NOT NULL DEFAULT 'synced', sync_error TEXT,
      field_statuses TEXT NOT NULL DEFAULT '{}',
      pkv_installed INTEGER NOT NULL DEFAULT 0, pid_installed INTEGER NOT NULL DEFAULT 0,
      gas_state TEXT, r_buf REAL, r_buf_source TEXT, r_inter_dr REAL, r_casing REAL,
      r_line REAL, r_line_source TEXT, t_before_choke REAL, t_line REAL,
      choke_mode TEXT, choke_value REAL, nozzle TEXT,
      r_downhole REAL, t_downhole REAL, r_ko REAL, inhibitor_feed REAL, note TEXT
    )''');
    await db.execute('CREATE INDEX idx_measurements_well_time ON measurements(well_id, measured_at DESC)');
    await db.execute('CREATE INDEX idx_measurements_pad_time ON measurements(pad_id, measured_at DESC)');
  }

  Future<void> _addGasColumns(Database db) async {
    const columns = {
      'gas_state':'TEXT','r_buf':'REAL','r_buf_source':'TEXT','r_inter_dr':'REAL','r_casing':'REAL',
      't_before_choke':'REAL','r_line':'REAL','t_line':'REAL','choke_mode':'TEXT','choke_value':'REAL',
      'nozzle':'TEXT','r_downhole':'REAL','t_downhole':'REAL','r_ko':'REAL','inhibitor_feed':'REAL',
    };
    for (final e in columns.entries) { try { await db.execute('ALTER TABLE measurements ADD COLUMN ${e.key} ${e.value}'); } catch (_) {} }
  }

  Future<void> _addV7Columns(Database db) async {
    const columns = {
      'pkv_installed':'INTEGER NOT NULL DEFAULT 0',
      'pid_installed':'INTEGER NOT NULL DEFAULT 0',
      'r_line_source':'TEXT',
      'choke_mode':'TEXT',
      'choke_value':'REAL',
    };
    for (final e in columns.entries) { try { await db.execute('ALTER TABLE measurements ADD COLUMN ${e.key} ${e.value}'); } catch (_) {} }
    // Удаляемые из формы поля остаются только для совместимости со старыми БД; новые замеры их не заполняют.
  }

  Future<void> _createWalks(Database db) async {
    await db.execute('''CREATE TABLE IF NOT EXISTS walk_sessions (
      pad_id TEXT PRIMARY KEY, current_index INTEGER NOT NULL, started_at TEXT NOT NULL, updated_at TEXT NOT NULL, completed INTEGER NOT NULL DEFAULT 0
    )''');
  }

  Future<void> _seedDemoData(Database db) async {
    final pad = demoPads.firstWhere((p) => p.id == '1017');
    for (final well in pad.wells) {
      if (well.rtr == null && well.rz == null && well.frequency == null && well.current == null) continue;
      await insertMeasurement(Measurement(padId: pad.id, wellId: well.id, wellNumber: well.number, measuredAt: DateTime(2026,9,25,14,15), rtr: well.rtr, rz: well.rz, pkvWork: well.pkvWork, pkvIdle: well.pkvIdle, frequency: well.frequency, current: well.current, load: well.load, rp: well.rp, tPed: well.tPed, rInsul: well.rInsul, pkvInstalled: well.pkvInstalled ?? (well.pkvWork != null || well.pkvIdle != null), pidInstalled: well.pidInstalled ?? (well.frequency != null || well.current != null || well.load != null), source: 'Исходные данные'), db: db);
    }
  }

  Future<void> _migrateSyncColumns(Database db) async {
    try { await db.execute("ALTER TABLE measurements ADD COLUMN sync_status TEXT NOT NULL DEFAULT 'synced'"); } catch (_) {}
    try { await db.execute("ALTER TABLE measurements ADD COLUMN sync_error TEXT"); } catch (_) {}
  }

  Future<void> _createSyncQueue(Database db) async {
    await db.execute('''CREATE TABLE IF NOT EXISTS sync_queue (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      entity_type TEXT NOT NULL,
      entity_id INTEGER NOT NULL,
      created_at TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'pending',
      attempts INTEGER NOT NULL DEFAULT 0,
      last_error TEXT,
      synced_at TEXT
    )''');
    await db.execute('CREATE INDEX IF NOT EXISTS idx_sync_queue_status ON sync_queue(status, created_at)');
  }

  Future<int> insertMeasurement(Measurement m, {Database? db}) async {
    final d = db ?? await database;
    final id = await d.insert('measurements', {
      'pad_id':m.padId,'well_id':m.wellId,'well_number':m.wellNumber,'measured_at':m.measuredAt.toIso8601String(),
      'rtr':m.rtr,'rz':m.rz,'pkv_work':m.pkvWork,'pkv_idle':m.pkvIdle,'frequency':m.frequency,'current':m.current,'load':m.load,
      'rp':m.rp,'t_ped':m.tPed,'r_insul':m.rInsul,'pid_current':m.pidCurrent,'pid_frequency_range':m.pidFrequencyRange,
      'pkv_installed':m.pkvInstalled ? 1 : 0,'pid_installed':m.pidInstalled ? 1 : 0,
      'source':m.source,'field_statuses':'{}','gas_state':m.gasState,'r_buf':m.rBuf,'r_buf_source':m.rBufSource,'r_inter_dr':m.rInterDr,'r_casing':m.rCasing,
      'r_line':m.rLine,'r_line_source':m.rLineSource,'t_before_choke':m.tBeforeChoke,'t_line':m.tLine,
      'choke_mode':m.chokeMode,'choke_value':m.chokeValue,'nozzle':m.nozzle,
      'r_downhole':m.rDownhole,'t_downhole':m.tDownhole,'r_ko':m.rKo,
      'inhibitor_feed':m.inhibitorFeed,'note':m.note,'sync_status':m.source == 'Исходные данные' ? 'synced' : 'pending','sync_error':null,
    });
    if (m.source != 'Исходные данные') {
      await d.insert('sync_queue', {'entity_type':'measurement','entity_id':id,'created_at':DateTime.now().toIso8601String(),'status':'pending'});
    }
    return id;
  }

  Measurement _fromMap(Map<String,Object?> m) => Measurement(
    id:m['id'] as int?,padId:m['pad_id'] as String,wellId:m['well_id'] as String,wellNumber:m['well_number'] as String,
    measuredAt:DateTime.parse(m['measured_at'] as String),rtr:(m['rtr'] as num?)?.toDouble(),rz:(m['rz'] as num?)?.toDouble(),
    pkvWork:m['pkv_work'] as int?,pkvIdle:m['pkv_idle'] as int?,frequency:(m['frequency'] as num?)?.toDouble(),current:(m['current'] as num?)?.toDouble(),
    load:(m['load'] as num?)?.toDouble(),rp:(m['rp'] as num?)?.toDouble(),tPed:(m['t_ped'] as num?)?.toDouble(),rInsul:(m['r_insul'] as num?)?.toDouble(),
    pidCurrent:(m['pid_current'] as num?)?.toDouble(),pidFrequencyRange:m['pid_frequency_range'] as String?,
    pkvInstalled:(m['pkv_installed'] as num?)?.toInt() == 1, pidInstalled:(m['pid_installed'] as num?)?.toInt() == 1,
    source:m['source'] as String,
    gasState:m['gas_state'] as String?,rBuf:(m['r_buf'] as num?)?.toDouble(),rBufSource:m['r_buf_source'] as String?,rInterDr:(m['r_inter_dr'] as num?)?.toDouble(),rCasing:(m['r_casing'] as num?)?.toDouble(),
    rLine:(m['r_line'] as num?)?.toDouble(),rLineSource:m['r_line_source'] as String?,tBeforeChoke:(m['t_before_choke'] as num?)?.toDouble(),tLine:(m['t_line'] as num?)?.toDouble(),
    chokeMode:m['choke_mode'] as String?,chokeValue:(m['choke_value'] as num?)?.toDouble(),nozzle:m['nozzle'] as String?,
    rDownhole:(m['r_downhole'] as num?)?.toDouble(),tDownhole:(m['t_downhole'] as num?)?.toDouble(),rKo:(m['r_ko'] as num?)?.toDouble(),
    inhibitorFeed:(m['inhibitor_feed'] as num?)?.toDouble(),note:m['note'] as String?,
  );

  Map<String,String> _decodeStatuses(String? value) {
    if (value == null || value.isEmpty) return const {};
    try {
      final decoded = jsonDecode(value);
      return Map<String,String>.from(decoded as Map);
    } catch (_) {
      return const {};
    }
  }

  Future<Measurement?> byId(int id) async { final db=await database; final r=await db.query('measurements',where:'id=?',whereArgs:[id],limit:1); return r.isEmpty?null:_fromMap(r.first); }

  Future<Measurement?> latestForWell(String wellId) async { final db=await database; final r=await db.query('measurements',where:'well_id=?',whereArgs:[wellId],orderBy:'measured_at DESC,id DESC',limit:1); return r.isEmpty?null:_fromMap(r.first); }
  Future<List<Measurement>> history({String? padId,String? wellId,int limit=100}) async { final db=await database; String? w; List<Object?>? a; if(wellId!=null){w='well_id=?';a=[wellId];} else if(padId!=null){w='pad_id=?';a=[padId];} final r=await db.query('measurements',where:w,whereArgs:a,orderBy:'measured_at DESC,id DESC',limit:limit); return r.map(_fromMap).toList(); }


  Future<List<Measurement>> trendMeasurements({required String wellId, required DateTime from, required DateTime to}) async {
    final db = await database;
    final rows = await db.query('measurements', where:'well_id=? AND measured_at>=? AND measured_at<=?', whereArgs:[wellId, from.toIso8601String(), to.toIso8601String()], orderBy:'measured_at ASC, id ASC');
    return rows.map(_fromMap).toList();
  }

  Future<void> _createAudit(Database db) async {
    await db.execute('''CREATE TABLE IF NOT EXISTS audit_log (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      measurement_id INTEGER NOT NULL,
      user_id TEXT NOT NULL,
      user_name TEXT NOT NULL,
      created_at TEXT NOT NULL,
      parameter TEXT NOT NULL,
      old_value TEXT,
      new_value TEXT,
      reason TEXT NOT NULL,
      comment TEXT
    )''');
    await db.execute('CREATE INDEX IF NOT EXISTS idx_audit_measurement ON audit_log(measurement_id, created_at DESC)');
  }

  Future<void> addAudit({required int measurementId, required String userId, required String userName, required String parameter, String? oldValue, String? newValue, required String reason, String? comment}) async {
    final db = await database;
    await db.insert('audit_log', {
      'measurement_id': measurementId, 'user_id': userId, 'user_name': userName,
      'created_at': DateTime.now().toIso8601String(), 'parameter': parameter,
      'old_value': oldValue, 'new_value': newValue, 'reason': reason, 'comment': comment,
    });
  }

  Future<List<Map<String,Object?>>> auditForMeasurement(int measurementId) async {
    final db = await database;
    return db.query('audit_log', where: 'measurement_id=?', whereArgs: [measurementId], orderBy: 'created_at DESC, id DESC');
  }

  Future<int> correctMeasurement({required int measurementId, required String parameter, required String? newValue, required String userId, required String userName, required String reason, String? comment}) async {
    final db = await database;
    final rows = await db.query('measurements', where:'id=?', whereArgs:[measurementId], limit:1);
    if (rows.isEmpty) throw StateError('Замер не найден');
    final oldValue = rows.first[parameter]?.toString();
    final text = newValue?.trim() ?? '';
    const textFields = {'pid_frequency_range','r_buf_source','r_line_source','choke_mode','nozzle','note'};
    Object? parsed;
    if (textFields.contains(parameter)) {
      parsed = text.isEmpty ? null : text;
    } else if (parameter == 'pkv_installed' || parameter == 'pid_installed') {
      if (text == 'Да' || text == '1' || text.toLowerCase() == 'true') parsed = 1;
      else if (text == 'Нет' || text == '0' || text.toLowerCase() == 'false') parsed = 0;
      else throw ArgumentError('Выберите Да или Нет');
    } else if (parameter == 'pkv_work' || parameter == 'pkv_idle') {
      parsed = text.isEmpty ? null : int.tryParse(text);
      if (text.isNotEmpty && parsed == null) throw ArgumentError('Введите целое число');
    } else {
      parsed = text.isEmpty ? null : double.tryParse(text.replaceAll(',', '.'));
      if (text.isNotEmpty && parsed == null) throw ArgumentError('Введите число');
    }
    await db.update('measurements', {parameter: parsed}, where:'id=?', whereArgs:[measurementId]);
    await addAudit(measurementId:measurementId,userId:userId,userName:userName,parameter:parameter,oldValue:oldValue,newValue:text.isEmpty?null:text,reason:reason,comment:comment);
    return measurementId;
  }

  Future<void> saveWalk(String padId,int index,{bool completed=false}) async { final db=await database; await db.insert('walk_sessions',{'pad_id':padId,'current_index':index,'started_at':DateTime.now().toIso8601String(),'updated_at':DateTime.now().toIso8601String(),'completed':completed?1:0},conflictAlgorithm:ConflictAlgorithm.replace); }
  Future<Map<String,Object?>?> activeWalk(String padId) async { final db=await database; final r=await db.query('walk_sessions',where:'pad_id=? AND completed=0',whereArgs:[padId],limit:1); return r.isEmpty?null:r.first; }
  Future<void> finishWalk(String padId) async { final db=await database; await db.update('walk_sessions',{'completed':1,'updated_at':DateTime.now().toIso8601String()},where:'pad_id=?',whereArgs:[padId]); }
  Future<List<Map<String,Object?>>> pendingSyncItems() async {
    final db = await database;
    return db.query('sync_queue', where: "status IN ('pending','error')", orderBy: 'created_at ASC');
  }

  Future<int> pendingSyncCount() async {
    final db = await database;
    final r = await db.rawQuery("SELECT COUNT(*) c FROM sync_queue WHERE status IN ('pending','error')");
    return Sqflite.firstIntValue(r) ?? 0;
  }

  Future<void> markSyncing(int queueId, int measurementId) async {
    final db = await database;
    await db.update('sync_queue', {'status':'syncing','attempts':1}, where:'id=?', whereArgs:[queueId]);
    await db.update('measurements', {'sync_status':'syncing','sync_error':null}, where:'id=?', whereArgs:[measurementId]);
  }

  Future<void> markSynced(int queueId, int measurementId) async {
    final db = await database;
    final now = DateTime.now().toIso8601String();
    await db.update('sync_queue', {'status':'synced','synced_at':now,'last_error':null}, where:'id=?', whereArgs:[queueId]);
    await db.update('measurements', {'sync_status':'synced','sync_error':null}, where:'id=?', whereArgs:[measurementId]);
  }

  Future<void> markSyncError(int queueId, int measurementId, String error) async {
    final db = await database;
    await db.update('sync_queue', {'status':'error','last_error':error}, where:'id=?', whereArgs:[queueId]);
    await db.update('measurements', {'sync_status':'error','sync_error':error}, where:'id=?', whereArgs:[measurementId]);
  }

  Future<void> resetSyncing() async {
    final db = await database;
    await db.update('sync_queue', {'status':'pending'}, where:"status='syncing'");
  }

  Future<int> checkedCount(String padId) async { final db=await database; final r=await db.rawQuery('SELECT COUNT(DISTINCT well_id) c FROM measurements WHERE pad_id=?',[padId]); return Sqflite.firstIntValue(r)??0; }
  Future<int> checkedPadsSince(DateTime since) async { final db=await database; final r=await db.rawQuery('SELECT COUNT(DISTINCT pad_id) c FROM measurements WHERE measured_at>=?', [since.toIso8601String()]); return Sqflite.firstIntValue(r)??0; }
}
