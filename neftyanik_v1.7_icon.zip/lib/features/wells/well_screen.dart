import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../core/models/measurement.dart';
import '../../core/models/pad.dart';
import '../../core/models/well.dart';
import '../../core/repositories/measurement_repository.dart';

class WellScreen extends StatefulWidget {
  const WellScreen({super.key, required this.padId, required this.wellId, this.walkIndex});
  final String padId;
  final String wellId;
  final int? walkIndex;

  @override State<WellScreen> createState() => _WellScreenState();
}

class _WellScreenState extends State<WellScreen> {
  final formKey = GlobalKey<FormState>();
  final repository = MeasurementRepository();
  late Well well;
  late final TextEditingController rtr, rz, pkvWork, pkvIdle, pidCurrent, pidFrequencyRange, frequency, current, load, rp, tPed, rInsul;
  late final TextEditingController rBuf, rBufSource, rInterDr, rCasing, rLine, rLineSource, tBeforeChoke, tLine, nozzle, rDownhole, tDownhole, rKo, inhibitorFeed, note;
  bool loading = true, saving = false, pkvInstalled = false, pidInstalled = false, pkvConfirmed = false, pidConfirmed = false;
  String chokeMode = 'Штуцер';
  double chokeValue = 50;

  @override void initState() {
    super.initState();
    final pad = demoPads.firstWhere((p) => p.id == widget.padId);
    well = pad.wells.firstWhere((w) => w.id == widget.wellId);
    rtr=TextEditingController(); rz=TextEditingController(); pkvWork=TextEditingController(); pkvIdle=TextEditingController(); pidCurrent=TextEditingController(); pidFrequencyRange=TextEditingController(); frequency=TextEditingController(); current=TextEditingController(); load=TextEditingController(); rp=TextEditingController(); tPed=TextEditingController(); rInsul=TextEditingController();
    rBuf=TextEditingController(); rBufSource=TextEditingController(); rInterDr=TextEditingController(); rCasing=TextEditingController(); rLine=TextEditingController(); rLineSource=TextEditingController(); tBeforeChoke=TextEditingController(); tLine=TextEditingController(); nozzle=TextEditingController(); rDownhole=TextEditingController(); tDownhole=TextEditingController(); rKo=TextEditingController(); inhibitorFeed=TextEditingController(); note=TextEditingController();
    _loadLatest();
  }

  Future<void> _loadLatest() async {
    final m = await repository.latestForWell(widget.wellId);
    if (m != null) {
      _setControllers(m);
      pkvInstalled = m.pkvInstalled;
      pidInstalled = m.pidInstalled;
      pkvConfirmed = true;
      pidConfirmed = true;
      chokeMode = m.chokeMode ?? 'Штуцер';
      chokeValue = m.chokeValue ?? 50;
    } else {
      _setFromWell();
      pkvInstalled = well.pkvInstalled ?? false;
      pidInstalled = well.pidInstalled ?? false;
    }
    if (mounted) setState(() => loading = false);
  }

  void _setFromWell() {
    rtr.text=_value(well.rtr); rz.text=_value(well.rz); pkvWork.text=well.pkvWork?.toString()??''; pkvIdle.text=well.pkvIdle?.toString()??'';
    frequency.text=_value(well.frequency); current.text=_value(well.current); load.text=_value(well.load); rp.text=_value(well.rp); tPed.text=_value(well.tPed); rInsul.text=_value(well.rInsul);
  }

  void _setControllers(Measurement m) {
    rtr.text=_value(m.rtr); rz.text=_value(m.rz); pkvWork.text=m.pkvWork?.toString()??''; pkvIdle.text=m.pkvIdle?.toString()??'';
    pidCurrent.text=_value(m.pidCurrent); pidFrequencyRange.text=m.pidFrequencyRange??''; frequency.text=_value(m.frequency); current.text=_value(m.current); load.text=_value(m.load); rp.text=_value(m.rp); tPed.text=_value(m.tPed); rInsul.text=_value(m.rInsul);
    rBuf.text=_value(m.rBuf); rBufSource.text=m.rBufSource??''; rInterDr.text=_value(m.rInterDr); rCasing.text=_value(m.rCasing); rLine.text=_value(m.rLine); rLineSource.text=m.rLineSource??''; tBeforeChoke.text=_value(m.tBeforeChoke); tLine.text=_value(m.tLine); nozzle.text=m.nozzle??''; rDownhole.text=_value(m.rDownhole); tDownhole.text=_value(m.tDownhole); rKo.text=_value(m.rKo); inhibitorFeed.text=_value(m.inhibitorFeed); note.text=m.note??'';
  }

  String _value(double? v)=>v==null?'':v.toString();
  double? _double(TextEditingController c)=>double.tryParse(c.text.trim().replaceAll(',','.'));
  int? _int(TextEditingController c)=>int.tryParse(c.text.trim());
  int? get pkvCycle { final a=_int(pkvWork), b=_int(pkvIdle); return a!=null&&b!=null?a+b:null; }

  @override void dispose(){ for(final c in [rtr,rz,pkvWork,pkvIdle,pidCurrent,pidFrequencyRange,frequency,current,load,rp,tPed,rInsul,rBuf,rBufSource,rInterDr,rCasing,rLine,rLineSource,tBeforeChoke,tLine,nozzle,rDownhole,tDownhole,rKo,inhibitorFeed,note]){c.dispose();} super.dispose(); }

  @override Widget build(BuildContext context){
    if(loading)return const Scaffold(body:Center(child:CircularProgressIndicator()));
    return well.type==WellType.gasCondensate?_gasScreen():_oilScreen();
  }

  Scaffold _oilScreen()=>Scaffold(
    appBar:AppBar(title:Text('Скважина ${well.number}'),bottom:_walkIndicator()),
    body:Form(key:formKey,child:ListView(padding:const EdgeInsets.fromLTRB(16,4,16,28),children:[
      Row(children:[Text(_statusText(well.status),style:const TextStyle(color:Colors.black54)),const Spacer(),const Text('Данные сохраняются локально',style:TextStyle(color:Colors.black54,fontSize:12))]),
      const SizedBox(height:14),
      _section('Давление',[_row(_number('Ртр',rtr,'кгс/см²'),_number('Рз',rz,'кгс/см²'))]),
      _section('ПКВ',[CheckboxListTile(contentPadding:EdgeInsets.zero,value:pkvInstalled,onChanged:(v)=>setState((){pkvInstalled=v??false;pkvConfirmed=true;}),title:const Text('На скважине установлена программа ПКВ'),subtitle:Text(pkvConfirmed?'Подтверждено':'Поставьте/снимите галочку для подтверждения') ),if(pkvInstalled)_row(_number('Работа',pkvWork,'мин',integer:true),_number('Простой',pkvIdle,'мин',integer:true)),if(pkvInstalled)AnimatedBuilder(animation:Listenable.merge([pkvWork,pkvIdle]),builder:(_,__)=>Text('Цикл: ${pkvCycle==null?'—':'$pkvCycle мин'}',style:const TextStyle(color:Colors.black54)))]),
      _section('ПИД',[CheckboxListTile(contentPadding:EdgeInsets.zero,value:pidInstalled,onChanged:(v)=>setState((){pidInstalled=v??false;pidConfirmed=true;}),title:const Text('На скважине установлена программа ПИД'),subtitle:Text(pidConfirmed?'Подтверждено':'Поставьте/снимите галочку для подтверждения') ),if(pidInstalled)_row(_number('Ток ПИД',pidCurrent,'А'),_text('Диапазон F',pidFrequencyRange,'Например 40–60 Гц'))]),
      _section('Фактические параметры',[_row(_number('F',frequency,'Гц',enabled:pidInstalled),_number('Iср',current,'А',enabled:pidInstalled)),const SizedBox(height:10),_row(_number('Загрузка',load,'%',enabled:pidInstalled),_number('Рпр',rp,'атм')),const SizedBox(height:10),_row(_number('Тпэд',tPed,'°C'),_number('Rизол',rInsul,'кОм'))]),
      _saveButton(),
    ])),
  );

  Scaffold _gasScreen()=>Scaffold(
    appBar:AppBar(title:Text('Скважина ${well.number}'),bottom:_walkIndicator()),
    body:Form(key:formKey,child:ListView(padding:const EdgeInsets.fromLTRB(16,4,16,28),children:[
      const Text('Газоконденсатные параметры',style:TextStyle(fontSize:20,fontWeight:FontWeight.w800)),const SizedBox(height:12),
      _section('Давления',[
        _row(_number('Рбуф',rBuf,'МПа'),_sourceField('Источник Рбуф',rBufSource)),
        const SizedBox(height:10),_row(_number('Рлин',rLine,'МПа'),_sourceField('Источник Рлин',rLineSource)),
        const SizedBox(height:10),_row(_number('Рмеж. др.',rInterDr,'МПа'),_number('Рзатр',rCasing,'МПа')),
      ]),
      _section('Температура',[_row(_number('Тлин',tLine,'°C'),_number('Тузд',tDownhole,'°C'))]),
      _section('Дросселирование',[
        Row(children:[const Text('Режим',style:TextStyle(fontWeight:FontWeight.w700)),const Spacer(),Text(chokeMode,style:const TextStyle(fontWeight:FontWeight.w700))]),
        const SizedBox(height:6),
        SegmentedButton<String>(segments:const[ButtonSegment(value:'Штуцер',label:Text('Штуцер'),icon:Icon(Icons.tune)),ButtonSegment(value:'Дроссель',label:Text('Дроссель'),icon:Icon(Icons.settings_input_component))],selected:{chokeMode},onSelectionChanged:(v)=>setState(()=>chokeMode=v.first)),
        if(chokeMode=='Дроссель')...[
          Text('Открытие дросселя: ${chokeValue.round()} %',style:const TextStyle(fontWeight:FontWeight.w600)),
          Slider(value:chokeValue,min:0,max:100,divisions:100,label:'${chokeValue.round()} %',onChanged:(v)=>setState(()=>chokeValue=v)),
        ] else _text('Штуцер',nozzle,'Сечение штуцера'),
      ]),
      _section('Рабочие параметры',[_row(_number('Рузд',rDownhole,'МПа'),_number('Рко',rKo,'МПа')),const SizedBox(height:10),_number('Подача ингибитора',inhibitorFeed,'кг/ч')]),
      _section('Замечание',[TextFormField(controller:note,maxLines:3,decoration:const InputDecoration(labelText:'Комментарий оператора'))]),
      _saveButton(),
    ])),
  );

  Widget _saveButton()=>Padding(padding:const EdgeInsets.only(top:4),child:FilledButton.icon(onPressed:saving?null:_save,icon:saving?const SizedBox(width:20,height:20,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.save_outlined),label:Text(saving?'Сохранение…':'Сохранить замер'),style:FilledButton.styleFrom(padding:const EdgeInsets.symmetric(vertical:15))));
  Widget _row(Widget a,Widget b)=>Row(children:[Expanded(child:a),const SizedBox(width:10),Expanded(child:b)]);
  Widget _section(String title,List<Widget> children)=>Card(margin:const EdgeInsets.only(bottom:12),child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(title,style:const TextStyle(fontWeight:FontWeight.w800,fontSize:16)),const SizedBox(height:10),...children])));

  Widget _number(String label,TextEditingController c,String unit,{bool integer=false,bool enabled=true})=>TextFormField(controller:c,enabled:enabled,keyboardType:TextInputType.numberWithOptions(decimal:!integer),decoration:InputDecoration(labelText:label,suffixText:unit,hintText:'Не измерено'),validator:(v){if(!enabled||v==null||v.trim().isEmpty)return null;final n=double.tryParse(v.replaceAll(',','.'));if(n==null||!n.isFinite||(integer&&n%1!=0)||n<0)return 'Проверьте значение';return null;});
  Widget _text(String label,TextEditingController c,String hint)=>TextFormField(controller:c,decoration:InputDecoration(labelText:label,hintText:hint));
  Widget _sourceField(String label,TextEditingController c)=>DropdownButtonFormField<String>(value:c.text.isEmpty?null:c.text,decoration:InputDecoration(labelText:label),items:const[DropdownMenuItem(value:'Механический манометр',child:Text('Механический манометр')),DropdownMenuItem(value:'БЭЛП',child:Text('БЭЛП')),DropdownMenuItem(value:'УМТ',child:Text('УМТ'))],onChanged:(v)=>c.text=v??'');

  PreferredSizeWidget? _walkIndicator(){final i=widget.walkIndex;if(i==null)return null;final pad=demoPads.firstWhere((p)=>p.id==widget.padId);return PreferredSize(preferredSize:const Size.fromHeight(34),child:Padding(padding:const EdgeInsets.fromLTRB(16,0,16,10),child:Align(alignment:Alignment.centerLeft,child:Text('${i+1} из ${pad.wells.length}',style:const TextStyle(fontSize:12)))));}
  String _statusText(WellStatus s)=>switch(s){WellStatus.working=>'Работает',WellStatus.stopped=>'Остановлена',WellStatus.krs=>'КРС',WellStatus.pdf=>'ПДФ',WellStatus.disabled=>'Отключен',WellStatus.underload=>'Недогруз'};

  Future<void> _save() async {
    if(!(formKey.currentState?.validate()??false))return;
    if(well.type==WellType.oil && (!pkvConfirmed || !pidConfirmed)){
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Сначала подтвердите наличие или отсутствие программ ПКВ и ПИД.')));return;
    }
    setState(()=>saving=true);
    try {
      await repository.save(Measurement(padId:widget.padId,wellId:widget.wellId,wellNumber:well.number,measuredAt:DateTime.now(),
        rtr:_double(rtr),rz:_double(rz),pkvWork:pkvInstalled?_int(pkvWork):null,pkvIdle:pkvInstalled?_int(pkvIdle):null,
        frequency:_double(frequency),current:_double(current),load:_double(load),rp:_double(rp),tPed:_double(tPed),rInsul:_double(rInsul),pidCurrent:pidInstalled?_double(pidCurrent):null,pidFrequencyRange:pidInstalled?pidFrequencyRange.text.trim():null,
        pkvInstalled:pkvInstalled,pidInstalled:pidInstalled,
        rBuf:_double(rBuf),rBufSource:rBufSource.text.trim().isEmpty?null:rBufSource.text.trim(),rInterDr:_double(rInterDr),rCasing:_double(rCasing),rLine:_double(rLine),rLineSource:rLineSource.text.trim().isEmpty?null:rLineSource.text.trim(),tBeforeChoke:null,tLine:_double(tLine),chokeMode:chokeMode,chokeValue:chokeMode=='Дроссель'?chokeValue:null,nozzle:chokeMode=='Штуцер'&&nozzle.text.trim().isNotEmpty?nozzle.text.trim():null,rDownhole:_double(rDownhole),tDownhole:_double(tDownhole),rKo:_double(rKo),inhibitorFeed:_double(inhibitorFeed),note:note.text.trim().isEmpty?null:note.text.trim()),);
      if(!mounted)return;
      if(widget.walkIndex!=null){
        final pad=demoPads.firstWhere((p)=>p.id==widget.padId);
        final next=widget.walkIndex!+1;
        if(next<pad.wells.length){await repository.saveWalk(widget.padId,next);context.go('/pad/${widget.padId}/walk/$next');}
        else{await repository.finishWalk(widget.padId);context.go('/pad/${widget.padId}/walk-summary');}
      }else{ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Замер сохранён в памяти телефона')));context.pop();}
    } finally {if(mounted)setState(()=>saving=false);}
  }
}
