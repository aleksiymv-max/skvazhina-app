import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../core/models/measurement.dart';
import '../../core/models/pad.dart';
import '../../core/models/well.dart';
import '../../core/repositories/measurement_repository.dart';

class TrendsScreen extends StatefulWidget { const TrendsScreen({super.key}); @override State<TrendsScreen> createState()=>_TrendsScreenState(); }
class _TrendsScreenState extends State<TrendsScreen>{
  final repo=MeasurementRepository();
  String? padId,wellId;
  String parameter='frequency';
  int days=7;
  List<Measurement> data=[];
  bool loading=false;
  Pad? get pad=>padId==null?null:demoPads.where((p)=>p.id==padId).firstOrNull;
  Well? get well=>pad?.wells.where((w)=>w.id==wellId).firstOrNull;

  @override void initState(){super.initState();padId=demoPads.first.id;wellId=pad!.wells.first.id;_load();}
  List<MapEntry<String,String>> _parameters(){final w=well;final base=<String,String>{'rtr':'Ртр','rz':'Рз','frequency':'F','current':'Iср','load':'Загрузка','rp':'Рпр','t_ped':'Тпэд','r_insul':'Rизол'}.entries.toList();if(w?.type==WellType.gasCondensate){return <String,String>{'r_buf':'Рбуф','r_line':'Рлин','r_inter_dr':'Рмеж. др.','r_casing':'Рзатр','t_before_choke':'Т до дросселя','t_line':'Тлин','choke_value':'Дроссель, %','r_downhole':'Рузд','t_downhole':'Тузд','r_ko':'Рко','inhibitor_feed':'Подача ингибитора'}.entries.toList();}return base;}
  double? _value(Measurement m){switch(parameter){case'rtr':return m.rtr;case'rz':return m.rz;case'frequency':return m.frequency;case'current':return m.current;case'load':return m.load;case'rp':return m.rp;case't_ped':return m.tPed;case'r_insul':return m.rInsul;case'r_buf':return m.rBuf;case'r_line':return m.rLine;case'r_inter_dr':return m.rInterDr;case'r_casing':return m.rCasing;case't_before_choke':return m.tBeforeChoke;case't_line':return m.tLine;case'choke_value':return m.chokeValue;case'r_downhole':return m.rDownhole;case't_downhole':return m.tDownhole;case'r_ko':return m.rKo;case'inhibitor_feed':return m.inhibitorFeed;default:return null;}}
  String _label()=>_parameters().firstWhere((e)=>e.key==parameter,orElse:()=>const MapEntry('','Параметр')).value;
  Future<void> _load()async{if(wellId==null)return;setState(()=>loading=true);final now=DateTime.now();data=await repo.trends(wellId:wellId!,from:now.subtract(Duration(days:days)),to:now);if(mounted)setState(()=>loading=false);}

  @override Widget build(BuildContext context){final params=_parameters();if(!params.any((e)=>e.key==parameter))parameter=params.first.key;return Scaffold(appBar:AppBar(title:const Text('Тренды')),body:ListView(padding:const EdgeInsets.all(16),children:[
    const Text('Параметры тренда',style:TextStyle(fontSize:20,fontWeight:FontWeight.w800)),const SizedBox(height:10),
    DropdownButtonFormField<String>(value:padId,decoration:const InputDecoration(labelText:'Кустовая площадка'),items:demoPads.map((p)=>DropdownMenuItem(value:p.id,child:Text(p.name))).toList(),onChanged:(v){setState((){padId=v;wellId=pad?.wells.firstOrNull?.id;});_load();}),
    const SizedBox(height:10),DropdownButtonFormField<String>(value:wellId,decoration:const InputDecoration(labelText:'Скважина'),items:(pad?.wells??const <Well>[]).map((w)=>DropdownMenuItem(value:w.id,child:Text('Скважина ${w.number}'))).toList(),onChanged:(v){setState(()=>wellId=v);_load();}),
    const SizedBox(height:10),DropdownButtonFormField<String>(value:params.any((e)=>e.key==parameter)?parameter:params.first.key,decoration:const InputDecoration(labelText:'Параметр'),items:params.map((e)=>DropdownMenuItem(value:e.key,child:Text(e.value))).toList(),onChanged:(v){setState(()=>parameter=v!);_load();}),
    const SizedBox(height:10),DropdownButtonFormField<int>(value:days,decoration:const InputDecoration(labelText:'Период'),items:const[DropdownMenuItem(value:1,child:Text('Последние 24 часа')),DropdownMenuItem(value:7,child:Text('Последние 7 дней')),DropdownMenuItem(value:30,child:Text('Последние 30 дней')),DropdownMenuItem(value:90,child:Text('Последние 90 дней'))],onChanged:(v){setState(()=>days=v!);_load();}),
    const SizedBox(height:18),
    if(loading)const Padding(padding:EdgeInsets.all(30),child:Center(child:CircularProgressIndicator())) else _chart(),
  ]));}

  Widget _chart() {
    final numeric = data.map(_value).whereType<double>().toList();
    if (numeric.isEmpty) {
      return Card(
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Text('Нет измерений параметра «${_label()}» за выбранный период.'),
        ),
      );
    }
    final latest = numeric.last;
    final min = numeric.reduce((a, b) => a < b ? a : b);
    final max = numeric.reduce((a, b) => a > b ? a : b);
    final lastMeasurement = data.last;
    return Column(
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: SizedBox(
              height: 240,
              child: CustomPaint(painter: _TrendPainter(values: numeric)),
            ),
          ),
        ),
        const SizedBox(height: 10),
        Card(
          child: ListTile(
            title: Text('Скважина ${well?.number} · ${_label()}'),
            subtitle: Text(
              '${DateFormat('dd.MM.yyyy HH:mm').format(lastMeasurement.measuredAt)}\nДиапазон: ${_fmt(min)} — ${_fmt(max)}',
            ),
            trailing: Text(_fmt(latest), style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
          ),
        ),
      ],
    );
  }

  String _fmt(double v)=>v.toStringAsFixed(v.truncateToDouble()==v?0:2).replaceAll('.',',');
}
class _TrendPainter extends CustomPainter{_TrendPainter({required this.values});final List<double> values;@override void paint(Canvas c,Size s){final axis=Paint()..color=Colors.grey.shade300..strokeWidth=1;final line=Paint()..color=Colors.blue..strokeWidth=3..style=PaintingStyle.stroke;c.drawLine(const Offset(22,10),Offset(22,s.height-25),axis);c.drawLine(Offset(22,s.height-25),Offset(s.width-8,s.height-25),axis);final min=values.reduce((a,b)=>a<b?a:b),max=values.reduce((a,b)=>a>b?a:b);final span=max-min==0?1:max-min;final pts=<Offset>[];for(var i=0;i<values.length;i++){final x=22+(s.width-32)*(values.length==1?0.5:i/(values.length-1));final y=12+(s.height-42)*(1-(values[i]-min)/span);pts.add(Offset(x,y));}if(pts.isNotEmpty){final path=Path()..moveTo(pts.first.dx,pts.first.dy);for(final p in pts.skip(1))path.lineTo(p.dx,p.dy);c.drawPath(path,line);}}@override bool shouldRepaint(covariant _TrendPainter old)=>old.values!=values;}
