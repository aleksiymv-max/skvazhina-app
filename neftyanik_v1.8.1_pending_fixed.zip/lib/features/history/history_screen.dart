import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../core/models/measurement.dart';
import '../../core/models/pad.dart';
import '../../core/models/well.dart';
import '../../core/repositories/measurement_repository.dart';
import '../../core/services/export_service.dart';
import '../../core/services/session_service.dart';

class HistoryScreen extends StatefulWidget { const HistoryScreen({super.key}); @override State<HistoryScreen> createState()=>_HistoryScreenState(); }
class _HistoryScreenState extends State<HistoryScreen> {
  final repo=MeasurementRepository(); String? padId,wellId; List<Measurement> items=[]; bool loading=false; String? selectedDate;
  Pad? get pad=>padId==null?null:demoPads.where((p)=>p.id==padId).firstOrNull;
  Well? get well=>pad?.wells.where((w)=>w.id==wellId).firstOrNull;
  @override void initState(){super.initState();padId=demoPads.first.id;_setWell();_load();}
  void _setWell(){final ws=pad?.wells??const <Well>[];wellId=ws.isEmpty?null:ws.first.id;selectedDate=null;}
  Future<void> _load() async {setState(()=>loading=true);items=await repo.history(wellId:wellId,limit:500);if(mounted)setState(()=>loading=false);}
  List<DateTime> get dates {final seen=<String>{};final out=<DateTime>[];for(final m in items){final k=m.measuredAt.toIso8601String();if(seen.add(k))out.add(m.measuredAt);}return out;}
  Measurement? _forDate(DateTime d)=>items.where((m)=>m.measuredAt.isAtSameMomentAs(d)).firstOrNull;
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('История')),body:ListView(padding:const EdgeInsets.all(16),children:[
    const Text('Объект',style:TextStyle(fontSize:18,fontWeight:FontWeight.w800)),const SizedBox(height:8),
    DropdownButtonFormField<String>(value:padId,decoration:const InputDecoration(labelText:'Кустовая площадка'),items:demoPads.map((p)=>DropdownMenuItem(value:p.id,child:Text(p.name))).toList(),onChanged:(v){setState((){padId=v;_setWell();});_load();}),const SizedBox(height:10),
    DropdownButtonFormField<String>(value:wellId,decoration:const InputDecoration(labelText:'Скважина'),items:(pad?.wells??const <Well>[]).map((w)=>DropdownMenuItem(value:w.id,child:Text('Скважина ${w.number}'))).toList(),onChanged:(v){setState((){wellId=v;selectedDate=null;});_load();}),const SizedBox(height:18),
    if(well!=null) Text('Даты внесения — скважина ${well!.number}',style:const TextStyle(fontSize:18,fontWeight:FontWeight.w800)),const SizedBox(height:8),
    if(loading)const Center(child:Padding(padding:EdgeInsets.all(24),child:CircularProgressIndicator())) else if(items.isEmpty)const Card(child:Padding(padding:EdgeInsets.all(18),child:Text('Для выбранной скважины замеров пока нет.'))) else ...dates.map((d)=>_dateCard(d)),
  ]));
  Widget _dateCard(DateTime d){final m=_forDate(d)!;final key=d.toIso8601String();final open=selectedDate==key;return Card(margin:const EdgeInsets.only(bottom:10),child:Column(children:[ListTile(leading:const CircleAvatar(child:Icon(Icons.calendar_today_outlined)),title:Text(DateFormat('dd.MM.yyyy').format(d),style:const TextStyle(fontWeight:FontWeight.w800)),subtitle:Text(DateFormat('HH:mm').format(d)),trailing:Icon(open?Icons.expand_less:Icons.expand_more),onTap:()=>setState(()=>selectedDate=open?null:key)),if(open)_details(m)]));}
  Widget _details(Measurement m) {
    final rows = _all(m);
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Divider(),
          ...rows.map((e) => Padding(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(child: Text(e.$1, style: const TextStyle(color: Colors.black54))),
                    Expanded(flex: 2, child: Text(e.$2, style: const TextStyle(fontWeight: FontWeight.w600))),
                  ],
                ),
              )),
          const SizedBox(height: 10),
          if (SessionService.instance.currentUser.canCorrect)
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: () async {
                  final changed = await Navigator.push<bool>(
                    context,
                    MaterialPageRoute(builder: (_) => _CorrectionScreen(measurement: m)),
                  );
                  if (changed == true) _load();
                },
                icon: const Icon(Icons.edit_outlined),
                label: const Text('Корректировать параметры'),
              ),
            ),
        ],
      ),
    );
  }
  List<(String,String)> _all(Measurement m){String f(double? v,String u)=>v==null?'Не измерено':'${v.toStringAsFixed(v.truncateToDouble()==v?0:2).replaceAll('.',',')} $u';return [
    ('Дата и время',DateFormat('dd.MM.yyyy HH:mm').format(m.measuredAt)),('Ртр',f(m.rtr,'кгс/см²')),('Рз',f(m.rz,'кгс/см²')),('ПКВ установлена',m.pkvInstalled?'Да':'Нет'),('ПКВ: работа',m.pkvInstalled?f(m.pkvWork?.toDouble(),'мин'):'Не применяется'),('ПКВ: простой',m.pkvInstalled?f(m.pkvIdle?.toDouble(),'мин'):'Не применяется'),('ПКВ: цикл',m.pkvCycle?.toString()??'Не измерено'),('ПИД установлен',m.pidInstalled?'Да':'Нет'),('Ток ПИД',f(m.pidCurrent,'А')),('Диапазон F',m.pidFrequencyRange??'Не измерено'),('F',f(m.frequency,'Гц')),('Iср',f(m.current,'А')),('Загрузка',f(m.load,'%')),('Рпр',f(m.rp,'атм')),('Тпэд',f(m.tPed,'°C')),('Rизол',f(m.rInsul,'кОм')),('Рбуф',f(m.rBuf,'МПа')),('Источник Рбуф',m.rBufSource??'Не измерено'),('Рлин',f(m.rLine,'МПа')),('Источник Рлин',m.rLineSource??'Не измерено'),('Рмеж. др.',f(m.rInterDr,'МПа')),('Рзатр',f(m.rCasing,'МПа')),('Тлин',f(m.tLine,'°C')),('Тузд',f(m.tDownhole,'°C')),('Дросселирование',m.chokeMode??'Не измерено'),('Значение дросселя',m.chokeMode=='Дроссель'?(m.chokeValue==null?'Не измерено':'${m.chokeValue!.round()} %'):(m.nozzle??'Не измерено')),('Рузд',f(m.rDownhole,'МПа')),('Рко',f(m.rKo,'МПа')),('Подача ингибитора',f(m.inhibitorFeed,'кг/ч')),('Замечание',m.note??'Нет'),
  ];}
}

class _CorrectionScreen extends StatefulWidget {const _CorrectionScreen({required this.measurement});final Measurement measurement;@override State<_CorrectionScreen> createState()=>_CorrectionScreenState();}
class _CorrectionScreenState extends State<_CorrectionScreen>{final repo=MeasurementRepository();final value=TextEditingController(),reason=TextEditingController(),comment=TextEditingController();late String parameter;late final List<MapEntry<String,String>> fields;bool saving=false;
 @override void initState(){super.initState();parameter='rtr';fields=<String,String>{'rtr':'Ртр','rz':'Рз','pkv_installed':'ПКВ установлена','pid_installed':'ПИД установлен','pkv_work':'ПКВ: работа','pkv_idle':'ПКВ: простой','pid_current':'Ток ПИД','pid_frequency_range':'Диапазон F','frequency':'F','current':'Iср','load':'Загрузка','rp':'Рпр','t_ped':'Тпэд','r_insul':'Rизол','r_buf':'Рбуф','r_buf_source':'Источник Рбуф','r_inter_dr':'Рмеж. др.','r_casing':'Рзатр','r_line':'Рлин','r_line_source':'Источник Рлин','t_line':'Тлин','t_downhole':'Тузд','choke_mode':'Дросселирование','choke_value':'Значение дросселя','nozzle':'Штуцер','r_downhole':'Рузд','r_ko':'Рко','inhibitor_feed':'Подача ингибитора','note':'Замечание'}.entries.toList();value.text=_old()??'';}
 String? _old(){final m=widget.measurement;switch(parameter){case'rtr':return m.rtr?.toString();case'rz':return m.rz?.toString();case'pkv_installed':return m.pkvInstalled?'Да':'Нет';case'pid_installed':return m.pidInstalled?'Да':'Нет';case'pkv_work':return m.pkvWork?.toString();case'pkv_idle':return m.pkvIdle?.toString();case'pid_current':return m.pidCurrent?.toString();case'pid_frequency_range':return m.pidFrequencyRange;case'frequency':return m.frequency?.toString();case'current':return m.current?.toString();case'load':return m.load?.toString();case'rp':return m.rp?.toString();case't_ped':return m.tPed?.toString();case'r_insul':return m.rInsul?.toString();case'r_buf':return m.rBuf?.toString();case'r_buf_source':return m.rBufSource;case'r_inter_dr':return m.rInterDr?.toString();case'r_casing':return m.rCasing?.toString();case'r_line':return m.rLine?.toString();case'r_line_source':return m.rLineSource;case't_line':return m.tLine?.toString();case't_downhole':return m.tDownhole?.toString();case'choke_mode':return m.chokeMode;case'choke_value':return m.chokeValue?.toString();case'nozzle':return m.nozzle;case'r_downhole':return m.rDownhole?.toString();case'r_ko':return m.rKo?.toString();case'inhibitor_feed':return m.inhibitorFeed?.toString();case'note':return m.note;default:return null;}}
 @override Widget build(BuildContext context){final bool b=parameter=='pkv_installed'||parameter=='pid_installed';return Scaffold(appBar:AppBar(title:const Text('Корректировка замера')),body:ListView(padding:const EdgeInsets.all(16),children:[Card(child:ListTile(title:Text('Скважина ${widget.measurement.wellNumber}'),subtitle:Text(DateFormat('dd.MM.yyyy HH:mm').format(widget.measurement.measuredAt)))),const SizedBox(height:12),DropdownButtonFormField<String>(value:parameter,decoration:const InputDecoration(labelText:'Параметр для корректировки'),items:fields.map((e)=>DropdownMenuItem(value:e.key,child:Text(e.value))).toList(),onChanged:(v){if(v!=null)setState((){parameter=v;value.text=_old()??'';});}),const SizedBox(height:8),Text('Текущее значение: ${_old()??'—'}',style:const TextStyle(fontWeight:FontWeight.w700)),const SizedBox(height:8),if(b)DropdownButtonFormField<String>(value:(value.text=='Да'||value.text=='Нет')?value.text:null,decoration:const InputDecoration(labelText:'Новое значение'),items:const[DropdownMenuItem(value:'Да',child:Text('Да')),DropdownMenuItem(value:'Нет',child:Text('Нет'))],onChanged:(v)=>setState(()=>value.text=v??'')) else TextField(controller:value,maxLines:parameter=='note'?3:1,decoration:InputDecoration(labelText:'Новое значение')),const SizedBox(height:10),TextField(controller:reason,decoration:const InputDecoration(labelText:'Причина исправления *')),const SizedBox(height:10),TextField(controller:comment,maxLines:2,decoration:const InputDecoration(labelText:'Комментарий')),const SizedBox(height:18),FilledButton.icon(onPressed:saving?null:_save,icon:const Icon(Icons.check),label:const Text('Сохранить корректировку'))]));}
 Future<void> _save()async{if(reason.text.trim().isEmpty){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Укажите причину исправления')));return;}setState(()=>saving=true);try{await repo.correct(measurementId:widget.measurement.id!,parameter:parameter,newValue:value.text,userId:SessionService.instance.currentUser.id,userName:SessionService.instance.currentUser.name,reason:reason.text.trim(),comment:comment.text.trim().isEmpty?null:comment.text.trim());if(mounted)Navigator.pop(context,true);}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Ошибка: $e')));}finally{if(mounted)setState(()=>saving=false);}}
 @override void dispose(){value.dispose();reason.dispose();comment.dispose();super.dispose();}
}
