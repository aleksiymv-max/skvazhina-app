import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../core/models/pad.dart';
import '../../core/models/production_area.dart';
import '../../core/models/well.dart';
import '../../core/models/user.dart';
import '../../core/models/measurement.dart';
import '../../core/services/session_service.dart';
import '../../core/services/sync_service.dart';
import '../../core/repositories/measurement_repository.dart';
import '../../shared/widgets/status_chip.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final repo = MeasurementRepository();
  List<Pad> pads = demoPads;
  Map<String, WellStatus> statuses = {};
  List<Measurement> problems = [];
  bool loading = true;

  @override void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    statuses = await repo.allWellStatuses();
    problems = await repo.unresolvedProblems();
    if (mounted) setState(() => loading = false);
  }

  List<Well> get wells => pads.expand((p) => p.wells).toList();
  WellStatus _status(Well w) => statuses[w.id] ?? w.status;
  int _count(WellStatus s) => wells.where((w) => _status(w) == s).length;
  int get oilWells => wells.where((w) => w.type == WellType.oil).length;
  int get gasWells => wells.where((w) => w.type == WellType.gasCondensate).length;
  int get oilPads => pads.where((p) => p.wells.any((w) => w.type == WellType.oil)).length;
  int get gasPads => pads.where((p) => p.wells.any((w) => w.type == WellType.gasCondensate)).length;
  int get oilProblems => problems.where((m) => _wellById(m.wellId)?.type == WellType.oil).length;
  int get gasProblems => problems.length - oilProblems;
  Well? _wellById(String id) { for (final p in pads) { for (final w in p.wells) { if (w.id == id) return w; } } return null; }

  @override Widget build(BuildContext context) {
    if (loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    final u = SessionService.instance.currentUser;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Нефтяник', style: TextStyle(fontWeight: FontWeight.w900)),
        actions: [
          IconButton(onPressed: () => context.push('/organization'), icon: const Icon(Icons.tune_outlined)),
          IconButton(onPressed: () async { await SessionService.instance.logout(); if (context.mounted) context.go('/login'); }, icon: const Icon(Icons.logout)),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(padding: const EdgeInsets.fromLTRB(16, 4, 16, 28), children: [
          Row(children: [
            Expanded(child: Text('Главная', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w900))),
            StatusChip(label: SyncService.instance.online ? 'Онлайн' : 'Офлайн', kind: SyncService.instance.online ? StatusKind.ok : StatusKind.warning),
          ]),
          const SizedBox(height: 6),
          const Text('Обзор месторождения', style: TextStyle(color: Colors.black54)),
          const SizedBox(height: 14),
          _fieldCard(context),
          const SizedBox(height: 12),
          _dashboardGrid(context),
          const SizedBox(height: 12),
          _statusVisual(),
          const SizedBox(height: 12),
          if (u.role == UserRole.shopChief || u.role == UserRole.engineer) _personnelTile(context),
          const SizedBox(height: 12),
          _quickActions(context),
        ]),
      ),
      bottomNavigationBar: NavigationBar(selectedIndex: 0, destinations: const [
        NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Главная'),
        NavigationDestination(icon: Icon(Icons.factory_outlined), label: 'Участки'),
        NavigationDestination(icon: Icon(Icons.water_drop_outlined), label: 'Скважины'),
        NavigationDestination(icon: Icon(Icons.history), label: 'История'),
        NavigationDestination(icon: Icon(Icons.person_outline), label: 'Профиль'),
      ], onDestinationSelected: (i) {
        if (i == 1 && demoAreas.isNotEmpty) context.push('/area/${demoAreas.first.id}');
        if (i == 3) context.push('/history');
        if (i == 4) context.push('/organization');
      }),
    );
  }

  Widget _fieldCard(BuildContext context) => Card(
    child: InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: () => context.push('/organization'),
      child: Padding(padding: const EdgeInsets.all(16), child: Row(children: [
        CircleAvatar(backgroundColor: Theme.of(context).colorScheme.primaryContainer, child: Icon(Icons.location_on_outlined, color: Theme.of(context).colorScheme.primary)),
        const SizedBox(width: 12),
        const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Месторождение', style: TextStyle(fontSize: 12, color: Colors.black54)), SizedBox(height: 3), Text('Демо-месторождение', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800))])),
        const Icon(Icons.chevron_right),
      ])),
    ),
  );

  Widget _dashboardGrid(BuildContext context) => GridView.count(
    crossAxisCount: 2, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), crossAxisSpacing: 10, mainAxisSpacing: 10, childAspectRatio: 1.42,
    children: [
      _dash('Участки', demoAreas.length, 'Нефть ${demoAreas.where((a) => a.pads.any((p) => p.wells.any((w) => w.type == WellType.oil))).length} · Газ ${demoAreas.where((a) => a.pads.any((p) => p.wells.any((w) => w.type == WellType.gasCondensate))).length}', Icons.account_tree_outlined, () => _showAreas()),
      _dash('Кусты', pads.length, 'Нефть $oilPads · Газ $gasPads', Icons.factory_outlined, () => _showPads()),
      _dash('Скважины', wells.length, 'Нефть $oilWells · Газ $gasWells', Icons.oil_barrel_outlined, () => _showWells()),
      _dash('В работе', _count(WellStatus.working), 'Остановлено ${_count(WellStatus.stopped)} · ВНР ${_count(WellStatus.workover)}', Icons.play_circle_outline, () => _showStatus()),
      _dash('Проблемы', problems.length, 'Нефть $oilProblems · Газ $gasProblems', Icons.warning_amber_outlined, () => _showProblems()),
      _dash('Персонал', SessionService.instance.workersForChief(SessionService.instance.currentUser.isChief ? SessionService.instance.currentUser.id : (SessionService.instance.currentUser.chiefId ?? 'chief-001')).length, 'Открыть список сотрудников', Icons.groups_outlined, () => context.push('/personnel')),
    ],
  );

  Widget _dash(String title, int value, String sub, IconData icon, VoidCallback tap) => Card(
    child: InkWell(borderRadius: BorderRadius.circular(16), onTap: tap, child: Padding(padding: const EdgeInsets.all(13), child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
      Icon(icon, color: Theme.of(context).colorScheme.primary), const SizedBox(height: 5), Text(title, style: const TextStyle(fontSize: 12, color: Colors.black54)),
      Text('$value', style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w900)), Text(sub, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 10, color: Colors.black54)),
    ]))),
  );

  Widget _statusVisual() {
    final total = wells.length;
    return Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Состояние фонда', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)), const SizedBox(height: 10),
      SizedBox(height: 155, child: Row(children: [
        SizedBox(width: 155, height: 155, child: CustomPaint(painter: _StatusDonutPainter(working: _count(WellStatus.working), stopped: _count(WellStatus.stopped), workover: _count(WellStatus.workover), total: total))),
        const SizedBox(width: 18), Expanded(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [_legendRow('В работе', _count(WellStatus.working), Colors.green), _legendRow('Остановлена', _count(WellStatus.stopped), Colors.red), _legendRow('ВНР', _count(WellStatus.workover), Colors.orange)])),
      ])),
      const Divider(), Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [_legend('Нефть', null, Colors.black87, ), _legend('Газ', null, Colors.blue)]),
    ])));
  }
  Widget _legendRow(String label, int value, Color color) => Padding(padding: const EdgeInsets.symmetric(vertical: 4), child: Row(children: [Container(width: 10, height: 10, decoration: BoxDecoration(color: color, shape: BoxShape.circle)), const SizedBox(width: 7), Expanded(child: Text(label)), Text('$value', style: const TextStyle(fontWeight: FontWeight.w800))]));
  Widget _legend(String label, int? value, Color color) => Column(children: [Text(label, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: color)), Text(label == 'Нефть' ? '$oilWells' : '$gasWells', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900))]);
  Widget _personnelTile(BuildContext context) => Card(child: ListTile(onTap: () => context.push('/personnel'), leading: CircleAvatar(backgroundColor: Theme.of(context).colorScheme.primaryContainer, child: const Icon(Icons.groups_outlined)), title: const Text('Персонал', style: TextStyle(fontWeight: FontWeight.w800)), subtitle: const Text('Нажмите, чтобы открыть список сотрудников'), trailing: const Icon(Icons.chevron_right)));
  Widget _quickActions(BuildContext context) => Row(children: [Expanded(child: FilledButton.icon(onPressed: () => context.push('/trends'), icon: const Icon(Icons.show_chart), label: const Text('Тренды'))), const SizedBox(width: 10), Expanded(child: OutlinedButton.icon(onPressed: () => context.push('/history'), icon: const Icon(Icons.history), label: const Text('История')))]);

  void _showAreas() => showModalBottomSheet(context: context, isScrollControlled: true, builder: (_) => SafeArea(child: ListView(padding: const EdgeInsets.all(16), children: [const Text('Участки добычи', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)), const SizedBox(height: 10), ...demoAreas.map((a) => Card(child: ListTile(title: Text(a.name), subtitle: Text('${a.pads.length} кустовых площадок'), trailing: const Icon(Icons.chevron_right), onTap: () { Navigator.pop(context); context.push('/area/${a.id}'); })))])));
  void _showPads() => showModalBottomSheet(context: context, isScrollControlled: true, builder: (_) => SafeArea(child: ListView(padding: const EdgeInsets.all(16), children: [const Text('Кустовые площадки', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)), const SizedBox(height: 10), ...demoAreas.map((a) => Card(child: ExpansionTile(title: Text(a.name), children: a.pads.map((p) => ListTile(title: Text(p.name), subtitle: Text('${p.wells.length} скважин'), onTap: () { Navigator.pop(context); context.push('/pad/${p.id}'); })).toList())))])));
  void _showWells() => _showGrouped('Скважины по участкам и кустам', demoAreas.map((a) => MapEntry(a.name, a.pads.expand((p) => p.wells.map((w) => '${p.name} · ${w.number} · ${w.type == WellType.oil ? 'Нефтяная' : 'Газовая'}')).toList())).toList());
  void _showStatus() => _showGrouped('Состояние скважин', demoAreas.map((a) => MapEntry(a.name, a.pads.expand((p) => p.wells.map((w) => '${p.name} · ${w.number} · ${switch (_status(w)) { WellStatus.working => 'В работе', WellStatus.workover => 'ВНР', WellStatus.stopped => 'Остановлена' }}')).toList())).toList());
  Future<void> _showProblems() async { problems = await repo.unresolvedProblems(); if (!mounted) return; await showModalBottomSheet<void>(context: context, isScrollControlled: true, builder: (_) => SafeArea(child: ListView(padding: const EdgeInsets.all(16), children: [Text('Проблемы · ${problems.length}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)), const SizedBox(height: 10), ...problems.map((m) { final w = _wellById(m.wellId); return Card(child: ListTile(title: Text('Скважина ${m.wellNumber} · ${w?.type == WellType.oil ? 'Нефтяная' : 'Газовая'}'), subtitle: Text(m.problemNote ?? 'Проблема'))); })]))); }
  void _showGrouped(String title, List<MapEntry<String, List<String>>> groups) => showModalBottomSheet(context: context, isScrollControlled: true, builder: (_) => SafeArea(child: ListView(padding: const EdgeInsets.all(16), children: [Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)), const SizedBox(height: 10), ...groups.map((g) => Card(child: ExpansionTile(title: Text(g.key, style: const TextStyle(fontWeight: FontWeight.w800)), children: g.value.map((x) => ListTile(dense: true, leading: const Icon(Icons.circle, size: 8), title: Text(x))).toList())))])));
}

class _StatusDonutPainter extends CustomPainter {
  _StatusDonutPainter({required this.working, required this.stopped, required this.workover, required this.total});
  final int working, stopped, workover, total;
  @override void paint(Canvas canvas, Size size) { final center = Offset(size.width / 2, size.height / 2); final radius = size.shortestSide / 2 - 12; final bg = Paint()..style = PaintingStyle.stroke..strokeWidth = 22..color = Colors.black12; canvas.drawCircle(center, radius, bg); if (total == 0) return; var start = -1.5708; void arc(int value, Color color) { final sweep = 6.28318 * value / total; if (value > 0) { final p = Paint()..style = PaintingStyle.stroke..strokeWidth = 22..color = color; canvas.drawArc(Rect.fromCircle(center: center, radius: radius), start, sweep, false, p); start += sweep; } } arc(working, Colors.green); arc(stopped, Colors.red); arc(workover, Colors.orange); }
  @override bool shouldRepaint(covariant _StatusDonutPainter old) => old.working != working || old.stopped != stopped || old.workover != workover || old.total != total;
}
