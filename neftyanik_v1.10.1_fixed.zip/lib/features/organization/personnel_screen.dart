import 'package:flutter/material.dart';
import '../../core/services/session_service.dart';
import '../../core/models/user.dart';

class PersonnelScreen extends StatelessWidget {
  const PersonnelScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final user = SessionService.instance.currentUser;
    final chiefId = user.isChief ? user.id : (user.chiefId ?? 'chief-001');
    final workers = SessionService.instance.workersForChief(chiefId);
    final pending = SessionService.instance.pendingForChief(chiefId);
    return Scaffold(
      appBar: AppBar(title: const Text('Персонал')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
        children: [
          Row(children: [
            Expanded(child: _metric(context, 'Всего', workers.length.toString(), Icons.groups_outlined)),
            const SizedBox(width: 10),
            Expanded(child: _metric(context, 'ИТР', workers.where((x) => x.role == UserRole.engineer).length.toString(), Icons.engineering_outlined)),
            const SizedBox(width: 10),
            Expanded(child: _metric(context, 'Операторы', workers.where((x) => x.role == UserRole.operator).length.toString(), Icons.person_outline)),
          ]),
          if (user.isChief && pending.isNotEmpty) ...[
            const SizedBox(height: 16),
            const Text('Ожидают подтверждения', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            ...pending.map((p) => Card(child: ListTile(
              leading: const CircleAvatar(child: Icon(Icons.person_add_alt_1)),
              title: Text(p.name),
              subtitle: Text('${p.role.label}${p.subrole == null ? '' : ' · ${p.subrole!.label}'}'),
              trailing: FilledButton(onPressed: () => SessionService.instance.approve(p.id), child: const Text('Подтвердить')),
            ))),
          ],
          const SizedBox(height: 16),
          const Text('Сотрудники', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          if (workers.isEmpty) const Card(child: Padding(padding: EdgeInsets.all(18), child: Text('Сотрудники пока не добавлены.'))),
          ...workers.map((x) => Card(child: ListTile(
            leading: CircleAvatar(child: Icon(x.role == UserRole.engineer ? Icons.engineering_outlined : Icons.person_outline)),
            title: Text(x.name),
            subtitle: Text(x.role == UserRole.engineer ? '${x.role.label} · ${x.itrSubrole?.label ?? ''}' : x.role.label),
          ))),
        ],
      ),
    );
  }

  Widget _metric(BuildContext context, String title, String value, IconData icon) => Card(
    child: Padding(padding: const EdgeInsets.all(12), child: Column(children: [
      Icon(icon, color: Theme.of(context).colorScheme.primary),
      const SizedBox(height: 5),
      Text(value, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w900)),
      Text(title, style: const TextStyle(fontSize: 11, color: Colors.black54)),
    ])),
  );
}
