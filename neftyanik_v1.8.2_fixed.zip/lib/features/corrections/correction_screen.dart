import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../core/models/measurement.dart';
import '../../core/repositories/measurement_repository.dart';
import '../../core/services/session_service.dart';

class CorrectionScreen extends StatefulWidget {
  const CorrectionScreen({super.key, required this.measurement});
  final Measurement measurement;
  @override State<CorrectionScreen> createState() => _CorrectionScreenState();
}

class _CorrectionScreenState extends State<CorrectionScreen> {
  final repo = MeasurementRepository();
  final value = TextEditingController();
  final reason = TextEditingController();
  final comment = TextEditingController();
  late List<MapEntry<String, String>> fields;
  late String parameter;
  bool saving = false;

  @override
  void initState() {
    super.initState();
    fields = _fields();
    parameter = fields.first.key;
    value.text = _old() ?? '';
  }

  List<MapEntry<String, String>> _fields() {
    final m = widget.measurement;
    final gas = m.rBuf != null || m.rLine != null || m.tBeforeChoke != null || m.rDownhole != null || m.chokeMode != null;
    if (gas) {
      return <String, String>{
        'r_buf': 'Рбуф', 'r_buf_source': 'Источник Рбуф', 'rtr': 'Ртр', 'r_line': 'Рлин', 'r_line_source': 'Источник Рлин',
        't_before_choke': 'Тдо штуцера', 't_line': 'Тлин', 'choke_mode': 'Дросселирование', 'choke_value': 'Дроссель 1', 'choke_value2': 'Дроссель 2', 'nozzle': 'Штуцер',
        'r_downhole': 'Рузд', 't_downhole': 'Тузд', 'shutoff_valve_installed': 'Клапан-отсекатель', 'r_ko': 'Рко',
        'inhibitor_installed': 'Ингибитор', 'inhibitor_feed': 'Расход ингибитора', 'problem_note': 'Проблема',
      }.entries.toList();
    }
    return <String, String>{
      'rtr': 'Ртр', 'rz': 'Рз', 'pkv_installed': 'ПКВ установлена', 'pkv_work': 'ПКВ: работа', 'pkv_idle': 'ПКВ: простой',
      'pid_installed': 'ПИД установлена', 'pid_current': 'Ток ПИД', 'pid_frequency_range': 'Диапазон F', 'frequency': 'F', 'current': 'Iср', 'load': 'Загрузка',
      'rp': 'Рпр', 't_ped': 'Тпэд', 'r_insul': 'Rизол', 'problem_note': 'Проблема',
    }.entries.toList();
  }

  String? _old() {
    final m = widget.measurement;
    switch (parameter) {
      case 'rtr': return m.rtr?.toString(); case 'rz': return m.rz?.toString();
      case 'pkv_installed': return m.pkvInstalled ? 'Да' : 'Нет'; case 'pkv_work': return m.pkvWork?.toString(); case 'pkv_idle': return m.pkvIdle?.toString();
      case 'pid_installed': return m.pidInstalled ? 'Да' : 'Нет'; case 'pid_current': return m.pidCurrent?.toString(); case 'pid_frequency_range': return m.pidFrequencyRange;
      case 'frequency': return m.frequency?.toString(); case 'current': return m.current?.toString(); case 'load': return m.load?.toString(); case 'rp': return m.rp?.toString();
      case 't_ped': return m.tPed?.toString(); case 'r_insul': return m.rInsul?.toString(); case 'r_buf': return m.rBuf?.toString(); case 'r_buf_source': return m.rBufSource;
      case 'r_line': return m.rLine?.toString(); case 'r_line_source': return m.rLineSource; case 't_before_choke': return m.tBeforeChoke?.toString(); case 't_line': return m.tLine?.toString();
      case 'choke_mode': return m.chokeMode; case 'choke_value': return m.chokeValue?.toString(); case 'choke_value2': return m.chokeValue2?.toString(); case 'nozzle': return m.nozzle;
      case 'r_downhole': return m.rDownhole?.toString(); case 't_downhole': return m.tDownhole?.toString(); case 'shutoff_valve_installed': return m.shutoffValveInstalled ? 'Да' : 'Нет';
      case 'r_ko': return m.rKo?.toString(); case 'inhibitor_installed': return m.inhibitorInstalled ? 'Да' : 'Нет'; case 'inhibitor_feed': return m.inhibitorFeed?.toString(); case 'problem_note': return m.problemNote;
      default: return null;
    }
  }

  bool get _toggle => {'pkv_installed', 'pid_installed', 'shutoff_valve_installed', 'inhibitor_installed'}.contains(parameter);
  bool get _text => {'r_buf_source', 'r_line_source', 'choke_mode', 'nozzle', 'pid_frequency_range', 'problem_note'}.contains(parameter);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Корректировка замера')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Card(child: ListTile(title: Text('Скважина ${widget.measurement.wellNumber}'), subtitle: Text(DateFormat('dd.MM.yyyy HH:mm').format(widget.measurement.measuredAt)))),
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(
          value: parameter,
          decoration: const InputDecoration(labelText: 'Параметр для корректировки'),
          items: fields.map((e) => DropdownMenuItem(value: e.key, child: Text(e.value))).toList(),
          onChanged: (v) { if (v != null) setState(() { parameter = v; value.text = _old() ?? ''; }); },
        ),
        const SizedBox(height: 8),
        Text('Текущее значение: ${_old() ?? '—'}', style: const TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 8),
        if (_toggle)
          DropdownButtonFormField<String>(
            value: value.text == 'Да' || value.text == 'Нет' ? value.text : null,
            decoration: const InputDecoration(labelText: 'Новое значение'),
            items: const [DropdownMenuItem(value: 'Да', child: Text('Да')), DropdownMenuItem(value: 'Нет', child: Text('Нет'))],
            onChanged: (v) => setState(() => value.text = v ?? ''),
          )
        else
          TextField(controller: value, maxLines: _text ? 4 : 1, keyboardType: _text ? TextInputType.text : const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'Новое значение')),
        const SizedBox(height: 10),
        TextField(controller: reason, decoration: const InputDecoration(labelText: 'Причина исправления *')),
        const SizedBox(height: 10),
        TextField(controller: comment, maxLines: 2, decoration: const InputDecoration(labelText: 'Комментарий')),
        const SizedBox(height: 18),
        FilledButton.icon(onPressed: saving ? null : _save, icon: const Icon(Icons.check), label: const Text('Сохранить корректировку')),
      ]),
    );
  }

  Future<void> _save() async {
    if (reason.text.trim().isEmpty) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Укажите причину исправления'))); return; }
    setState(() => saving = true);
    try {
      await repo.correct(measurementId: widget.measurement.id!, parameter: parameter, newValue: value.text, userId: SessionService.instance.currentUser.id, userName: SessionService.instance.currentUser.name, reason: reason.text.trim(), comment: comment.text.trim().isEmpty ? null : comment.text.trim());
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Ошибка: $e')));
    } finally { if (mounted) setState(() => saving = false); }
  }

  @override void dispose() { value.dispose(); reason.dispose(); comment.dispose(); super.dispose(); }
}
