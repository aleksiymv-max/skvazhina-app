import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../core/models/pad.dart';
import '../../core/models/well.dart';
import '../../core/models/user.dart';
import '../../core/services/session_service.dart';
import '../../core/services/sync_service.dart';
import '../../core/repositories/measurement_repository.dart';
import '../../shared/widgets/status_chip.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final search = TextEditingController();
  final repo = MeasurementRepository();
  List<Pad> pads = demoPads;
  int checked = 0, checkedPads24h = 0, weekMeasurements = 0, weekProblems = 0;

  @override void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    checked = 0;
    for (final p in pads) checked += await repo.checkedCount(p.id);
    checkedPads24h = await repo.checkedPadsSince(DateTime.now().subtract(const Duration(hours: 24)));
    final week = DateTime.now().subtract(const Duration(days: 7));
    weekMeasurements = 0; weekProblems = 0;
    for (final p in pads) {
      final ms = await repo.history(padId: p.id, limit: 500);
      final recent = ms.where((m) => m.measuredAt.isAfter(week));
      weekMeasurements += recent.length;
      weekProblems += recent.where((m) => m.problemNote != null && m.problemNote!.trim().isNotEmpty).length;
    }
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final u = SessionService.instance.currentUser;
    final q = search.text.toLowerCase();
    final filtered = pads.where((p) => p.name.toLowerCase().contains(q)).toList();
    final wells = pads.expand((p) => p.wells).toList();
    final working = wells.where((w) => w.status == WellStatus.working).length;
    final problems = wells.where((w) => w.status != WellStatus.working).length;
    return Scaffold(
      appBar: AppBar(title: const Text('Нефтяник'), actions: [
        Padding(padding: const EdgeInsets.only(right: 8), child: Center(child: Text(u.role.label, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12)))),
        IconButton(onPressed: () => context.push('/organization'), tooltip: 'Управление', icon: const Icon(Icons.admin_panel_settings_outlined)),
        IconButton(onPressed: () async { await SessionService.instance.logout(); if (context.mounted) context.go('/login'); }, icon: const Icon(Icons.logout)),
      ]),
      body: ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 24), children: [
        Text('Обзор месторождения', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
        const SizedBox(height: 12),
        GridView.count(crossAxisCount: 2, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), crossAxisSpacing: 10, mainAxisSpacing: 10, childAspectRatio: 1.55, children: [
          _dash('Кустов', pads.length, Icons.location_on_outlined, _showPads),
          _dash('Скважин', wells.length, Icons.oil_barrel_outlined, _showWellsGrouped),
          _dash('В работе', working, Icons.play_circle_outline, _showWorking),
          _dash('Проблемы', problems, Icons.warning_amber_outlined, _showProblems),
        ]),
        const SizedBox(height: 12),
        Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Данные за последние 7 дней', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
          const SizedBox(height: 8), Row(children: [Expanded(child: Text('Замеров: $weekMeasurements')), Expanded(child: Text('Проблем: $weekProblems'))]),
        ]))),
        if (u.isChief) _chiefDashboard(),
        _syncCard(),
        const SizedBox(height: 14),
        TextField(controller: search, onChanged: (_) => setState(() {}), decoration: const InputDecoration(labelText: 'Поиск кустовой площадки', prefixIcon: Icon(Icons.search))),
        const SizedBox(height: 14), const Text('Кустовые площадки', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)), const SizedBox(height: 8),
        ...filtered.map((p) => Card(child: ListTile(onTap: () => context.push('/pad/${p.id}'), leading: CircleAvatar(backgroundColor: Theme.of(context).colorScheme.primaryContainer, child: const Icon(Icons.factory_outlined)), title: Text(p.name, style: const TextStyle(fontWeight: FontWeight.w800)), subtitle: Text('${p.wells.length} скважин · ${p.type}'), trailing: const Icon(Icons.chevron_right)))),
        const SizedBox(height: 12),
        Row(children: [Expanded(child: FilledButton.icon(onPressed: () => context.push('/trends'), icon: const Icon(Icons.show_chart), label: const Text('Тренды'))), const SizedBox(width: 10), Expanded(child: OutlinedButton.icon(onPressed: () => context.push('/history'), icon: const Icon(Icons.history), label: const Text('История')))]),
      ]),
    );
  }

  Widget _dash(String title, int value, IconData icon, VoidCallback onTap) {
    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(children: [
            Icon(icon, color: Theme.of(context).colorScheme.primary),
            const SizedBox(width: 10),
            Expanded(child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(title, style: const TextStyle(fontSize: 12, color: Colors.black54)),
                Text('$value', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
                const Text('Нажмите для списка', style: TextStyle(fontSize: 10, color: Colors.black45)),
              ],
            )),
          ]),
        ),
      ),
    );
  }

  void _showPads() => _showList('Кустовые площадки', pads.map((p) => '${p.name} — ${p.wells.length} скважин').toList());
  void _showWellsGrouped() => _showGrouped('Скважины по кустовым площадкам', pads.map((p) => MapEntry(p.name, p.wells.map((w) => '${w.number} · ${_status(w.status)}').toList())).toList());
  void _showWorking() => _showGrouped('Скважины в работе', pads.map((p) => MapEntry(p.name, p.wells.where((w) => w.status == WellStatus.working).map((w) => w.number).toList())).where((e) => e.value.isNotEmpty).toList());
  Future<void> _showProblems() async {
    final groups = <MapEntry<String, List<String>>>[];
    for (final p in pads) {
      final rows = <String>[];
      for (final w in p.wells) {
        final latest = await repo.latestForWell(w.id);
        final note = latest?.problemNote?.trim();
        if (w.status != WellStatus.working || (note != null && note.isNotEmpty)) {
          rows.add(note == null || note.isEmpty ? '${w.number} · ${_status(w.status)}' : '${w.number} · ${_status(w.status)}: $note');
        }
      }
      if (rows.isNotEmpty) groups.add(MapEntry(p.name, rows));
    }
    if (mounted) _showGrouped('Проблемы и остановки', groups);
  }
  String _status(WellStatus s) => switch (s) { WellStatus.working => 'Работает', WellStatus.stopped => 'Остановлена', WellStatus.krs => 'КРС', WellStatus.pdf => 'ПДФ', WellStatus.disabled => 'Отключен', WellStatus.underload => 'Недогруз' };

  void _showList(String title, List<String> rows) => showModalBottomSheet(context: context, isScrollControlled: true, builder: (_) => SafeArea(child: ListView(padding: const EdgeInsets.all(16), children: [Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)), const SizedBox(height: 10), ...rows.map((x) => Card(child: ListTile(leading: const Icon(Icons.chevron_right), title: Text(x))))])));

  void _showGrouped(String title, List<MapEntry<String, List<String>>> groups) => showModalBottomSheet(context: context, isScrollControlled: true, builder: (_) => SafeArea(child: ListView(padding: const EdgeInsets.all(16), children: [
    Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)), const SizedBox(height: 10),
    ...groups.map((g) => Card(child: ExpansionTile(title: Text(g.key, style: const TextStyle(fontWeight: FontWeight.w800)), children: g.value.map((x) => ListTile(dense: true, leading: const Icon(Icons.circle, size: 8), title: Text(x))).toList()))),
  ])));

  Widget _chiefDashboard() { final ws = SessionService.instance.workersForChief(SessionService.instance.currentUser.id); final pending = SessionService.instance.pendingForChief(SessionService.instance.currentUser.id).length; return Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('Статус работников', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)), const SizedBox(height: 8), Text('Подчинённых: ${ws.length}'), Text('Операторов: ${ws.where((u) => u.role == UserRole.operator).length} · ИТР: ${ws.where((u) => u.role == UserRole.engineer).length}'), Text('Ожидают подтверждения: $pending'), Text('Осмотрено кустовых площадок за 24 часа: $checkedPads24h')]))); }
  Widget _syncCard() => AnimatedBuilder(animation: SyncService.instance, builder: (context, _) { final s = SyncService.instance; return Card(child: ListTile(leading: Icon(s.online ? Icons.cloud_outlined : Icons.cloud_off_outlined), title: const Text('Локальные данные'), subtitle: Text(s.online ? 'Готово к синхронизации' : 'Работа офлайн'), trailing: StatusChip(label: s.online ? 'Онлайн' : 'Офлайн', kind: s.online ? StatusKind.ok : StatusKind.warning))); });
  @override void dispose() { search.dispose(); super.dispose(); }
}
