import 'dart:io';
import 'package:excel/excel.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

import '../models/measurement.dart';

class ExportService {
  static Future<File> createXlsx({required List<Measurement> measurements, required String padName}) async {
    final excel = Excel.createExcel();
    final sheet = excel['Замеры'];
    final headers = [
      'Дата и время','Куст','Скважина','Тип','Ртр, кгс/см²','Рз, кгс/см²','ПКВ работа, мин','ПКВ простой, мин','ПКВ цикл, мин',
      'F, Гц','Iср, А','Загрузка, %','Рпр, атм','Тпэд, °C','Rизол, кОм','Рбуф, МПа','Источник Рбуф','Рмеж. др., МПа',
      'Рзатр, МПа','Т до дросселя, °C','Рлин, МПа','Тлин, °C','Т после дросселя, °C','Дроссель 1, %','Дроссель 2, %','Штуцер',
      'Траб, °C','Рузд, МПа','Тузд, °C','Рко, МПа','Шибер ДУ','Подача ингибитора, кг/ч','Статусы','Источник замера'
    ];
    sheet.appendRow(headers.map((h) => TextCellValue(h)).toList());
    for (final m in measurements) {
      final values = [
        m.measuredAt.toLocal().toIso8601String().replaceFirst('T',' '), padName, m.wellNumber, _wellType(m),
        m.rtr, m.rz, m.pkvWork, m.pkvIdle, m.pkvCycle, m.frequency, m.current, m.load, m.rp, m.tPed, m.rInsul,
        m.rBuf, m.rBufSource, m.rInterDr, m.rCasing, m.tBeforeChoke, m.rLine, m.tLine, m.tAfterChoke, m.choke1, m.choke2,
        m.nozzle, m.tWork, m.rDownhole, m.tDownhole, m.rKo, m.duValve, m.inhibitorFeed,
        m.statuses.entries.map((e) => '${e.key}: ${e.value}').join('; '), m.source,
      ];
      sheet.appendRow(values.map(_cell).toList());
    }
    final dir = await getTemporaryDirectory();
    final safePad = padName.replaceAll(RegExp(r'[^A-Za-zА-Яа-я0-9_-]'), '_');
    final file = File('${dir.path}/замеры_${safePad}_${DateTime.now().millisecondsSinceEpoch}.xlsx');
    final bytes = excel.encode();
    if (bytes == null) throw StateError('Не удалось сформировать Excel-файл');
    await file.writeAsBytes(bytes, flush: true);
    return file;
  }

  static CellValue _cell(dynamic v) {
    if (v == null) return TextCellValue('');
    if (v is int) return IntCellValue(v);
    if (v is double) return DoubleCellValue(v);
    if (v is num) return DoubleCellValue(v.toDouble());
    return TextCellValue(v.toString());
  }

  static String _wellType(Measurement m) => m.gasState != null || m.rBuf != null || m.rLine != null ? 'Газоконденсатная' : 'Механизированная';

  static Future<void> shareXlsx(File file) async {
    await Share.shareXFiles([XFile(file.path)], text: 'Выгрузка замеров — Нефтяник');
  }
}
