import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../features/history/history_screen.dart';
import '../features/auth/login_screen.dart';
import '../features/corrections/correction_screen.dart';
import '../features/home/home_screen.dart';
import '../features/pads/pad_screen.dart';
import '../features/trends/trends_screen.dart';
import '../features/wells/well_screen.dart';
import '../core/models/measurement.dart';
import '../core/models/pad.dart';
import '../features/walk/walk_summary_screen.dart';
import 'theme.dart';

class OilmanApp extends StatelessWidget {
  const OilmanApp({super.key, this.initializationError});

  final Object? initializationError;

  static final GoRouter _router = GoRouter(
    initialLocation: '/login',
    routes: [
      GoRoute(path: '/login', builder: (_, __) => const LoginScreen()),
      GoRoute(path: '/', builder: (_, __) => const HomeScreen()),
      GoRoute(path: '/pad/:padId', builder: (_, state) => PadScreen(padId: state.pathParameters['padId']!)),
      GoRoute(path: '/pad/:padId/well/:wellId', builder: (_, state) => WellScreen(
        padId: state.pathParameters['padId']!,
        wellId: state.pathParameters['wellId']!,
      )),
      GoRoute(path: '/pad/:padId/walk/:index', builder: (_, state) {
        final padId = state.pathParameters['padId']!;
        final index = int.tryParse(state.pathParameters['index']!) ?? 0;
        final pad = demoPads.firstWhere((p) => p.id == padId);
        final safeIndex = index.clamp(0, pad.wells.length - 1).toInt();
        return WellScreen(padId: padId, wellId: pad.wells[safeIndex].id, walkIndex: safeIndex);
      }),
      GoRoute(path: '/pad/:padId/walk-summary', builder: (_, state) => WalkSummaryScreen(padId: state.pathParameters['padId']!)),
      GoRoute(path: '/history', builder: (_, __) => const HistoryScreen()),
      GoRoute(path: '/correction', builder: (_, state) => CorrectionScreen(measurement: state.extra! as Measurement)),
      GoRoute(path: '/trends', builder: (_, __) => const TrendsScreen()),
    ],
  );

  @override
  Widget build(BuildContext context) {
    return MaterialApp.router(
      title: 'Нефтяник',
      debugShowCheckedModeBanner: false,
      theme: buildAppTheme(),
      routerConfig: _router,
      builder: (context, child) {
        if (initializationError == null) return child ?? const SizedBox.shrink();
        return Material(
          child: SafeArea(
            child: Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.error_outline, size: 56),
                    const SizedBox(height: 16),
                    const Text('Не удалось открыть локальные данные', textAlign: TextAlign.center, style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
                    const SizedBox(height: 10),
                    Text(initializationError.toString(), textAlign: TextAlign.center),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
