enum WorkTaskTarget { personal, area, pad }
enum WorkTaskStatus { active, awaitingConfirmation, confirmed }

class WorkTask {
  WorkTask({required this.id,required this.title,required this.description,required this.createdBy,required this.createdAt,required this.targetType,required this.targetId,required this.targetName,this.areaName,this.padName,this.status=WorkTaskStatus.active,this.completedAt,this.completedBy,this.confirmedAt,this.confirmedBy});
  final String id,title,description,createdBy,targetId,targetName;
  final DateTime createdAt;
  final WorkTaskTarget targetType;
  final String? areaName,padName;
  WorkTaskStatus status;
  DateTime? completedAt,confirmedAt;
  String? completedBy,confirmedBy;
}

class WorkTaskStore {
  WorkTaskStore._(); static final instance=WorkTaskStore._();
  final List<WorkTask> tasks=[
    WorkTask(id:'t1',title:'Проверить состояние арматуры',description:'Осмотреть устьевую арматуру и сообщить о замечаниях.',createdBy:'Ведущий технолог',createdAt:DateTime.now().subtract(const Duration(hours:5)),targetType:WorkTaskTarget.pad,targetId:'1017',targetName:'КП 1017',areaName:'Участок добычи №1',padName:'КП 1017'),
    WorkTask(id:'t2',title:'Контроль давления',description:'Проверить давление на скважинах участка при ближайшем обходе.',createdBy:'Начальник цеха',createdAt:DateTime.now().subtract(const Duration(days:1)),targetType:WorkTaskTarget.area,targetId:'area-1',targetName:'Участок добычи №1',areaName:'Участок добычи №1'),
  ];
  void add(WorkTask t)=>tasks.insert(0,t);
  void complete(WorkTask t,String user){if(t.status!=WorkTaskStatus.active)return;t.status=WorkTaskStatus.awaitingConfirmation;t.completedAt=DateTime.now();t.completedBy=user;}
  void confirm(WorkTask t,String user){if(t.status!=WorkTaskStatus.awaitingConfirmation)return;t.status=WorkTaskStatus.confirmed;t.confirmedAt=DateTime.now();t.confirmedBy=user;}
}
